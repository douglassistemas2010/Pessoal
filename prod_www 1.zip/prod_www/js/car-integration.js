/**
 * CAR Integration - Integração com Cadastro Ambiental Rural
 * MapCarteiras v2.0
 * 
 * Sistema completo de integração com CAR (Cadastro Ambiental Rural)
 * - Carregamento automático por BBOX
 * - Cache de dados para otimização
 * - Popups e tooltips informativos
 * - Ajuste automático de polígonos aos limites CAR
 */

class CARIntegration {
    constructor() {
        this.config = CONFIG.car;
        this.carLayers = [];
        this.carLayerGroup = null;
        this.carFeatures = []; // Armazenar features para ajustes
        this.isLoading = false;
        this.isActive = false;
        this.cache = new Map(); // Cache de dados CAR por bbox
        this.cacheTimeout = 300000; // 5 minutos
        this.wfsAvailable = null; // null = não testado, true = disponível, false = indisponível
        console.log('✅ CAR Integration inicializado');
        
        // Testar disponibilidade do WFS em background
        this.testWFSAvailability();
    }

    /**
     * Testa se o servidor WFS do CAR está acessível
     */
    async testWFSAvailability() {
        try {
            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            console.log('🔍 TESTANDO CONECTIVIDADE COM SERVIDOR CAR');
            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            console.log(`📡 Servidor: ${this.config.wfsUrl}`);
            console.log(`⏱️  Timeout: 15 segundos`);
            console.log(`🔗 Testando URL: ${this.config.wfsUrl}?service=WFS&version=1.0.0&request=GetCapabilities`);
            
            // Fazer uma requisição simples GetCapabilities
            const url = `${this.config.wfsUrl}?service=WFS&version=1.0.0&request=GetCapabilities`;
            
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout (aumentado)
            
            const response = await fetch(url, {
                signal: controller.signal,
                method: 'GET',
                mode: 'cors'
            });
            
            clearTimeout(timeoutId);
            
            if (response.ok) {
                this.wfsAvailable = true;
                console.log('✅ SERVIDOR CAR ESTÁ ACESSÍVEL E RESPONDENDO');
                console.log(`   Status: ${response.status} ${response.statusText}`);
                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            } else {
                this.wfsAvailable = false;
                console.warn('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                console.warn(`❌ SERVIDOR CAR RETORNOU ERRO: ${response.status} ${response.statusText}`);
                console.warn('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                console.warn('💡 O sistema continuará funcionando, mas dados CAR não estarão disponíveis');
            }
        } catch (error) {
            this.wfsAvailable = false;
            console.warn('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            if (error.name === 'AbortError') {
                console.warn('❌ TIMEOUT AO TESTAR SERVIDOR CAR (15 segundos)');
                console.warn('   O servidor não respondeu dentro do tempo esperado');
            } else {
                console.warn(`❌ ERRO AO ACESSAR SERVIDOR CAR: ${error.message}`);
                console.warn(`   Tipo de erro: ${error.name}`);
            }
            console.warn('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            console.warn('💡 Possíveis causas:');
            console.warn('   • Servidor CAR está offline ou em manutenção');
            console.warn('   • Firewall ou proxy bloqueando acesso');
            console.warn('   • Problemas de conectividade de rede');
            console.warn('💡 O sistema continuará funcionando, mas dados CAR não estarão disponíveis');
        }
    }

    /**
     * Detecta o estado baseado nas coordenadas do polígono
     * PRIORIDADE: 1) Região selecionada pelo usuário, 2) Coordenadas
     * @param {L.Polygon} polygon - Polígono do Leaflet
     * @returns {string} Código do estado (ex: 'pr', 'ms')
     */
    detectStateFromPolygon(polygon) {
        try {
            // Obter centro do polígono para log
            const bounds = polygon.getBounds();
            const center = bounds.getCenter();
            const lat = center.lat;
            const lng = center.lng;

            console.log(`📍 Detectando estado para coordenadas: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);

            // ═══════════════════════════════════════════════════════════════════
            // PRIORIDADE 1: Região selecionada pelo usuário (mais confiável)
            // ═══════════════════════════════════════════════════════════════════
            if (window.app && window.app.uiController && window.app.uiController.currentRegion) {
                const region = window.app.uiController.currentRegion;
                const state = this.config.regionMapping[region];
                if (state) {
                    console.log(`🗺️ Estado detectado via REGIÃO SELECIONADA: ${state.toUpperCase()} (${region})`);
                    return state;
                }
            }

            // ═══════════════════════════════════════════════════════════════════
            // PRIORIDADE 2: Detecção por coordenadas (fallback)
            // ═══════════════════════════════════════════════════════════════════
            console.log(`📍 Região não selecionada, usando detecção por coordenadas...`);

            // Ranges aproximados dos estados (baseado em coordenadas típicas)
            // NOTA: Há sobreposição entre estados, então a ordem importa!

            // Paraná: lat -27 a -22, lng -55 a -48 (prioridade alta - região mais comum)
            if (lat >= -27 && lat <= -22 && lng >= -55 && lng <= -48) {
                console.log('🗺️ Estado detectado por coordenadas: PR (Paraná)');
                return 'pr';
            }

            // Mato Grosso do Sul: lat -24 a -19, lng -58 a -54 (ajustado para não sobrepor PR)
            if (lat >= -24 && lat <= -19 && lng >= -58 && lng <= -54) {
                console.log('🗺️ Estado detectado por coordenadas: MS (Mato Grosso do Sul)');
                return 'ms';
            }

            // Mato Grosso: lat -18 a -7, lng -61 a -50
            if (lat >= -18 && lat <= -7 && lng >= -61 && lng <= -50) {
                console.log('🗺️ Estado detectado por coordenadas: MT (Mato Grosso)');
                return 'mt';
            }

            // Santa Catarina: lat -30 a -25, lng -54 a -48
            if (lat >= -30 && lat <= -25 && lng >= -54 && lng <= -48) {
                console.log('🗺️ Estado detectado por coordenadas: SC (Santa Catarina)');
                return 'sc';
            }

            // Rio Grande do Sul: lat -34 a -27, lng -58 a -49
            if (lat >= -34 && lat <= -27 && lng >= -58 && lng <= -49) {
                console.log('🗺️ Estado detectado por coordenadas: RS (Rio Grande do Sul)');
                return 'rs';
            }

            // Goiás: lat -20 a -12, lng -54 a -45
            if (lat >= -20 && lat <= -12 && lng >= -54 && lng <= -45) {
                console.log('🗺️ Estado detectado por coordenadas: GO (Goiás)');
                return 'go';
            }

            // São Paulo: lat -26 a -19, lng -53 a -44 (ajustado para não sobrepor PR)
            if (lat >= -26 && lat <= -19 && lng >= -53 && lng <= -44) {
                console.log('🗺️ Estado detectado por coordenadas: SP (São Paulo)');
                return 'sp';
            }

            // Minas Gerais: lat -23 a -14, lng -51 a -39
            if (lat >= -23 && lat <= -14 && lng >= -51 && lng <= -39) {
                console.log('🗺️ Estado detectado por coordenadas: MG (Minas Gerais)');
                return 'mg';
            }

            // Padrão: PR (região mais comum)
            console.warn('⚠️ Não foi possível detectar o estado, usando padrão: PR');
            return 'pr';

        } catch (error) {
            console.error('Erro ao detectar estado:', error);
            return 'pr'; // Padrão
        }
    }

    /**
     * Detecta estado a partir do nome da região
     * @param {string} regionName - Nome da região (ex: "Região PR I")
     * @returns {string} Código do estado (ex: 'pr')
     */
    detectStateFromRegion(regionName) {
        const state = this.config.regionMapping[regionName];
        if (state) {
            console.log(`🗺️ Estado detectado via região: ${state.toUpperCase()} (${regionName})`);
            return state;
        }
        console.warn(`⚠️ Região "${regionName}" não mapeada, usando padrão: PR`);
        return 'pr';
    }

    /**
     * Inicializa o layer group do CAR
     */
    initLayerGroup(map) {
        if (!this.carLayerGroup) {
            this.carLayerGroup = L.layerGroup();
            this.carLayerGroup.addTo(map);
            console.log('✅ CAR Layer Group criado');
        }
        return this.carLayerGroup;
    }

    /**
     * Carrega polígonos CAR para um polígono específico (BBOX do polígono)
     * @param {L.Polygon} polygon - Polígono do Leaflet para buscar CAR
     * @param {string} state - Código do estado (ex: 'pr', 'sc')
     * @param {Function} progressCallback - Callback opcional para atualizar progresso
     */
    async loadCARForPolygon(polygon, state = 'pr', progressCallback = null) {
        if (this.isLoading) {
            console.log('⏳ Já está carregando CAR...');
            return;
        }

        try {
            this.isLoading = true;
            console.log('🌐 Carregando polígonos CAR para o polígono selecionado...');

            // Obter bounds do polígono selecionado
            const bounds = polygon.getBounds();
            const bbox = `${bounds.getWest()},${bounds.getSouth()},${bounds.getEast()},${bounds.getNorth()}`;

            console.log(`📍 BBOX: ${bbox}`);
            console.log(`🗺️ Estado: ${state.toUpperCase()}`);

            // Buscar dados CAR com divisão automática de BBOX se necessário
            const features = await this.fetchCARDataWithSplit(state, bbox, 0, progressCallback);

            if (features.length === 0) {
                console.log('ℹ️ Nenhum polígono CAR encontrado nesta área');
                return null;
            }

            console.log(`✅ ${features.length} polígonos CAR carregados (total final)`);
            return features;

        } catch (error) {
            console.error('Erro ao carregar CAR:', error);
            throw error;
        } finally {
            this.isLoading = false;
        }
    }

    /**
     * Busca CAR com divisão automática de BBOX quando atingir o limite
     * @param {string} state - Código do estado
     * @param {string} bbox - BBOX no formato "west,south,east,north"
     * @param {number} depth - Profundidade da recursão (máx 4 níveis)
     * @param {Function} progressCallback - Callback para atualizar progresso (opcional)
     * @returns {Array} Features combinadas de todas as divisões
     */
    async fetchCARDataWithSplit(state, bbox, depth = 0, progressCallback = null) {
        const MAX_DEPTH = 4; // Máximo 4 níveis de subdivisão (2^8 = 256 quadrantes)
        const LIMIT_THRESHOLD = 10000; // Limite da API do CAR
        
        // ⭐ OTIMIZAÇÃO: Dividir proativamente áreas muito grandes (> 0.5° em qualquer dimensão)
        const [west, south, east, north] = bbox.split(',').map(Number);
        const width = east - west;
        const height = north - south;
        const area = width * height;
        
        // Se área é muito grande (> 0.25 graus²) e depth < 2, dividir imediatamente
        const LARGE_AREA_THRESHOLD = 0.25; // ~27km x 27km
        if (area > LARGE_AREA_THRESHOLD && depth < 2) {
            console.log(`📏 Área grande detectada (${width.toFixed(4)}° x ${height.toFixed(4)}° = ${area.toFixed(4)}°²)`);
            console.log(`   🔄 Dividindo proativamente em quadrantes menores (nível ${depth})...`);
            
            if (progressCallback) {
                progressCallback(`Área grande - dividindo em quadrantes menores...`);
            }
            
            // Pular direto para divisão em quadrantes
            return await this.splitAndFetchQuadrants(state, bbox, depth, progressCallback);
        }

        // Buscar dados para este BBOX
        const features = await this.fetchCARData(state, bbox);

        // Se não atingiu o limite OU já está no máximo de profundidade, retornar
        if (features.length < LIMIT_THRESHOLD || depth >= MAX_DEPTH) {
            if (features.length === LIMIT_THRESHOLD) {
                console.warn(`⚠️ AVISO: Limite de ${LIMIT_THRESHOLD} CARs atingido (profundidade ${depth})`);
                if (depth >= MAX_DEPTH) {
                    console.warn(`⚠️ Profundidade máxima atingida - pode haver mais CARs não carregados`);
                }
            }
            return features;
        }

        // LIMITE ATINGIDO - dividir BBOX em 4 quadrantes
        console.warn(`🔄 Limite de ${LIMIT_THRESHOLD} CARs atingido! Dividindo BBOX em quadrantes...`);
        console.log(`   📊 Profundidade: ${depth + 1}/${MAX_DEPTH}`);
        
        if (progressCallback) {
            progressCallback(`Área muito densa! Dividindo em quadrantes menores... (nível ${depth + 1})`);
        }
        
        return await this.splitAndFetchQuadrants(state, bbox, depth, progressCallback);
    }

    /**
     * Divide BBOX em 4 quadrantes e busca CARs de cada um
     * @param {string} state - Código do estado
     * @param {string} bbox - BBOX no formato "west,south,east,north"
     * @param {number} depth - Profundidade da recursão
     * @param {Function} progressCallback - Callback para atualizar progresso
     * @returns {Array} Features combinadas e deduplic adas
     */
    async splitAndFetchQuadrants(state, bbox, depth, progressCallback) {
        const [west, south, east, north] = bbox.split(',').map(Number);
        const centerLng = (west + east) / 2;
        const centerLat = (south + north) / 2;

        // Criar 4 quadrantes: SW, SE, NW, NE
        const quadrants = [
            `${west},${south},${centerLng},${centerLat}`,      // SW (sudoeste)
            `${centerLng},${south},${east},${centerLat}`,      // SE (sudeste)
            `${west},${centerLat},${centerLng},${north}`,      // NW (noroeste)
            `${centerLng},${centerLat},${east},${north}`       // NE (nordeste)
        ];

        console.log(`   🗺️ Dividindo em 4 quadrantes:`);
        quadrants.forEach((q, i) => {
            console.log(`      Q${i + 1}: ${q}`);
        });

        // Buscar CARs de cada quadrante em sequência
        const allFeatures = [];
        for (let i = 0; i < quadrants.length; i++) {
            console.log(`   🔍 Buscando quadrante ${i + 1}/4...`);
            
            if (progressCallback) {
                progressCallback(`Buscando CARs - quadrante ${i + 1} de 4 (nível ${depth + 1})...`);
            }
            
            const quadrantFeatures = await this.fetchCARDataWithSplit(state, quadrants[i], depth + 1, progressCallback);
            allFeatures.push(...quadrantFeatures);
            console.log(`      ✅ ${quadrantFeatures.length} CARs no quadrante ${i + 1}`);
        }

        // Remover duplicatas (CARs que podem aparecer em bordas de quadrantes)
        const uniqueFeatures = this.removeDuplicateFeatures(allFeatures);
        const duplicatesRemoved = allFeatures.length - uniqueFeatures.length;
        
        if (duplicatesRemoved > 0) {
            console.log(`   🧹 Removidas ${duplicatesRemoved} duplicatas`);
        }
        
        console.log(`   ✅ Total de ${uniqueFeatures.length} CARs únicos nos 4 quadrantes`);
        
        if (progressCallback) {
            progressCallback(`${uniqueFeatures.length} CARs carregados (após divisão em quadrantes)`);
        }
        
        return uniqueFeatures;
    }

    /**
     * Remove features duplicadas baseado no ID
     * @param {Array} features - Array de features GeoJSON
     * @returns {Array} Features únicas
     */
    removeDuplicateFeatures(features) {
        const seen = new Set();
        const unique = [];

        for (const feature of features) {
            // Tentar usar ID do CAR como identificador único
            const id = feature.id || 
                      feature.properties?.cod_imovel || 
                      feature.properties?.nu_car ||
                      JSON.stringify(feature.geometry); // Fallback: geometria completa

            if (!seen.has(id)) {
                seen.add(id);
                unique.push(feature);
            }
        }

        return unique;
    }

    /**
     * Busca dados CAR - FLUXO HÍBRIDO
     * 1. Cache Memória (5min) - mais rápido
     * 2. Cache Supabase (30 dias) - persistente
     * 3. WFS SICAR (fallback) - fonte original
     */
    async fetchCARData(state, bbox) {
        try {
            const cacheKey = `${state}_${bbox}`;
            const cacheConfig = CONFIG.carCache || {};
            const debugLogs = cacheConfig.debugLogs;

            console.log(`🔍 [CAR HÍBRIDO] Iniciando busca para ${state.toUpperCase()}...`);
            console.log(`   📋 Cache habilitado: ${cacheConfig.enabled}`);
            console.log(`   📋 DataManager configurado: ${window.app?.dataManager?.isConfigured() || false}`);
            console.log(`   📋 WFS disponível: ${this.wfsAvailable}`);

            // 1. VERIFICAR CACHE MEMÓRIA (mais rápido)
            const memoryCached = this.cache.get(cacheKey);
            if (memoryCached && (Date.now() - memoryCached.timestamp < this.cacheTimeout)) {
                console.log(`📦 [1. CACHE MEMÓRIA] ✅ HIT - ${memoryCached.data.length} features de ${state}`);
                return memoryCached.data;
            }
            console.log(`📦 [1. CACHE MEMÓRIA] ❌ MISS`);

            // 2. VERIFICAR CACHE SUPABASE (se habilitado)
            if (cacheConfig.enabled && window.app?.dataManager?.isConfigured()) {
                console.log(`📦 [2. CACHE SUPABASE] Verificando...`);
                const supabaseResult = await this.checkSupabaseCache(state, bbox);

                if (supabaseResult.features.length > 0) {
                    console.log(`📦 [2. CACHE SUPABASE] ✅ HIT - ${supabaseResult.features.length} features de ${state}`);

                    // Atualizar cache memória
                    this.cache.set(cacheKey, {
                        data: supabaseResult.features,
                        timestamp: Date.now()
                    });

                    // Background refresh se dados estão stale
                    if (supabaseResult.needsRefresh && cacheConfig.backgroundRefresh) {
                        console.log(`🔄 [BACKGROUND] Iniciando refresh de dados stale...`);
                        this.backgroundRefresh(state, bbox);
                    }

                    return supabaseResult.features;
                }
                console.log(`📦 [2. CACHE SUPABASE] ❌ MISS - needsRefresh: ${supabaseResult.needsRefresh}`);
            } else {
                console.log(`📦 [2. CACHE SUPABASE] ⏭️ PULADO (desabilitado ou DataManager não configurado)`);
            }

            // 3. BUSCAR DO WFS SICAR (fallback)
            console.log(`🌐 [3. WFS SICAR] Buscando dados de ${state.toUpperCase()}...`);
            const wfsFeatures = await this.fetchFromWFS(state, bbox);

            if (wfsFeatures.length > 0) {
                console.log(`🌐 [3. WFS SICAR] ✅ ${wfsFeatures.length} features carregadas`);

                // Salvar no cache memória
                this.cache.set(cacheKey, {
                    data: wfsFeatures,
                    timestamp: Date.now()
                });

                // Salvar no Supabase (assíncrono, não bloqueia)
                if (cacheConfig.enabled && window.app?.dataManager?.isConfigured()) {
                    this.saveToSupabaseCache(wfsFeatures, bbox);
                }
            } else {
                console.log(`🌐 [3. WFS SICAR] ⚠️ Nenhuma feature retornada`);
            }

            return wfsFeatures;

        } catch (error) {
            console.error(`❌ Erro no fluxo híbrido CAR de ${state}:`, error);
            return [];
        }
    }

    /**
     * Verifica cache Supabase para CAR features
     * @returns {Object} { features: [], needsRefresh: boolean }
     */
    async checkSupabaseCache(state, bbox) {
        try {
            const [west, south, east, north] = bbox.split(',').map(Number);
            const bboxObj = { west, south, east, north };
            const maxAgeDays = CONFIG.carCache?.freshnessThresholdDays || 30;

            // Verificar cobertura do cache
            const coverage = await window.app.dataManager.checkCARCacheCoverage(
                state, bboxObj, maxAgeDays
            );

            // Se não tem dados no cache, retornar vazio
            if (!coverage || coverage.total_cached === 0) {
                return { features: [], needsRefresh: true };
            }

            // Buscar features do cache
            const { data: cachedData, error } = await window.app.dataManager.getCARByBbox(
                state, bboxObj, { maxAgeDays }
            );

            if (error || !cachedData?.length) {
                return { features: [], needsRefresh: true };
            }

            // Converter para formato GeoJSON Feature
            const features = cachedData.map(row => ({
                type: 'Feature',
                id: row.cod_imovel,
                properties: {
                    cod_car: row.cod_car,
                    cod_imovel: row.cod_imovel,
                    nom_propri: row.nom_propri,
                    nom_munici: row.nom_munici,
                    sig_uf: row.sig_uf,
                    num_area: row.num_area,
                    des_condi: row.des_condi,
                    _cached: true,
                    _stale: row.is_stale
                },
                geometry: typeof row.geometry === 'string'
                    ? JSON.parse(row.geometry)
                    : row.geometry
            }));

            return {
                features,
                needsRefresh: coverage.needs_refresh || false
            };

        } catch (error) {
            console.warn('⚠️ Erro ao verificar cache Supabase:', error);
            return { features: [], needsRefresh: true };
        }
    }

    /**
     * Salva features CAR no Supabase (assíncrono)
     */
    async saveToSupabaseCache(features, bbox) {
        // Executar em background sem bloquear
        setTimeout(async () => {
            try {
                if (!features?.length) return;

                const result = await window.app.dataManager.saveCARToCache(features, bbox);

                if (CONFIG.carCache?.debugLogs) {
                    console.log(`💾 [CACHE SALVO] ${result.inserted} novos, ${result.updated} atualizados`);
                }
            } catch (error) {
                console.warn('⚠️ Erro ao salvar no cache Supabase:', error);
            }
        }, 100);
    }

    /**
     * Refresh em background de dados stale
     */
    async backgroundRefresh(state, bbox) {
        // Executar em background
        setTimeout(async () => {
            try {
                const freshFeatures = await this.fetchFromWFS(state, bbox);

                if (freshFeatures.length > 0) {
                    await window.app.dataManager.saveCARToCache(freshFeatures, bbox);

                    if (CONFIG.carCache?.debugLogs) {
                        console.log(`✅ [BACKGROUND REFRESH] ${freshFeatures.length} features atualizadas`);
                    }
                }
            } catch (error) {
                console.warn('⚠️ Erro no background refresh:', error);
            }
        }, 500);
    }

    /**
     * Busca dados CAR diretamente do servidor WFS SICAR
     * (Lógica original extraída para método separado)
     */
    async fetchFromWFS(state, bbox) {
        try {
            console.log(`🌐 [WFS] fetchFromWFS iniciado - wfsAvailable: ${this.wfsAvailable}`);

            // Aguardar teste de disponibilidade se ainda estiver em andamento
            if (this.wfsAvailable === null) {
                console.log('⏳ [WFS] Aguardando teste de disponibilidade do servidor CAR...');
                let waitCount = 0;
                while (this.wfsAvailable === null && waitCount < 20) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                    waitCount++;
                }
                console.log(`⏳ [WFS] Teste concluído após ${waitCount * 500}ms - wfsAvailable: ${this.wfsAvailable}`);
            }

            // Verificar se o WFS está disponível
            if (this.wfsAvailable === false) {
                console.warn('⚠️ [WFS] Servidor CAR não está disponível. Pulando requisição.');
                console.warn('   💡 Dica: Verifique se https://geoserver.car.gov.br está acessível na sua rede');
                return [];
            }

            console.log(`✅ [WFS] Servidor disponível, iniciando requisição...`);

            // Garantir que o estado está em lowercase
            const stateCode = state.toLowerCase();

            // Construir typeName correto: sicar:sicar_imoveis_pr
            const typeName = `${this.config.typeNamePrefix}${stateCode}`;

            // Construir URL WFS
            const params = new URLSearchParams({
                service: 'WFS',
                version: '1.0.0',
                request: 'GetFeature',
                typeName: typeName,
                outputFormat: this.config.outputFormat,
                srsName: 'EPSG:4326',
                bbox: bbox,
                maxFeatures: this.config.maxFeatures
            });

            const url = `${this.config.wfsUrl}?${params.toString()}`;

            // LOG DETALHADO COM URL CLICÁVEL
            console.log(`🔍 Buscando CAR de ${stateCode.toUpperCase()}...`);
            console.log(`📡 TypeName: ${typeName}`);
            console.log(`📦 BBOX: ${bbox}`);
            console.log(`🌐 URL: ${url}`);

            // Fazer requisição com timeout aumentado
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            const response = await fetch(url, {
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            // Validar resposta
            if (!data.features || !Array.isArray(data.features)) {
                console.warn('Resposta CAR sem features válidas');
                return [];
            }

            console.log(`✅ ${data.features.length} features de ${state} carregadas do WFS`);
            return data.features;

        } catch (error) {
            if (error.name === 'AbortError') {
                console.error(`⏱️ Timeout ao buscar CAR de ${state} (30 segundos)`);
            } else {
                console.error(`❌ Erro ao buscar CAR de ${state}:`, error.message);
            }
            return [];
        }
    }

    /**
     * Adiciona polígonos CAR ao mapa
     */
    addCARToMap(features, map) {
        try {
            // Inicializar layer group se necessário
            if (!this.carLayerGroup) {
                this.initLayerGroup(map);
            }

            // Limpar camada CAR anterior
            this.clearCAR();

            // Armazenar features para uso posterior (ajuste de polígonos)
            this.carFeatures = features;

            let layerCount = 0;

            // Adicionar cada feature
            features.forEach(feature => {
                try {
                    // Criar layer GeoJSON com estilo DISCRETO (segundo plano)
                    const layer = L.geoJSON(feature, {
                        style: {
                            color: '#888888',        // Cinza discreto
                            fillColor: '#cccccc',    // Cinza claro para preenchimento
                            fillOpacity: 0.05,       // Muito transparente (apenas contorno visível)
                            weight: 1,               // Linha fina
                            opacity: 0.4,            // Contorno semi-transparente
                            dashArray: '3, 6'        // Linha tracejada para ser menos invasivo
                        },
                        pane: 'carPane',             // Pane customizado para z-index baixo
                        onEachFeature: (feature, layer) => {
                            // Adicionar popup
                            layer.bindPopup(this.createCARPopup(feature.properties), {
                                maxWidth: 300,
                                className: 'car-popup'
                            });

                            // Adicionar tooltip
                            const tooltipContent = this.createCARTooltip(feature.properties);
                            layer.bindTooltip(tooltipContent, {
                                permanent: false,
                                direction: 'top',
                                className: 'car-tooltip'
                            });

                            // Hover effects - destaca levemente ao passar o mouse
                            layer.on('mouseover', function(e) {
                                this.setStyle({
                                    fillOpacity: 0.15,   // Destaca um pouco mais
                                    weight: 2,            // Linha um pouco mais espessa
                                    opacity: 0.6,         // Mais visível
                                    color: '#666666'      // Cinza mais escuro
                                });
                            });

                            layer.on('mouseout', function(e) {
                                this.setStyle({
                                    fillOpacity: 0.05,    // Volta ao discreto
                                    weight: 1,
                                    opacity: 0.4,
                                    color: '#888888'
                                });
                            });
                        }
                    });

                    // Adicionar ao layer group
                    layer.addTo(this.carLayerGroup);
                    this.carLayers.push(layer);
                    layerCount++;

                } catch (error) {
                    console.warn('Erro ao adicionar feature CAR:', error);
                }
            });

            // Garantir que o layer group está no mapa
            if (!map.hasLayer(this.carLayerGroup)) {
                this.carLayerGroup.addTo(map);
            }

            console.log(`✅ ${layerCount} polígonos CAR adicionados ao mapa`);
            
            // Notificação visual
            if (layerCount > 0 && window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    `${layerCount} polígonos CAR carregados`,
                    'success'
                );
            }

            return this.carLayers;

        } catch (error) {
            console.error('Erro ao adicionar CAR ao mapa:', error);
            throw error;
        }
    }

    /**
     * Cria conteúdo do popup para polígono CAR
     */
    createCARPopup(properties) {
        return `
            <div class="car-popup-content">
                <div class="car-popup-header">
                    <i class="bi bi-file-earmark-text text-danger"></i>
                    <strong>CAR - Cadastro Ambiental Rural</strong>
                </div>
                <div class="car-popup-body">
                    <div class="info-row">
                        <span class="info-label">Código CAR:</span>
                        <span class="info-value">${properties.cod_car || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Proprietário:</span>
                        <span class="info-value">${properties.nom_propri || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Município:</span>
                        <span class="info-value">${properties.nom_munici || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">UF:</span>
                        <span class="info-value">${properties.sig_uf || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Área (ha):</span>
                        <span class="info-value">${properties.num_area ? parseFloat(properties.num_area).toFixed(2) : 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Status:</span>
                        <span class="info-value">${properties.des_condi || 'N/A'}</span>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Cria conteúdo do tooltip para polígono CAR
     */
    createCARTooltip(properties) {
        const area = properties.num_area ? parseFloat(properties.num_area).toFixed(2) : 'N/A';
        return `<strong>CAR:</strong> ${properties.cod_car || 'N/A'}<br>
                <strong>Área:</strong> ${area} ha`;
    }

    /**
     * Busca polígonos CAR que intersectam com um polígono específico
     */
    async findIntersectingCAR(polygon, mapManager) {
        try {
            // Carregar CAR da área
            const bounds = L.geoJSON(polygon).getBounds();
            const bbox = `${bounds.getWest()},${bounds.getSouth()},${bounds.getEast()},${bounds.getNorth()}`;

            const features = [];
            for (const state of this.config.states) {
                try {
                    // Usar fetchCARDataWithSplit para lidar com áreas grandes
                    const stateFeatures = await this.fetchCARDataWithSplit(state, bbox);
                    features.push(...stateFeatures);
                    console.log(`   ✅ ${stateFeatures.length} CARs de ${state.toUpperCase()}`);
                } catch (error) {
                    console.warn(`Erro ao buscar CAR de ${state}:`, error);
                }
            }

            if (features.length === 0) {
                return [];
            }

            console.log(`🔍 Filtrando ${features.length} CARs por interseção real...`);

            // Filtrar apenas os que realmente intersectam
            const intersecting = features.filter(feature => {
                try {
                    return turf.booleanIntersects(polygon, feature);
                } catch (error) {
                    return false;
                }
            });

            console.log(`✅ ${intersecting.length} CARs intersectam o polígono`);

            console.log(`🔍 ${intersecting.length} polígonos CAR intersectam com o polígono`);
            return intersecting;

        } catch (error) {
            console.error('Erro ao buscar CAR intersectante:', error);
            return [];
        }
    }

    /**
     * Ajusta polígono para alinhar com boundaries CAR
     */
    async adjustPolygonToCAR(polygon, mapManager, polygonTools) {
        try {
            console.log('🎯 Ajustando polígono aos limites CAR...');

            // Encontrar polígonos CAR intersectantes
            const carFeatures = await this.findIntersectingCAR(polygon, mapManager);

            if (carFeatures.length === 0) {
                console.warn('Nenhum polígono CAR encontrado para ajuste');
                return polygon;
            }

            // Usar o primeiro CAR como referência
            const reference = carFeatures[0];

            // Fazer snap
            const adjusted = polygonTools.snapToNeighbor(polygon, reference, {
                tolerance: 0.02 // 20 metros
            });

            // Suavizar
            const smoothed = polygonTools.smoothPolygon(adjusted, {
                removeDentals: true
            });

            console.log('✅ Polígono ajustado aos limites CAR');
            return smoothed;

        } catch (error) {
            console.error('Erro ao ajustar polígono ao CAR:', error);
            return polygon;
        }
    }

    /**
     * Limpa todos os polígonos CAR do mapa
     */
    clearCAR() {
        if (this.carLayerGroup) {
            this.carLayerGroup.clearLayers();
        }
        this.carLayers = [];
        this.carFeatures = [];
        console.log('🗑️ Polígonos CAR removidos do mapa');
    }

    /**
     * Toggle visibilidade CAR
     */
    toggleCARVisibility(map) {
        if (!this.carLayerGroup) {
            console.warn('CAR Layer Group não inicializado');
            return;
        }

        if (map.hasLayer(this.carLayerGroup)) {
            map.removeLayer(this.carLayerGroup);
            this.isActive = false;
            console.log('👁️ CAR oculto');
            
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification('CAR oculto', 'info');
            }
        } else {
            map.addLayer(this.carLayerGroup);
            this.isActive = true;
            console.log('👁️ CAR visível');
            
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification('CAR visível', 'info');
            }
        }
    }

    /**
     * Ativa o sistema CAR
     */
    async activateCAR(map, state = null) {
        try {
            console.log('🚀 Ativando sistema CAR...');
            
            // Inicializar layer group
            this.initLayerGroup(map);
            
            // Carregar dados para a view atual
            const features = await this.loadCARForCurrentView(map, state);
            
            if (features && features.length > 0) {
                // Adicionar ao mapa
                this.addCARToMap(features, map);
                this.isActive = true;
                
                console.log('✅ Sistema CAR ativado com sucesso');
                return true;
            } else {
                console.warn('⚠️ Nenhum dado CAR encontrado para esta área');
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification(
                        'Nenhum polígono CAR encontrado nesta área',
                        'warning'
                    );
                }
                return false;
            }
            
        } catch (error) {
            console.error('Erro ao ativar CAR:', error);
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    'Erro ao carregar dados CAR',
                    'error'
                );
            }
            return false;
        }
    }

    /**
     * Desativa o sistema CAR
     */
    deactivateCAR(map) {
        this.clearCAR();
        if (this.carLayerGroup && map.hasLayer(this.carLayerGroup)) {
            map.removeLayer(this.carLayerGroup);
        }
        this.isActive = false;
        console.log('🛑 Sistema CAR desativado');
    }

    /**
     * Exporta polígonos CAR como GeoJSON
     */
    exportCARAsGeoJSON() {
        const features = [];
        
        this.carLayers.forEach(layer => {
            layer.eachLayer(function(l) {
                if (l.toGeoJSON) {
                    features.push(l.toGeoJSON());
                }
            });
        });

        const geojson = {
            type: 'FeatureCollection',
            features: features
        };

        return geojson;
    }

    /**
     * Limpa o cache de dados CAR
     */
    clearCache() {
        this.cache.clear();
        console.log('🗑️ Cache CAR limpo');
    }

    /**
     * Obtém informações do sistema CAR
     */
    getInfo() {
        return {
            isActive: this.isActive,
            isLoading: this.isLoading,
            layersCount: this.carLayers.length,
            cacheSize: this.cache.size,
            config: this.config
        };
    }

    /**
     * Carrega CAR para um polígono selecionado
     * Método principal para integração com o sistema de seleção de polígonos
     * @param {L.Polygon} polygon - Polígono selecionado
     * @param {string|null} state - Código do estado (opcional, será detectado automaticamente)
     * @param {L.Map} map - Mapa Leaflet
     */
    async loadCARForSelectedPolygon(polygon, state = null, map) {
        try {
            console.log('🎯 Carregando CAR para polígono selecionado...');
            
            // Detectar estado automaticamente se não foi fornecido
            if (!state) {
                state = this.detectStateFromPolygon(polygon);
                console.log(`🔍 Estado auto-detectado: ${state.toUpperCase()}`);
            }
            
            // Limpar CAR anterior
            this.clearCAR();
            
            // Inicializar layer group se necessário
            this.initLayerGroup(map);
            
            // Carregar polígonos CAR para a BBOX do polígono
            const features = await this.loadCARForPolygon(polygon, state);
            
            if (!features || features.length === 0) {
                console.log('ℹ️ Nenhum polígono CAR encontrado para este polígono');
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification(
                        `Nenhum polígono CAR encontrado nesta área (${state.toUpperCase()})`,
                        'info'
                    );
                }
                return null;
            }
            
            // Adicionar ao mapa
            this.addCARToMap(features, map);
            this.isActive = true;
            
            // Highlight dos polígonos CAR que intersectam
            this.highlightIntersectingCAR(polygon);
            
            console.log(`✅ ${features.length} polígonos CAR carregados para o polígono selecionado`);
            
            // Notificar usuário
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    `✅ ${features.length} polígonos CAR carregados (${state.toUpperCase()})`,
                    'success'
                );
            }
            
            return features;
            
        } catch (error) {
            console.error('Erro ao carregar CAR para polígono:', error);
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    'Erro ao carregar CAR',
                    'error'
                );
            }
            return null;
        }
    }

    /**
     * Remove apenas "dentes" (protrusões pequenas) mantendo a forma original
     * Usa buffer negativo MÍNIMO para cortar apenas irregularidades
     * 
     * IMPORTANTE: Para SUB-TERRITÓRIOS, mantém MultiPolygon (tipo PREENCHIMENTO)
     * 
     * @param {Object} polygon - GeoJSON Polygon/MultiPolygon
     * @param {number} bufferMeters - Buffer em metros para cortar dentes (default: 3m)
     * @param {boolean} preserveMultiPolygon - Se true, mantém MultiPolygon ao invés de pegar maior parte
     * @returns {Object} - Polígono sem dentes, mantendo forma e vértices
     */
    smoothPolygon(polygon, bufferMeters = 3, preserveMultiPolygon = false) {
        try {
            const bufferKm = bufferMeters / 1000;
            
            console.log(`✂️ Removendo dentes (buffer ${bufferMeters}m)...`);
            
            // Contar vértices ANTES
            const verticesBefore = polygon.geometry.type === 'Polygon' 
                ? polygon.geometry.coordinates[0].length 
                : polygon.geometry.coordinates[0][0].length;
            
            // TÉCNICA: Buffer negativo MUITO PEQUENO (-3m) seguido de positivo (+3m)
            // Isso "corta" apenas projeções finas (dentes) sem alterar forma geral
            
            // PASSO 1: Buffer NEGATIVO mínimo (corta dentes que se projetam)
            const contracted = turf.buffer(polygon, -bufferKm, { 
                units: 'kilometers', 
                steps: 4  // Poucos steps = menos vértices adicionados
            });
            
            if (!contracted) {
                console.warn('⚠️ Falha no buffer negativo');
                return polygon;
            }
            
            // Tratar MultiPolygon
            let basePolygon = contracted;
            if (contracted.geometry.type === 'MultiPolygon') {
                if (preserveMultiPolygon) {
                    // SUB-TERRITÓRIO: Manter TODOS os fragmentos (tipo PREENCHIMENTO)
                    console.log(`🔧 MultiPolygon detectado - MANTENDO TODOS os ${contracted.geometry.coordinates.length} fragmentos (preserveMultiPolygon=true)`);
                    // Não fazer nada, manter MultiPolygon completo
                } else {
                    // TERRITÓRIO: Pegar maior parte (tipo RECORTE)
                    console.log('🔧 MultiPolygon detectado, pegando maior parte...');
                    let largestPart = null;
                    let largestArea = 0;
                    
                    for (const coords of contracted.geometry.coordinates) {
                        try {
                            const part = turf.polygon(coords);
                            const area = turf.area(part);
                            if (area > largestArea) {
                                largestArea = area;
                                largestPart = part;
                            }
                        } catch (e) {
                            // Ignorar partes inválidas
                        }
                    }
                    
                    if (largestPart) {
                        basePolygon = largestPart;
                    }
                }
            }
            
            // PASSO 2: Buffer POSITIVO (volta ao tamanho original)
            const expanded = turf.buffer(basePolygon, bufferKm, { 
                units: 'kilometers', 
                steps: 4  // Poucos steps = mantém vértices próximos ao original
            });
            
            if (!expanded) {
                console.warn('⚠️ Falha no buffer positivo');
                return basePolygon;
            }
            
            // Pegar maior parte se virou MultiPolygon (SOMENTE se não estiver preservando)
            let finalPolygon = expanded;
            if (expanded.geometry.type === 'MultiPolygon' && !preserveMultiPolygon) {
                let largestPart = null;
                let largestArea = 0;
                
                for (const coords of expanded.geometry.coordinates) {
                    try {
                        const part = turf.polygon(coords);
                        const area = turf.area(part);
                        if (area > largestArea) {
                            largestArea = area;
                            largestPart = part;
                        }
                    } catch (e) {
                        // Ignorar
                    }
                }
                
                if (largestPart) {
                    finalPolygon = largestPart;
                }
            }
            
            // PASSO 3: Remover buracos internos (holes)
            if (finalPolygon.geometry.type === 'Polygon' && finalPolygon.geometry.coordinates.length > 1) {
                console.log('🔧 Removendo buracos internos...');
                finalPolygon.geometry.coordinates = [finalPolygon.geometry.coordinates[0]];
            } else if (finalPolygon.geometry.type === 'MultiPolygon') {
                // Para MultiPolygon, remover buracos de cada polígono
                console.log('🔧 Removendo buracos internos de MultiPolygon...');
                finalPolygon.geometry.coordinates = finalPolygon.geometry.coordinates.map(coords => {
                    return [coords[0]]; // Manter apenas anel externo de cada polígono
                });
            }
            
            // Contar vértices DEPOIS
            let verticesAfter;
            if (finalPolygon.geometry.type === 'Polygon') {
                verticesAfter = finalPolygon.geometry.coordinates[0].length;
            } else if (finalPolygon.geometry.type === 'MultiPolygon') {
                // Somar vértices de todos os fragmentos
                verticesAfter = finalPolygon.geometry.coordinates.reduce((sum, coords) => {
                    return sum + coords[0].length;
                }, 0);
            } else {
                verticesAfter = verticesBefore;
            }
            
            const change = verticesAfter - verticesBefore;
            const changePercent = Math.round((change / verticesBefore) * 100);
            
            console.log(`✅ Dentes removidos: ${verticesBefore} → ${verticesAfter} vértices (${change >= 0 ? '+' : ''}${changePercent}%)`);
            console.log(`💡 Forma preservada, apenas irregularidades removidas`);
            
            return finalPolygon;
            
        } catch (error) {
            console.warn('⚠️ Erro ao remover dentes:', error);
            return polygon; // Retornar original se falhar
        }
    }

    /**
     * Destaca (highlight) polígonos CAR que intersectam com um polígono específico
     */
    highlightIntersectingCAR(polygon) {
        try {
            let highlightCount = 0;
            
            this.carLayers.forEach(layer => {
                layer.eachLayer(carLayer => {
                    try {
                        // Verificar intersecção usando Turf.js
                        const polygonGeoJSON = polygon.toGeoJSON();
                        const carGeoJSON = carLayer.toGeoJSON();
                        
                        if (turf.booleanIntersects(polygonGeoJSON, carGeoJSON)) {
                            // Destacar levemente (ainda discreto, mas visível)
                            carLayer.setStyle({
                                color: '#4a9eff',        // Azul suave
                                fillColor: '#4a9eff',    // Azul suave
                                weight: 2,               // Linha um pouco mais espessa
                                fillOpacity: 0.12,       // Levemente mais visível
                                opacity: 0.5,            // Contorno mais visível
                                dashArray: '5, 5'        // Tracejado diferente para destacar
                            });
                            highlightCount++;
                        }
                    } catch (error) {
                        console.warn('Erro ao verificar intersecção:', error);
                    }
                });
            });
            
            if (highlightCount > 0) {
                console.log(`⭐ ${highlightCount} polígonos CAR intersectam com o polígono selecionado`);
            }
            
        } catch (error) {
            console.error('Erro ao destacar CAR intersectantes:', error);
        }
    }

    /**
     * Ajusta o polígono para alinhar com as divisas dos CARs
     * Usa SNAP (alinhamento) + SMOOTH (suavização)
     * Documentação: CAR_IMPLEMENTATION.md
     * @param {L.Polygon} polygon - Polígono a ser ajustado
     * @param {Array} carFeatures - Features dos CARs carregados
     * @returns {Object} GeoJSON do polígono ajustado
     */
    async adjustPolygonToCAR(polygon, carFeatures) {
        try {
            console.log('🎯 Iniciando ajuste ao CAR (SNAP + SMOOTH)...');
            
            if (!polygon || !carFeatures || carFeatures.length === 0) {
                console.warn('Polígono ou features CAR inválidos');
                return null;
            }

            // Converter polígono para GeoJSON
            const polygonGeoJSON = polygon.toGeoJSON();
            let territoryGeoJSON = turf.polygon(polygonGeoJSON.geometry.coordinates);

            // Encontrar CARs que intersectam com o polígono
            const intersectingCARs = [];
            
            for (const feature of carFeatures) {
                try {
                    // Validar estrutura do CAR
                    if (!feature || !feature.geometry || !feature.geometry.coordinates) {
                        continue;
                    }

                    let carPolygon;
                    
                    // Tratar diferentes tipos de geometria
                    if (feature.geometry.type === 'Polygon') {
                        const coords = feature.geometry.coordinates[0];
                        if (!coords || coords.length < 4) {
                            continue;
                        }
                        carPolygon = turf.polygon(feature.geometry.coordinates);
                    } else if (feature.geometry.type === 'MultiPolygon') {
                        // Pegar maior parte do MultiPolygon
                        let largestPart = null;
                        let largestArea = 0;
                        
                        for (const polyCoords of feature.geometry.coordinates) {
                            try {
                                const coords = polyCoords[0];
                                if (coords && coords.length >= 4) {
                                    const poly = turf.polygon(polyCoords);
                                    const area = turf.area(poly);
                                    if (area > largestArea) {
                                        largestArea = area;
                                        largestPart = poly;
                                    }
                                }
                            } catch (e) {
                                // Ignorar partes inválidas
                            }
                        }
                        
                        if (!largestPart) {
                            continue;
                        }
                        carPolygon = largestPart;
                    } else {
                        continue;
                    }
                    
                    // Verificar se há intersecção
                    try {
                        if (turf.booleanIntersects(territoryGeoJSON, carPolygon)) {
                            intersectingCARs.push(carPolygon);
                        }
                    } catch (e) {
                        // Ignorar CARs problemáticos
                    }
                } catch (error) {
                    // Ignorar CARs problemáticos
                }
            }

            console.log(`📍 Encontrados ${intersectingCARs.length} CARs intersectantes`);

            if (intersectingCARs.length === 0) {
                console.warn('⚠️ Nenhum CAR intersectando com o polígono');
                return null;
            }

            // ================================================================
            // ABORDAGEM: UNIÃO/EXPANSÃO - Território + TODOS os CARs
            // Expande o território para cobrir todos os CARs sobrepostos
            // ================================================================
            console.log(`🔗 Expandindo território para TODOS os ${intersectingCARs.length} CARs sobrepostos...`);
            
            // ETAPA 1: Começar com o território original
            let adjustedPolygon = territoryGeoJSON;
            
            // ETAPA 2: Unir território com CADA CAR (sem limite)
            let processedCount = 0;
            let failedCount = 0;
            const totalCARs = intersectingCARs.length;
            
            for (let i = 0; i < totalCARs; i++) {
                try {
                    const carPolygon = intersectingCARs[i];
                    
                    // Validar geometrias antes de unir
                    if (!adjustedPolygon || !adjustedPolygon.geometry) {
                        console.error(`   ❌ adjustedPolygon inválido no CAR ${i + 1}`);
                        failedCount++;
                        continue;
                    }
                    
                    if (!carPolygon || !carPolygon.geometry) {
                        console.error(`   ❌ carPolygon inválido no CAR ${i + 1}`);
                        failedCount++;
                        continue;
                    }
                    
                    // Garantir que são Features válidos
                    const feature1 = adjustedPolygon.type === 'Feature' 
                        ? adjustedPolygon 
                        : turf.feature(adjustedPolygon.geometry || adjustedPolygon);
                    
                    const feature2 = carPolygon.type === 'Feature'
                        ? carPolygon
                        : turf.feature(carPolygon.geometry || carPolygon);
                    
                    // Fazer UNIÃO (território + CAR) - Turf v6.5.0 aceita 2 features diretamente
                    const temp = turf.union(feature1, feature2);
                    
                    if (temp) {
                        adjustedPolygon = temp;
                        processedCount++;
                        
                        // Log a cada 50 CARs
                        if ((i + 1) % 50 === 0 || i === totalCARs - 1) {
                            console.log(`   ✓ ${i + 1}/${totalCARs} CARs processados (${((i + 1) / totalCARs * 100).toFixed(1)}%)`);
                        }
                    } else {
                        failedCount++;
                    }
                } catch (e) {
                    failedCount++;
                    if (failedCount <= 5) { // Mostrar apenas primeiros 5 erros
                        console.warn(`   ⚠️ CAR ${i + 1}: Falha ao unir (${e.message})`);
                    }
                }
            }
            
            console.log(`✅ União concluída: ${processedCount}/${totalCARs} CARs unidos com sucesso`);
            if (failedCount > 0) {
                console.warn(`⚠️ ${failedCount} CARs falharam na união`);
            }
            
            if (processedCount === 0) {
                console.error('❌ Nenhum CAR pôde ser unido ao território');
                return null;
            }

            // ETAPA 3: Tratar MultiPolygon (pegar maior parte)
            if (adjustedPolygon.geometry.type === 'MultiPolygon') {
                console.log('🔧 Resultado é MultiPolygon, pegando maior parte...');
                let largestPart = null;
                let largestArea = 0;
                
                for (const coords of adjustedPolygon.geometry.coordinates) {
                    try {
                        const part = turf.polygon(coords);
                        const area = turf.area(part);
                        if (area > largestArea) {
                            largestArea = area;
                            largestPart = part;
                        }
                    } catch (e) {
                        // Ignorar partes inválidas
                    }
                }
                
                if (largestPart) {
                    adjustedPolygon = largestPart;
                    console.log('✅ Maior parte selecionada');
                }
            }

            // ETAPA 4: Simplificação REMOVIDA - Agora é apenas MANUAL
            // O usuário decide quando simplificar clicando no botão
            console.log('⏭️ Simplificação automática desabilitada (apenas manual)');

            // ETAPA 5: Validar resultado
            const polygonTools = window.app.polygonTools || new PolygonTools();
            
            console.log('🔍 Validando resultado...');
            if (!polygonTools.validatePolygon(adjustedPolygon)) {
                console.warn('⚠️ Polígono ajustado inválido');
                return null;
            }

            // ETAPA 6: Calcular estatísticas
            const originalArea = polygonTools.calculateArea(territoryGeoJSON);
            const adjustedArea = polygonTools.calculateArea(adjustedPolygon);
            const areaChange = ((adjustedArea - originalArea) / originalArea * 100).toFixed(2);
            
            const originalVertices = territoryGeoJSON.geometry.coordinates[0].length;
            const adjustedVertices = adjustedPolygon.geometry.coordinates[0].length;

            const areaIncrease = (adjustedArea - originalArea).toFixed(2);
            const percentIncrease = ((adjustedArea - originalArea) / originalArea * 100).toFixed(2);
            
            // Armazenar estatísticas para o modal
            this.lastAdjustStats = {
                processed: processedCount,
                total: intersectingCARs.length,
                originalArea: originalArea,
                adjustedArea: adjustedArea,
                areaIncrease: areaIncrease,
                percentIncrease: percentIncrease,
                originalVertices: originalVertices,
                adjustedVertices: adjustedVertices
            };
            
            console.log(`
✅ AJUSTE CONCLUÍDO COM SUCESSO (EXPANSÃO + SUAVIZAÇÃO OTIMIZADA):

📊 Estatísticas:
   • Área original: ${originalArea.toFixed(2)} ha
   • Área ajustada: ${adjustedArea.toFixed(2)} ha
   • Aumento: +${areaIncrease} ha (+${percentIncrease}%) ⬆️
   
   • Vértices original: ${originalVertices}
   • Vértices ajustado: ${adjustedVertices} (suavizado)
   • ${adjustedVertices < originalVertices ? 'Redução' : 'Aumento'}: ${Math.abs(adjustedVertices - originalVertices)} vértices
   
   • CARs processados: ${processedCount}/${intersectingCARs.length} unidos
   • Taxa de sucesso: ${(processedCount / intersectingCARs.length * 100).toFixed(1)}%
   • Suavização: Otimizada (±30m, steps=8) - Rápida e eficiente ⚡
            `);

            // Retornar GeoJSON Feature (não Leaflet layer)
            return adjustedPolygon;

        } catch (error) {
            console.error('Erro ao ajustar polígono ao CAR:', error);
            return null;
        }
    }

    /**
     * Ajusta SUB-TERRITÓRIO ao CAR usando UNIÃO/EXPANSÃO
     * 1. EXPANDE para seguir contornos dos CARs periféricos externos
     * 2. MANTÉM todos fragmentos (tipo PREENCHIMENTO)
     * 
     * NOTA: Corte dentro do território pai acontece no STEP 2 do wizard
     */
    async adjustSubTerritoryToCAR(polygon, carFeatures) {
        try {
            console.log('🎯 Ajustando SUB-TERRITÓRIO ao CAR (UNIÃO/EXPANSÃO)...');
            
            if (!polygon || !carFeatures || carFeatures.length === 0) {
                console.warn('Polígono ou features CAR inválidos');
                return null;
            }

            // Converter polígono para GeoJSON
            const polygonGeoJSON = polygon.toGeoJSON ? polygon.toGeoJSON() : polygon;
            let subTerritoryGeoJSON = turf.polygon(polygonGeoJSON.geometry.coordinates);

            // Encontrar CARs que intersectam com o sub-território
            const intersectingCARs = [];
            
            for (const feature of carFeatures) {
                try {
                    // Validar estrutura do CAR
                    if (!feature || !feature.geometry || !feature.geometry.coordinates) {
                        continue;
                    }

                    let carPolygon;
                    
                    // Tratar diferentes tipos de geometria
                    if (feature.geometry.type === 'Polygon') {
                        const coords = feature.geometry.coordinates[0];
                        if (!coords || coords.length < 4) {
                            continue;
                        }
                        carPolygon = turf.polygon(feature.geometry.coordinates);
                    } else if (feature.geometry.type === 'MultiPolygon') {
                        // Pegar maior parte do MultiPolygon
                        let largestPart = null;
                        let largestArea = 0;
                        
                        for (const polyCoords of feature.geometry.coordinates) {
                            try {
                                const coords = polyCoords[0];
                                if (coords && coords.length >= 4) {
                                    const poly = turf.polygon(polyCoords);
                                    const area = turf.area(poly);
                                    if (area > largestArea) {
                                        largestArea = area;
                                        largestPart = poly;
                                    }
                                }
                            } catch (e) {
                                // Ignorar partes inválidas
                            }
                        }
                        
                        if (!largestPart) {
                            continue;
                        }
                        carPolygon = largestPart;
                    } else {
                        continue;
                    }
                    
                    // Verificar se há intersecção
                    try {
                        if (turf.booleanIntersects(subTerritoryGeoJSON, carPolygon)) {
                            intersectingCARs.push(carPolygon);
                        }
                    } catch (e) {
                        // Ignorar CARs problemáticos
                    }
                } catch (error) {
                    // Ignorar CARs problemáticos
                }
            }

            console.log(`📍 Encontrados ${intersectingCARs.length} CARs intersectantes`);

            if (intersectingCARs.length === 0) {
                console.warn('⚠️ Nenhum CAR intersectando com o sub-território');
                return null;
            }

            // ================================================================
            // FILTRAR APENAS CARs PERIFÉRICOS EXTERNOS
            // Queremos CARs que estão na BORDA EXTERNA do sub-território
            // = CARs que o sub-território NÃO contém completamente
            // = CARs que têm parte FORA dos limites do sub-território
            // ================================================================
            console.log(`🔍 Filtrando CARs periféricos externos...`);
            
            const peripheralCARs = [];
            
            for (const carPolygon of intersectingCARs) {
                try {
                    // Verificar se o sub-território contém o CAR completamente
                    const subTerritoryContainsCAR = turf.booleanContains(subTerritoryGeoJSON, carPolygon);
                    
                    if (!subTerritoryContainsCAR) {
                        // Sub-território NÃO contém o CAR = CAR tem parte FORA = PERIFÉRICO EXTERNO
                        peripheralCARs.push(carPolygon);
                    }
                    // Se subTerritoryContainsCAR = true, CAR está completamente dentro = IGNORA
                } catch (e) {
                    // Em caso de erro, incluir (seguro incluir do que excluir)
                    peripheralCARs.push(carPolygon);
                }
            }
            
            console.log(`📍 ${peripheralCARs.length} CARs periféricos externos encontrados (${intersectingCARs.length - peripheralCARs.length} CARs completamente internos ignorados)`);

            if (peripheralCARs.length === 0) {
                console.warn('⚠️ Nenhum CAR periférico encontrado');
                return subTerritoryGeoJSON; // Retornar original se não há CARs na periferia
            }

            // ================================================================
            // ABORDAGEM: UNIÃO/EXPANSÃO COM CARs PERIFÉRICOS
            // 1. Unir sub-território com CADA CAR periférico (expande para fora)
            // 2. Mantém todos fragmentos dentro do território pai (tipo PREENCHIMENTO)
            // ================================================================
            console.log(`🔗 Expandindo sub-território para seguir ${peripheralCARs.length} CARs periféricos...`);
            
            // ETAPA 1: Começar com o sub-território original
            let adjustedPolygon = subTerritoryGeoJSON;
            
            // ETAPA 2: Fazer UNIÃO com cada CAR periférico (expande para fora)
            let processedCount = 0;
            let failedCount = 0;
            
            for (let i = 0; i < peripheralCARs.length; i++) {
                try {
                    const carPolygon = peripheralCARs[i];
                    
                    // Validar geometrias
                    if (!adjustedPolygon || !adjustedPolygon.geometry) {
                        console.error(`  ❌ adjustedPolygon inválido no CAR ${i + 1}`);
                        failedCount++;
                        continue;
                    }
                    
                    if (!carPolygon || !carPolygon.geometry) {
                        console.error(`  ❌ carPolygon inválido no CAR ${i + 1}`);
                        failedCount++;
                        continue;
                    }
                    
                    const feature1 = adjustedPolygon.type === 'Feature'
                        ? adjustedPolygon
                        : turf.feature(adjustedPolygon.geometry || adjustedPolygon);
                    
                    const feature2 = carPolygon.type === 'Feature'
                        ? carPolygon
                        : turf.feature(carPolygon.geometry || carPolygon);
                    
                    // Fazer UNIÃO (sub-território + CAR periférico) - EXPANDE PARA FORA
                    const unionResult = turf.union(feature1, feature2);
                    
                    if (unionResult) {
                        adjustedPolygon = unionResult;
                        processedCount++;
                        console.log(`  ✅ CAR ${i + 1}/${peripheralCARs.length}: União calculada (expandiu)`);
                    } else {
                        console.log(`  ⚠️ CAR ${i + 1}/${peripheralCARs.length}: Sem união`);
                        failedCount++;
                    }
                } catch (e) {
                    console.warn(`  ❌ CAR ${i + 1}: Erro ao unir:`, e.message);
                    failedCount++;
                }
            }
            
            console.log(`✅ União concluída: ${processedCount}/${peripheralCARs.length} CARs periféricos unidos`);
            
            if (failedCount > 0) {
                console.warn(`⚠️ ${failedCount} CARs falharam na união`);
            }
            
            if (!adjustedPolygon) {
                console.error('❌ Nenhuma união válida');
                return null;
            }

            // ETAPA 3: Tratar MultiPolygon (MANTER TODOS os fragmentos - preenchimento)
            if (adjustedPolygon.geometry.type === 'MultiPolygon') {
                console.log('🔧 Resultado é MultiPolygon - MANTENDO TODOS os fragmentos (preenchimento)');
                
                // Para sub-território, MANTER o MultiPolygon com todos os fragmentos
                // Não pegar apenas a maior parte - isso é preenchimento, não recorte!
                const fragmentCount = adjustedPolygon.geometry.coordinates.length;
                console.log(`✅ ${fragmentCount} fragmentos mantidos (tipo: preenchimento)`);
                
                // Calcular área total de todos os fragmentos
                let totalArea = 0;
                for (const coords of adjustedPolygon.geometry.coordinates) {
                    try {
                        const part = turf.polygon(coords);
                        const area = turf.area(part);
                        totalArea += area;
                    } catch (e) {
                        console.warn('⚠️ Erro ao calcular área de fragmento');
                    }
                }
                console.log(`📊 Área total dos fragmentos: ${(totalArea / 10000).toFixed(2)} ha`);
                
                // MANTER O MULTIPOLYGON - não converter para Polygon
                // adjustedPolygon já está correto como MultiPolygon
            }

            // ETAPA 4: Simplificação MÍNIMA (apenas para remover vértices duplicados)
            // NÃO simplificar muito para preservar contornos detalhados do CAR!
            try {
                // Tolerância MUITO BAIXA - apenas limpar duplicatas, não alterar forma
                const simplified = turf.simplify(adjustedPolygon, { tolerance: 0.000001, highQuality: true });
                
                if (simplified && simplified.geometry) {
                    // Verificar se tem coordenadas válidas (suportar Polygon e MultiPolygon)
                    const hasValidCoords = simplified.geometry.type === 'Polygon' 
                        ? simplified.geometry.coordinates[0].length >= 4
                        : simplified.geometry.coordinates.length > 0;
                    
                    if (hasValidCoords) {
                        adjustedPolygon = simplified;
                        console.log('✅ Limpeza de duplicatas aplicada');
                    } else {
                        console.log('ℹ️ Limpeza não aplicada, mantendo geometria original');
                    }
                } else {
                    console.log('ℹ️ Limpeza não necessária, mantendo geometria original');
                }
            } catch (e) {
                console.warn('⚠️ Não foi possível limpar, mantendo original (contornos preservados)');
            }

            // ETAPA 5: Validar resultado
            const polygonTools = window.app.polygonTools || new PolygonTools();
            
            if (!polygonTools.validatePolygon(adjustedPolygon)) {
                console.warn('⚠️ Sub-território ajustado inválido');
                return null;
            }

            // ETAPA 6: Calcular estatísticas
            const originalArea = polygonTools.calculateArea(subTerritoryGeoJSON);
            const adjustedArea = polygonTools.calculateArea(adjustedPolygon);
            
            // Contar vértices (suportar Polygon e MultiPolygon)
            let originalVertices = 0;
            let adjustedVertices = 0;
            
            if (subTerritoryGeoJSON.geometry.type === 'Polygon') {
                originalVertices = subTerritoryGeoJSON.geometry.coordinates[0].length;
            } else if (subTerritoryGeoJSON.geometry.type === 'MultiPolygon') {
                subTerritoryGeoJSON.geometry.coordinates.forEach(poly => {
                    originalVertices += poly[0].length;
                });
            }
            
            if (adjustedPolygon.geometry.type === 'Polygon') {
                adjustedVertices = adjustedPolygon.geometry.coordinates[0].length;
            } else if (adjustedPolygon.geometry.type === 'MultiPolygon') {
                adjustedPolygon.geometry.coordinates.forEach(poly => {
                    adjustedVertices += poly[0].length;
                });
            }
            
            const geometryType = adjustedPolygon.geometry.type;
            const fragmentCount = geometryType === 'MultiPolygon' 
                ? adjustedPolygon.geometry.coordinates.length 
                : 1;
            
            console.log(`
✅ SUB-TERRITÓRIO AJUSTADO AO CAR (UNIÃO/EXPANSÃO):

📊 Estatísticas:
   • Área original: ${originalArea.toFixed(2)} ha
   • Área ajustada: ${adjustedArea.toFixed(2)} ha
   • Diferença: ${(adjustedArea - originalArea).toFixed(2)} ha (${((adjustedArea - originalArea) / originalArea * 100).toFixed(2)}%)
   
   • Vértices original: ${originalVertices}
   • Vértices ajustado: ${adjustedVertices}
   
   • Tipo: ${geometryType} (${fragmentCount} fragmento${fragmentCount > 1 ? 's' : ''})
   • CARs periféricos: ${peripheralCARs.length} (${intersectingCARs.length - peripheralCARs.length} internos ignorados)
   • Método: UNIÃO COM PERIFERIA EXTERNA + PREENCHIMENTO
   
⚠️  PRÓXIMO PASSO: STEP 2 cortará dentro do território pai
            `);

            // Retornar GeoJSON Feature
            return adjustedPolygon;

        } catch (error) {
            console.error('❌ Erro ao ajustar sub-território ao CAR:', error);
            return null;
        }
    }


}

// Export
window.CARIntegration = CARIntegration;
