/**
 * Exemplos de Uso do Sistema CAR
 * MapCarteiras v2.0
 */

// ============================================================
// EXEMPLO 1: Uso Básico - Carregar CAR para área visível
// ============================================================

async function exemploBasico() {
    console.log('=== EXEMPLO 1: Carregamento Básico ===');
    
    // Obter instâncias globais
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    
    // Carregar CAR para o estado de MS
    const features = await carIntegration.loadCARForCurrentView(
        mapManager.getMap(), 
        'MS'
    );
    
    console.log(`✅ ${features.length} polígonos CAR carregados`);
    
    // Adicionar ao mapa
    carIntegration.addCARToMap(features, mapManager);
    
    console.log('✅ Polígonos CAR exibidos no mapa');
}

// ============================================================
// EXEMPLO 2: Carregar CAR de múltiplos estados
// ============================================================

async function carregarMultiplosEstados() {
    console.log('=== EXEMPLO 2: Múltiplos Estados ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    
    const estados = ['MS', 'MT', 'PR'];
    let totalFeatures = 0;
    
    for (const estado of estados) {
        const features = await carIntegration.loadCARForCurrentView(
            mapManager.getMap(),
            estado
        );
        
        if (features && features.length > 0) {
            carIntegration.addCARToMap(features, mapManager);
            totalFeatures += features.length;
            console.log(`✅ ${features.length} polígonos de ${estado}`);
        }
    }
    
    console.log(`✅ Total: ${totalFeatures} polígonos CAR carregados`);
}

// ============================================================
// EXEMPLO 3: Buscar CAR que intersecta com polígono
// ============================================================

async function buscarCARIntersectante() {
    console.log('=== EXEMPLO 3: Buscar Interseção ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    
    // Definir um polígono de teste (coordenadas de exemplo)
    const poligonoTeste = {
        type: 'Polygon',
        coordinates: [[
            [-54.5, -20.5],
            [-54.5, -20.3],
            [-54.3, -20.3],
            [-54.3, -20.5],
            [-54.5, -20.5]
        ]]
    };
    
    // Buscar CAR que intersecta
    const intersectantes = await carIntegration.findIntersectingCAR(
        poligonoTeste,
        mapManager
    );
    
    console.log(`✅ ${intersectantes.length} polígonos CAR intersectam`);
    
    // Destacar os intersectantes no mapa
    intersectantes.forEach(feature => {
        const layer = L.geoJSON(feature, {
            style: {
                color: '#ff0000',
                weight: 3,
                fillOpacity: 0.5
            }
        }).addTo(mapManager.getMap());
        
        layer.bindPopup(`
            <strong>CAR Intersectante</strong><br>
            Código: ${feature.properties.cod_car || 'N/A'}<br>
            Área: ${feature.properties.num_area || 'N/A'} ha
        `);
    });
}

// ============================================================
// EXEMPLO 4: Ajustar polígono aos limites CAR
// ============================================================

async function ajustarPoligonoAoCAR() {
    console.log('=== EXEMPLO 4: Ajustar aos Limites CAR ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    const polygonTools = window.polygonTools;
    
    // Polígono original (aproximado)
    const poligonoOriginal = {
        type: 'Polygon',
        coordinates: [[
            [-54.5, -20.5],
            [-54.5, -20.3],
            [-54.3, -20.3],
            [-54.3, -20.5],
            [-54.5, -20.5]
        ]]
    };
    
    console.log('🎯 Ajustando polígono aos limites CAR...');
    
    // Ajustar
    const poligonoAjustado = await carIntegration.adjustPolygonToCAR(
        poligonoOriginal,
        mapManager,
        polygonTools
    );
    
    console.log('✅ Polígono ajustado');
    
    // Exibir ambos no mapa para comparação
    L.geoJSON(poligonoOriginal, {
        style: { color: '#ff0000', dashArray: '5, 5' }
    }).addTo(mapManager.getMap()).bindPopup('Original');
    
    L.geoJSON(poligonoAjustado, {
        style: { color: '#00ff00' }
    }).addTo(mapManager.getMap()).bindPopup('Ajustado');
}

// ============================================================
// EXEMPLO 5: Toggle de visibilidade CAR
// ============================================================

function toggleVisibilidadeCAR() {
    console.log('=== EXEMPLO 5: Toggle Visibilidade ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    
    // Alternar visibilidade
    carIntegration.toggleCARVisibility(mapManager);
    
    console.log('✅ Visibilidade CAR alternada');
}

// ============================================================
// EXEMPLO 6: Exportar CAR como GeoJSON
// ============================================================

function exportarCARComoGeoJSON() {
    console.log('=== EXEMPLO 6: Exportar GeoJSON ===');
    
    const carIntegration = window.carIntegration;
    
    // Exportar
    const geojson = carIntegration.exportCARAsGeoJSON();
    
    console.log('✅ GeoJSON exportado:', geojson);
    
    // Salvar em arquivo
    const dataStr = JSON.stringify(geojson, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'car-export.geojson';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    console.log('✅ Arquivo GeoJSON baixado');
}

// ============================================================
// EXEMPLO 7: Limpar todos os polígonos CAR
// ============================================================

function limparTodoCAR() {
    console.log('=== EXEMPLO 7: Limpar CAR ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    
    // Limpar
    carIntegration.clearCAR(mapManager);
    
    console.log('✅ Todos os polígonos CAR removidos');
}

// ============================================================
// EXEMPLO 8: Ativação completa do sistema CAR
// ============================================================

async function ativarSistemaCAR() {
    console.log('=== EXEMPLO 8: Ativação Completa ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    const uiController = window.uiController;
    
    try {
        // Ativar sistema completo
        await carIntegration.activateCAR(mapManager, uiController);
        
        console.log('✅ Sistema CAR ativado com sucesso');
        
    } catch (error) {
        console.error('❌ Erro ao ativar CAR:', error);
    }
}

// ============================================================
// EXEMPLO 9: Informações detalhadas de um polígono CAR
// ============================================================

function infoDetalhadaCAR(codCAR) {
    console.log('=== EXEMPLO 9: Info Detalhada ===');
    
    const carIntegration = window.carIntegration;
    
    // Buscar feature pelo código CAR
    const feature = carIntegration.carLayers.find(layer => {
        return layer.feature.properties.cod_car === codCAR;
    });
    
    if (!feature) {
        console.warn(`⚠️ CAR ${codCAR} não encontrado`);
        return;
    }
    
    const props = feature.feature.properties;
    
    console.log('📋 Informações do CAR:');
    console.log('  Código:', props.cod_car);
    console.log('  Proprietário:', props.nom_propri);
    console.log('  Município:', props.nom_munici);
    console.log('  UF:', props.sig_uf);
    console.log('  Área:', props.num_area, 'ha');
    console.log('  Status:', props.des_condi);
    console.log('  Data Cadastro:', props.dat_cadas);
}

// ============================================================
// EXEMPLO 10: Workflow completo - Da busca ao ajuste
// ============================================================

async function workflowCompleto() {
    console.log('=== EXEMPLO 10: Workflow Completo ===');
    
    const carIntegration = window.carIntegration;
    const mapManager = window.mapManager;
    const polygonTools = window.polygonTools;
    
    try {
        // 1. Carregar CAR
        console.log('1️⃣ Carregando CAR...');
        const features = await carIntegration.loadCARForCurrentView(
            mapManager.getMap(),
            'MS'
        );
        console.log(`   ✅ ${features.length} polígonos carregados`);
        
        // 2. Adicionar ao mapa
        console.log('2️⃣ Adicionando ao mapa...');
        carIntegration.addCARToMap(features, mapManager);
        console.log('   ✅ Polígonos exibidos');
        
        // 3. Definir área de interesse
        console.log('3️⃣ Definindo área de interesse...');
        const areaInteresse = {
            type: 'Polygon',
            coordinates: [[
                [-54.5, -20.5],
                [-54.5, -20.3],
                [-54.3, -20.3],
                [-54.3, -20.5],
                [-54.5, -20.5]
            ]]
        };
        
        // 4. Buscar intersecções
        console.log('4️⃣ Buscando intersecções...');
        const intersectantes = await carIntegration.findIntersectingCAR(
            areaInteresse,
            mapManager
        );
        console.log(`   ✅ ${intersectantes.length} intersecções encontradas`);
        
        // 5. Ajustar polígono
        console.log('5️⃣ Ajustando polígono...');
        const ajustado = await carIntegration.adjustPolygonToCAR(
            areaInteresse,
            mapManager,
            polygonTools
        );
        console.log('   ✅ Polígono ajustado');
        
        // 6. Exportar resultado
        console.log('6️⃣ Exportando resultado...');
        const geojson = {
            type: 'FeatureCollection',
            features: [
                { type: 'Feature', geometry: ajustado, properties: { tipo: 'ajustado' } },
                ...intersectantes
            ]
        };
        console.log('   ✅ GeoJSON pronto para exportação');
        
        console.log('\n🎉 Workflow completo finalizado!');
        return geojson;
        
    } catch (error) {
        console.error('❌ Erro no workflow:', error);
        throw error;
    }
}

// ============================================================
// DISPONIBILIZAR NO CONSOLE
// ============================================================

window.CARExamples = {
    exemploBasico,
    carregarMultiplosEstados,
    buscarCARIntersectante,
    ajustarPoligonoAoCAR,
    toggleVisibilidadeCAR,
    exportarCARComoGeoJSON,
    limparTodoCAR,
    ativarSistemaCAR,
    infoDetalhadaCAR,
    workflowCompleto
};

console.log(`
╔════════════════════════════════════════════════════════════╗
║           EXEMPLOS CAR - MapCarteiras v2.0                 ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  Use no console:                                           ║
║                                                            ║
║  CARExamples.exemploBasico()              - Básico         ║
║  CARExamples.carregarMultiplosEstados()   - Multi-Estado   ║
║  CARExamples.buscarCARIntersectante()     - Interseção     ║
║  CARExamples.ajustarPoligonoAoCAR()       - Ajuste         ║
║  CARExamples.toggleVisibilidadeCAR()      - Toggle         ║
║  CARExamples.exportarCARComoGeoJSON()     - Exportar       ║
║  CARExamples.limparTodoCAR()              - Limpar         ║
║  CARExamples.ativarSistemaCAR()           - Ativar         ║
║  CARExamples.infoDetalhadaCAR(codigo)     - Info           ║
║  CARExamples.workflowCompleto()           - Workflow       ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
`);
