/**
 * ═══════════════════════════════════════════════════════════════════════════
 * MapCarteiras v2.0 - Sistema de Gestão de Territórios com CAR
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * CONFIGURAÇÃO:
 * Este arquivo lê as credenciais de js/env.js (window.ENV)
 *
 * Para configurar o ambiente:
 * 1. Copie js/env.example.js para js/env.js
 * 2. Configure as credenciais em env.js
 * 3. O env.js não é commitado no git (está no .gitignore)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 */

// Verificar se ENV está definido
if (typeof window.ENV === 'undefined') {
    console.error('⚠️ ERRO: Arquivo env.js não carregado!');
    console.error('Por favor, copie js/env.example.js para js/env.js e configure suas credenciais.');
    window.ENV = {
        SUPABASE_URL: '',
        SUPABASE_SERVICE_ROLE_KEY: '',
        DEBUG: true
    };
}

const CONFIG = {
    // ═══════════════════════════════════════════════════════════════════════
    // SUPABASE CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════
    // Credenciais lidas de env.js
    // ═══════════════════════════════════════════════════════════════════════
    supabase: {
        url: window.ENV.SUPABASE_URL,
        serviceRoleKey: window.ENV.SUPABASE_SERVICE_ROLE_KEY
    },

    // Database Schema Configuration
    database: {
        schema: 'territorio',
        tables: {
            properties: 'api_properties',      // View: public.api_properties -> territorio.properties
            territories: 'api_territories',    // View: public.api_territories -> territorio.territories
            subTerritories: 'api_sub_territories' // View: public.api_sub_territories -> territorio.sub_territories
        }
    },

    // Map Configuration
    map: {
        center: [-15.7801, -47.9292], // Brasília, Brasil
        zoom: 5,
        minZoom: 3,
        maxZoom: 20,

        // Tile Layers
        layers: {
            openStreetMap: {
                name: 'OpenStreetMap',
                url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            },
            satellite: {
                name: 'Satélite Híbrido (ESRI)',
                url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
                labelsUrl: 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
                attribution: '&copy; Esri'
            },
            googleSat: {
                name: 'Google Satélite',
                url: 'https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}',
                attribution: '&copy; Google'
            },
            googleHybrid: {
                name: 'Google Híbrido',
                url: 'https://mt0.google.com/vt/lyrs=y&hl=en&x={x}&y={y}&z={z}',
                attribution: '&copy; Google'
            }
        }
    },

    // ═══════════════════════════════════════════════════════════════════════
    // CAR (CADASTRO AMBIENTAL RURAL) INTEGRATION
    // ═══════════════════════════════════════════════════════════════════════
    car: {
        wfsUrl: 'https://geoserver.car.gov.br/geoserver/sicar/ows',
        states: ['ms', 'mt', 'pr', 'rs', 'sc', 'go', 'sp', 'mg'],
        stateMapping: {
            'MS': 'ms',
            'MT': 'mt',
            'PR': 'pr',
            'RS': 'rs',
            'SC': 'sc',
            'GO': 'go',
            'SP': 'sp',
            'MG': 'mg'
        },
        regionMapping: {
            'Região MS': 'ms',
            'Região MT': 'mt',
            'Região PR I': 'pr',
            'Região PR II': 'pr',
            'Região PR III': 'pr',
            'Região RS': 'rs',
            'Região SC': 'sc',
            'Região GO': 'go',
            'Região SP': 'sp',
            'Região MG': 'mg'
        },
        maxFeatures: 10000,
        outputFormat: 'application/json',
        typeNamePrefix: 'sicar:sicar_imoveis_'
    },

    // ═══════════════════════════════════════════════════════════════════════
    // POLYGON TOOLS CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════
    polygonTools: {
        smoothing: {
            resolution: 10000,
            sharpness: 0.85
        },
        snapTolerance: 0.01,
        dentalMaxDistance: 50,
        dentalMaxAngle: 160,
        bufferDefaultDistance: 10,
        validateArea: true,
        minAreaHectares: 0.1
    },

    // ═══════════════════════════════════════════════════════════════════════
    // UI CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════
    ui: {
        colors: {
            property: '#3388ff',
            territory: '#ff7800',
            subTerritory: '#00ff00',
            car: '#ff0000'
        },
        opacity: {
            fill: 0.2,
            stroke: 0.8
        },
        notifications: {
            duration: 3000,
            position: 'top-right'
        }
    },

    // ═══════════════════════════════════════════════════════════════════════
    // DEBUG MODE (lido de env.js)
    // ═══════════════════════════════════════════════════════════════════════
    debug: window.ENV.DEBUG || false
};

// Make config globally available
window.CONFIG = CONFIG;

// Log de inicialização
if (CONFIG.debug) {
    console.log('✅ CONFIG carregado');
    console.log('   Supabase URL:', CONFIG.supabase.url || '(não configurado)');
}

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
