/**
 * Data Manager - Gerenciamento de Dados com Supabase
 * MapCarteiras v2.0
 */

class DataManager {
    constructor() {
        this.supabase = null;
        this.currentProperty = null;
        this.init();
    }

    /**
     * Inicializa cliente Supabase com Service Role Key
     */
    init() {
        try {
            const { createClient } = supabase;
            
            // Use service role key for full database access
            this.supabase = createClient(
                CONFIG.supabase.url,
                CONFIG.supabase.serviceRoleKey,
                {
                    auth: {
                        autoRefreshToken: false,
                        persistSession: false
                    }
                }
            );

            console.log('✅ DataManager inicializado com Service Role');
            console.log('📊 Schema:', CONFIG.database.schema);
        } catch (error) {
            console.error('❌ Erro ao inicializar Supabase:', error);
            console.warn('⚠️ Configure as credenciais do Supabase em js/config.js');
        }
    }

    /**
     * Verifica se Supabase está configurado
     */
    isConfigured() {
        return this.supabase !== null && 
               CONFIG.supabase.serviceRoleKey && 
               CONFIG.supabase.serviceRoleKey.length > 20;
    }

    // ==================== PROPERTIES ====================

    /**
     * Cria nova propriedade
     * Usa a estrutura: territorio.properties via api_properties view
     */
    async createProperty(data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data: property, error } = await this.supabase
                .from(CONFIG.database.tables.properties)
                .insert({
                    owner: data.ownerName,           // owner VARCHAR(255)
                    owner_bpid: data.ownerBPID,      // owner_bpid VARCHAR(20)
                    name: data.propertyName,         // name VARCHAR(255)
                    bpid: data.propertyBPID || '',   // bpid VARCHAR(20)
                    stnm: data.stnm || '',           // stnm VARCHAR(20)
                    region: data.region || null,     // region VARCHAR(100)
                    center: data.center || null,     // center VARCHAR(100)
                    center_key: data.centerKey || null // center_key VARCHAR(10)
                })
                .select()
                .single();

            if (error) throw error;

            console.log('✅ Propriedade criada:', property);
            this.currentProperty = property;
            return property;

        } catch (error) {
            console.error('❌ Erro ao criar propriedade:', error);
            throw error;
        }
    }

    /**
     * Lista todas as propriedades
     */
    async listProperties() {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data, error } = await this.supabase
                .from(CONFIG.database.tables.properties)
                .select('*')
                .order('created_at', { ascending: false });

            if (error) throw error;

            console.log(`📋 ${data.length} propriedades carregadas`);
            return data;

        } catch (error) {
            console.error('❌ Erro ao listar propriedades:', error);
            throw error;
        }
    }

    /**
     * Obtém propriedade por ID
     */
    async getProperty(id) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data, error } = await this.supabase
                .from(CONFIG.database.tables.properties)
                .select('*')
                .eq('id', id)
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('❌ Erro ao obter propriedade:', error);
            throw error;
        }
    }

    /**
     * Atualiza propriedade
     */
    async updateProperty(id, data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data: updated, error } = await this.supabase
                .from(CONFIG.database.tables.properties)
                .update(data)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;

            console.log('✅ Propriedade atualizada');
            return updated;

        } catch (error) {
            console.error('❌ Erro ao atualizar propriedade:', error);
            throw error;
        }
    }

    /**
     * Deleta propriedade (CASCADE deleta territórios e sub_territories)
     */
    async deleteProperty(id) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { error } = await this.supabase
                .from(CONFIG.database.tables.properties)
                .delete()
                .eq('id', id);

            if (error) throw error;

            console.log('🗑️ Propriedade deletada (CASCADE)');

        } catch (error) {
            console.error('❌ Erro ao deletar propriedade:', error);
            throw error;
        }
    }

    // ==================== TERRITORIES ====================

    /**
     * Verifica se há sobreposição com territórios existentes no banco de dados
     * Usa PostGIS ST_Intersects para verificação precisa
     * @param {Object} geometry - GeoJSON do novo território
     * @param {String} excludeTerritoryId - ID do território a excluir da verificação (para edição)
     * @returns {Object} { hasOverlap: boolean, overlappingTerritories: [] }
     */
    async checkTerritoryOverlap(geometry, excludeTerritoryId = null) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log('🔍 Verificando sobreposição no banco de dados...');

            // Usar RPC (Remote Procedure Call) para executar função PostGIS customizada
            const { data, error } = await this.supabase
                .rpc('check_territory_overlap', {
                    new_geometry: geometry,
                    exclude_id: excludeTerritoryId
                });

            if (error) {
                console.error('❌ Erro ao verificar sobreposição:', error);
                throw error;
            }

            console.log('✅ Resultado da verificação:', data);

            return {
                hasOverlap: data && data.length > 0,
                overlappingTerritories: data || []
            };

        } catch (error) {
            console.error('❌ Erro ao verificar sobreposição:', error);
            throw error;
        }
    }

    /**
     * Cria novo território
     * Estrutura: territorio.territories via api_territories view
     */
    async createTerritory(data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            // ========================================
            // VALIDAÇÃO DE SOBREPOSIÇÃO NO BANCO
            // ========================================
            // NOTA: Função PostgreSQL check_territory_overlap precisa ser instalada primeiro
            // Execute: migrations/004_check_territory_overlap_function.sql
            // 
            // try {
            //     console.log('🔐 VALIDAÇÃO FINAL: Verificando sobreposição no banco de dados...');
            //     
            //     const overlapCheck = await this.checkTerritoryOverlap(data.geometry);
            //     
            //     if (overlapCheck.hasOverlap) {
            //         const overlappingNames = overlapCheck.overlappingTerritories
            //             .map(t => t.territory_id)
            //             .join(', ');
            //         
            //         console.error('🚫 SOBREPOSIÇÃO DETECTADA NO BANCO!');
            //         console.error('   Territórios sobrepostos:', overlappingNames);
            //         
            //         throw new Error(`❌ BLOQUEIO DE SALVAMENTO: O território sobrepõe os seguintes territórios existentes: ${overlappingNames}. Aplique TRIM antes de salvar.`);
            //     }
            //     
            //     console.log('✅ Sem sobreposição - prosseguindo com salvamento...');
            // } catch (error) {
            //     console.warn('⚠️ Validação no banco desabilitada - função PostgreSQL não encontrada');
            //     console.warn('   Execute migrations/004_check_territory_overlap_function.sql');
            // }

            const insertData = {
                territory_id: data.territory_id,           // Ex: C089
                name: data.name,
                region_name: data.region_name || null,     // Região MS, MT, etc
                center_name: data.center_name || null,     // Nome do centro
                center_key: data.center_key || null,       // Centro Chave (ex: C089)
                geometry: data.geometry,                   // GeoJSON
                area_hectares: data.area_hectares,
                aprovacao_regional: data.aprovacao_regional || false,
                aprovacao_departamento: data.aprovacao_departamento || false
            };

            // Se property_id for fornecido (compatibilidade)
            if (data.property_id) {
                insertData.property_id = data.property_id;
                insertData.area_key = data.areaKey || 1;
            }

            console.log('📤 Enviando território para Supabase:', insertData);
            console.log('📋 Tabela:', CONFIG.database.tables.territories);

            // Usar RPC para UPSERT que lida com registros deletados
            // A VIEW api_territories exclui is_deleted=true, mas a constraint unique ainda existe
            console.log('🔄 Tentando salvar território via RPC upsert_territory...');

            let territory, error;

            // Tentar via RPC primeiro (mais robusto)
            try {
                const { data: rpcResult, error: rpcError } = await this.supabase.rpc('upsert_territory', {
                    p_territory_id: insertData.territory_id,
                    p_name: insertData.name,
                    p_region_name: insertData.region_name,
                    p_center_name: insertData.center_name,
                    p_center_key: insertData.center_key,
                    p_geometry: insertData.geometry,
                    p_area_hectares: insertData.area_hectares,
                    p_aprovacao_regional: insertData.aprovacao_regional || false,
                    p_aprovacao_departamento: insertData.aprovacao_departamento || false,
                    p_property_id: insertData.property_id || null
                });

                if (!rpcError && rpcResult) {
                    console.log('✅ Território salvo via RPC:', rpcResult);
                    territory = rpcResult;
                    error = null;
                } else {
                    throw rpcError || new Error('RPC retornou null');
                }
            } catch (rpcErr) {
                console.warn('⚠️ RPC upsert_territory não disponível, usando método alternativo...');
                console.warn('   Erro:', rpcErr.message || rpcErr);

                // Método alternativo: verificar na VIEW e fazer INSERT ou UPDATE
                const { data: existing } = await this.supabase
                    .from(CONFIG.database.tables.territories)
                    .select('id')
                    .eq('territory_id', insertData.territory_id)
                    .maybeSingle();

                if (existing) {
                    // UPDATE - território visível na VIEW (não deletado)
                    console.log('🔄 Território encontrado na VIEW (ID:', existing.id, ') - Atualizando...');
                    const updateData = {
                        ...insertData,
                        updated_at: new Date().toISOString()
                    };

                    const result = await this.supabase
                        .from(CONFIG.database.tables.territories)
                        .update(updateData)
                        .eq('id', existing.id)
                        .select()
                        .single();
                    territory = result.data;
                    error = result.error;
                } else {
                    // Território não existe na VIEW - pode ser novo OU estar deletado
                    // Tentar UPSERT que deve funcionar se a VIEW tiver trigger
                    console.log('➕ Território não visível na VIEW - Tentando UPSERT...');

                    // Adicionar campos para reativar caso esteja deletado
                    const upsertData = {
                        ...insertData,
                        is_deleted: false,
                        deleted_at: null,
                        updated_at: new Date().toISOString()
                    };

                    // Tentar upsert com ignoreDuplicates para evitar erro
                    const result = await this.supabase
                        .from(CONFIG.database.tables.territories)
                        .upsert(upsertData, {
                            onConflict: 'territory_id',
                            ignoreDuplicates: false
                        })
                        .select()
                        .single();

                    territory = result.data;
                    error = result.error;

                    // Se upsert falhar com 409 (conflict), tentar abordagem diferente
                    if (error && error.code === '23505') {
                        console.log('⚠️ Conflito de chave - território existe mas está invisível (deletado)');
                        console.log('   Por favor, execute a migration 011_upsert_territory_function.sql');
                        console.log('   Ou restaure manualmente o território no banco de dados');
                        error = new Error(`Território ${insertData.territory_id} está marcado como deletado no banco. Use a função de restauração ou execute: UPDATE territorio.territories SET is_deleted = false, deleted_at = null WHERE territory_id = '${insertData.territory_id}'`);
                    }
                }
            }

            if (error) {
                console.error('❌ Erro detalhado do Supabase:');
                console.error('  - Código:', error.code);
                console.error('  - Mensagem:', error.message);
                console.error('  - Detalhes:', error.details);
                console.error('  - Hint:', error.hint);
                console.error('  - Objeto completo:', error);
                throw error;
            }

            console.log('✅ Território salvo:', territory);
            return territory;

        } catch (error) {
            console.error('❌ Erro ao criar território:', error);
            console.error('Dados enviados:', data);
            throw error;
        }
    }

    /**
     * Lista territórios de uma propriedade (ou todos se propertyId for null)
     */
    async listTerritories(propertyId = null) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            let query = this.supabase
                .from(CONFIG.database.tables.territories)
                .select('*');

            if (propertyId) {
                query = query.eq('property_id', propertyId);
            }

            query = query.order('created_at', { ascending: false });

            const { data, error } = await query;

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('❌ Erro ao listar territórios:', error);
            throw error;
        }
    }

    /**
     * Busca todos os territórios existentes para visualização em segundo plano
     * Retorna geometrias simplificadas para melhor performance
     */
    async getAllTerritoriesForBackground() {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log('🔍 Buscando territórios existentes para visualização...');

            // Usar RPC para simplificar geometrias no servidor (muito mais rápido)
            const { data, error } = await this.supabase
                .rpc('get_simplified_territories', {
                    tolerance: 0.0001 // ~10m de tolerância para simplificação
                });

            if (error) {
                // Fallback: se RPC não existir, usar query normal mas limitar
                console.warn('⚠️ RPC não disponível, usando query padrão limitada');
                const { data: fallbackData, error: fallbackError } = await this.supabase
                    .from(CONFIG.database.tables.territories)
                    .select('id, territory_id, name, geometry, area_hectares, region_name, center_name')
                    .limit(50) // Limitar a 50 territórios para não travar
                    .order('created_at', { ascending: true });

                if (fallbackError) throw fallbackError;
                console.log(`✅ ${fallbackData.length} territórios encontrados (modo limitado)`);
                return fallbackData || [];
            }

            console.log(`✅ ${data.length} territórios encontrados para visualização (simplificados)`);
            return data || [];

        } catch (error) {
            console.error('❌ Erro ao buscar territórios para background:', error);
            return [];
        }
    }

    /**
     * Atualiza território
     */
    async updateTerritory(id, data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data: updated, error } = await this.supabase
                .from(CONFIG.database.tables.territories)
                .update(data)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;

            console.log('✅ Território atualizado');
            return updated;

        } catch (error) {
            console.error('❌ Erro ao atualizar território:', error);
            throw error;
        }
    }

    /**
     * Deleta território (CASCADE deleta sub_territories)
     */
    async deleteTerritory(id) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { error } = await this.supabase
                .from(CONFIG.database.tables.territories)
                .delete()
                .eq('id', id);

            if (error) throw error;

            console.log('🗑️ Território deletado (CASCADE)');

        } catch (error) {
            console.error('Erro ao deletar território:', error);
            throw error;
        }
    }

    // ==================== SUB TERRITORIES (CARTEIRAS) ====================

    /**
     * Cria nova carteira (sub-território)
     * Estrutura: territorio.sub_territories via api_sub_territories view
     * Usa RPC upsert_sub_territory para lidar com registros deletados
     */
    async createSubTerritory(territoryId, propertyId, data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const insertData = {
                territory_id: territoryId,
                property_id: propertyId,
                area_key: data.areaKey || 1,
                sub_area_key: data.subAreaKey || 1,
                carteira_id: data.carteiraId,          // Centro Chave + sufixo (ex: C089.01)
                name: data.name,
                geometry: data.geometry,               // GeoJSON
                coordinates: data.coordinates || null, // TEXT format
                area_hectares: data.area_hectares,
                aprovacao_regional: data.aprovacaoRegional || false,
                aprovacao_departamento: data.aprovacaoDepartamento || false
            };

            console.log('📤 Enviando sub-território para Supabase:', insertData);
            console.log('🔄 Tentando salvar sub-território via RPC upsert_sub_territory...');

            let subTerritory, error;

            // Tentar via RPC primeiro (mais robusto - lida com registros deletados)
            // NOTA: Ordem dos parâmetros deve corresponder à função SQL (obrigatórios primeiro)
            try {
                const { data: rpcResult, error: rpcError } = await this.supabase.rpc('upsert_sub_territory', {
                    p_territory_id: insertData.territory_id,
                    p_carteira_id: insertData.carteira_id,
                    p_name: insertData.name,
                    p_property_id: insertData.property_id || null,
                    p_area_key: insertData.area_key,
                    p_sub_area_key: insertData.sub_area_key,
                    p_geometry: insertData.geometry,
                    p_coordinates: insertData.coordinates,
                    p_area_hectares: insertData.area_hectares,
                    p_aprovacao_regional: insertData.aprovacao_regional,
                    p_aprovacao_departamento: insertData.aprovacao_departamento
                });

                if (!rpcError && rpcResult) {
                    console.log('✅ Sub-território salvo via RPC:', rpcResult);
                    subTerritory = rpcResult;
                    error = null;
                } else {
                    throw rpcError || new Error('RPC retornou null');
                }
            } catch (rpcErr) {
                console.warn('⚠️ RPC upsert_sub_territory não disponível, usando método alternativo...');
                console.warn('   Erro:', rpcErr.message || rpcErr);

                // Método alternativo: verificar na VIEW e fazer INSERT ou UPDATE
                const { data: existing } = await this.supabase
                    .from(CONFIG.database.tables.subTerritories)
                    .select('id')
                    .eq('carteira_id', insertData.carteira_id)
                    .maybeSingle();

                if (existing) {
                    // UPDATE - sub-território visível na VIEW (não deletado)
                    console.log('🔄 Sub-território encontrado na VIEW (ID:', existing.id, ') - Atualizando...');
                    const updateData = {
                        ...insertData,
                        updated_at: new Date().toISOString()
                    };

                    const result = await this.supabase
                        .from(CONFIG.database.tables.subTerritories)
                        .update(updateData)
                        .eq('id', existing.id)
                        .select()
                        .single();
                    subTerritory = result.data;
                    error = result.error;
                } else {
                    // Sub-território não existe na VIEW - pode ser novo OU estar deletado
                    console.log('➕ Sub-território não visível na VIEW - Tentando INSERT...');

                    const result = await this.supabase
                        .from(CONFIG.database.tables.subTerritories)
                        .insert(insertData)
                        .select()
                        .single();

                    subTerritory = result.data;
                    error = result.error;

                    // Se INSERT falhar com conflito, orientar sobre a migration
                    if (error && (error.code === '23505' || error.code === '409')) {
                        console.log('⚠️ Conflito de chave - sub-território existe mas está invisível (deletado)');
                        console.log('   Por favor, execute a migration 013_upsert_sub_territory_function.sql');
                        error = new Error(`Sub-território ${insertData.carteira_id} está marcado como deletado no banco. Execute a migration 013 ou restaure manualmente: UPDATE territorio.sub_territories SET is_deleted = false, deleted_at = null WHERE carteira_id = '${insertData.carteira_id}'`);
                    }
                }
            }

            if (error) {
                console.error('❌ Erro detalhado do Supabase:');
                console.error('  - Código:', error.code);
                console.error('  - Mensagem:', error.message);
                console.error('  - Detalhes:', error.details);
                throw error;
            }

            console.log('✅ Carteira criada:', subTerritory);
            return subTerritory;

        } catch (error) {
            console.error('❌ Erro ao criar carteira:', error);
            throw error;
        }
    }

    /**
     * Lista carteiras de um território
     */
    async listSubTerritories(territoryId) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data, error } = await this.supabase
                .from(CONFIG.database.tables.subTerritories)
                .select('*')
                .eq('territory_id', territoryId)
                .order('created_at', { ascending: false });

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('❌ Erro ao listar carteiras:', error);
            throw error;
        }
    }

    /**
     * Atualiza carteira
     */
    async updateSubTerritory(id, data) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { data: updated, error } = await this.supabase
                .from(CONFIG.database.tables.subTerritories)
                .update(data)
                .eq('id', id)
                .select()
                .single();

            if (error) throw error;

            console.log('✅ Carteira atualizada');
            return updated;

        } catch (error) {
            console.error('❌ Erro ao atualizar carteira:', error);
            throw error;
        }
    }

    /**
     * Deleta carteira
     */
    async deleteSubTerritory(id) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            const { error } = await this.supabase
                .from(CONFIG.database.tables.subTerritories)
                .delete()
                .eq('id', id);

            if (error) throw error;

            console.log('🗑️ Carteira deletada');

        } catch (error) {
            console.error('❌ Erro ao deletar carteira:', error);
            throw error;
        }
    }

    /**
     * Verifica sobreposição de sub-territórios dentro de um território
     * @param {Object} geometry - GeoJSON do novo sub-território
     * @param {String} territoryId - ID do território pai
     * @param {String} excludeSubTerritoryId - ID do sub-território a excluir (para edição)
     * @returns {Object} { hasOverlap: boolean, overlappingSubTerritories: Array }
     */
    async checkSubTerritoryOverlap(geometry, territoryId, excludeSubTerritoryId = null) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log('🔍 Verificando sobreposição de sub-território no banco de dados...');

            // Buscar sub-territórios do mesmo território pai
            let query = this.supabase
                .from(CONFIG.database.tables.subTerritories)
                .select('*')
                .eq('territory_id', territoryId);

            if (excludeSubTerritoryId) {
                query = query.neq('id', excludeSubTerritoryId);
            }

            const { data: subTerritories, error } = await query;

            if (error) throw error;

            if (!subTerritories || subTerritories.length === 0) {
                console.log('✅ Nenhum sub-território existente no território pai');
                return {
                    hasOverlap: false,
                    overlappingSubTerritories: []
                };
            }

            // Verificar sobreposição usando Turf.js no cliente
            const newGeo = typeof geometry === 'string' ? JSON.parse(geometry) : geometry;
            const overlapping = [];

            for (const subTerritory of subTerritories) {
                const existingGeo = typeof subTerritory.geometry === 'string' 
                    ? JSON.parse(subTerritory.geometry) 
                    : subTerritory.geometry;

                const intersects = turf.booleanIntersects(newGeo, existingGeo);
                
                if (intersects) {
                    overlapping.push({
                        id: subTerritory.id,
                        carteira_id: subTerritory.carteira_id,
                        name: subTerritory.name,
                        area_hectares: subTerritory.area_hectares,
                        geometry: subTerritory.geometry  // ✅ INCLUIR GEOMETRIA
                    });
                }
            }

            console.log(`✅ Verificação concluída: ${overlapping.length} sobreposições encontradas`);

            return {
                hasOverlap: overlapping.length > 0,
                overlappingSubTerritories: overlapping
            };

        } catch (error) {
            console.error('❌ Erro ao verificar sobreposição de sub-território:', error);
            throw error;
        }
    }

    /**
     * Busca território completo com seus sub-territórios
     * @param {String} territoryId - ID do território
     * @returns {Object} Território com sub-territórios incluídos
     */
    async getTerritoryWithSubTerritories(territoryId) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            // Buscar território
            const { data: territory, error: territoryError } = await this.supabase
                .from(CONFIG.database.tables.territories)
                .select('*')
                .eq('id', territoryId)
                .single();

            if (territoryError) throw territoryError;

            // Buscar sub-territórios
            const subTerritories = await this.listSubTerritories(territoryId);
            
            territory.subTerritories = subTerritories; // Usar camelCase
            territory.sub_territories = subTerritories; // Manter snake_case para compatibilidade

            console.log(`✅ Território carregado com ${subTerritories.length} sub-territórios`);
            return territory;

        } catch (error) {
            console.error('❌ Erro ao buscar território com sub-territórios:', error);
            throw error;
        }
    }

    // ==================== HELPER METHODS ====================

    /**
     * Carrega propriedade completa (com territórios e carteiras)
     */
    async loadCompleteProperty(propertyId) {
        try {
            const property = await this.getProperty(propertyId);
            const territories = await this.listTerritories(propertyId);

            // Carregar carteiras de cada território
            for (const territory of territories) {
                territory.sub_territories = await this.listSubTerritories(territory.id);
            }

            property.territories = territories;

            console.log('📦 Propriedade completa carregada');
            return property;

        } catch (error) {
            console.error('Erro ao carregar propriedade completa:', error);
            throw error;
        }
    }

    /**
     * Exporta todos os dados como JSON
     */
    async exportAllData() {
        try {
            const properties = await this.listProperties();
            
            // Carregar dados completos
            for (const property of properties) {
                property.territories = await this.listTerritories(property.id);
                
                for (const territory of property.territories) {
                    territory.sub_territories = await this.listSubTerritories(territory.id);
                }
            }

            return properties;

        } catch (error) {
            console.error('Erro ao exportar dados:', error);
            throw error;
        }
    }

    /**
     * Busca áreas (propriedades) por consultor para exibição no mapa
     * Retorna dados agrupados por consultor com geometrias das áreas
     * @param {string} consultorName - Nome do consultor
     * @returns {Object} Objeto com data (array de áreas) e error
     */
    async getAreasByConsultor(consultorName) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`🔍 Buscando áreas por consultor: ${consultorName}`);

            // 🚀 UMA ÚNICA CHAMADA RPC - O banco faz todos os joins!
            const { data, error } = await this.supabase.rpc('get_areas_by_consultor', {
                p_consultor_name: consultorName
            });

            if (error) {
                console.error('❌ Erro ao buscar áreas:', error);
                throw error;
            }

            if (!data || data.length === 0) {
                console.log('⚠️ Nenhuma área encontrada para este consultor');
                return { data: [], error: null };
            }

            console.log(`✅ ${data.length} áreas encontradas para consultor ${consultorName}`);

            // Debug: ver estrutura do primeiro registro
            if (data.length > 0) {
                console.log('📝 Estrutura do primeiro registro:', data[0]);
                console.log('📝 Tipo de area_location:', typeof data[0].area_location);
            }

            // Converter para formato esperado pelo mapa
            const result = data.map(row => {
                // Converter WKB hex para GeoJSON
                let location = row.area_location;
                if (typeof location === 'string') {
                    try {
                        // Usar o conversor WKB
                        location = window.WKBConverter.wkbHexToGeoJSON(location);
                    } catch (error) {
                        console.error('❌ Erro ao converter WKB:', error, 'WKB:', location.substring(0, 50));
                        return null;
                    }
                }
                
                // NÃO aplicar simplificação aqui - polígonos do banco devem permanecer como estão
                // Simplificação é aplicada APENAS em polígonos novos/editados no assistente
                
                // Buscar nome do centro a partir da chave
                let centroNome = row.centro_chave;
                if (window.RegionCenterUtils) {
                    const centerInfo = window.RegionCenterUtils.getCenterByChave(row.centro_chave);
                    if (centerInfo) {
                        centroNome = centerInfo.centro;
                    }
                }
                
                return {
                    location: location,
                    centro_chave: row.centro_chave,
                    centro_nome: centroNome,  // Nome real do centro
                    cliente: row.cliente_nome || 'Sem Cliente',
                    consultor: row.consultor || 'Sem Consultor',
                    insumos: row.customer_share_insumos || 0,
                    graos: row.customer_share_graos || 0,
                    tempo_atendimento: row.tempo_atendimento || 0,
                    regiao: row.regiao
                };
            }).filter(Boolean); // Remover nulls

            console.log(`✅ ${result.length} áreas processadas para visualização`);
            return { data: result, error: null };

        } catch (error) {
            console.error('❌ Erro ao buscar áreas por consultor:', error);
            return { data: [], error: error };
        }
    }

    /**
     * Busca áreas (propriedades) por unidade (centro) para exibição no mapa
     * Carrega todas as propriedades da região, mas usa cores e legendas de Centro
     * @param {string} centerKey - Chave do centro (ex: 'C001')
     * @returns {Object} Objeto com data (array de áreas) e error
     */
    async getAreasByUnidade(centerKey) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`🔍 Buscando áreas por unidade para centro: ${centerKey}`);

            // 🚀 UMA ÚNICA CHAMADA RPC - O banco faz todos os joins!
            const { data, error } = await this.supabase.rpc('get_areas_by_centro', {
                p_centro_chave: centerKey
            });

            if (error) {
                console.error('❌ Erro ao buscar áreas:', error);
                throw error;
            }

            if (!data || data.length === 0) {
                console.log('⚠️ Nenhuma área encontrada para este centro');
                return { data: [], error: null };
            }

            console.log(`✅ ${data.length} áreas encontradas para centro ${centerKey}`);

            // Debug: ver estrutura do primeiro registro
            if (data.length > 0) {
                console.log('📝 Estrutura do primeiro registro:', data[0]);
                console.log('📝 Tipo de area_location:', typeof data[0].area_location);
                console.log('📝 Conteúdo area_location:', data[0].area_location);
            }

            // Converter para formato esperado pelo mapa
            const result = data.map(row => {
                // Converter WKB hex para GeoJSON
                let location = row.area_location;
                if (typeof location === 'string') {
                    try {
                        // Usar o conversor WKB
                        location = window.WKBConverter.wkbHexToGeoJSON(location);
                    } catch (error) {
                        console.error('❌ Erro ao converter WKB:', error, 'WKB:', location.substring(0, 50));
                        return null;
                    }
                }
                
                // NÃO aplicar simplificação aqui - polígonos do banco devem permanecer como estão
                // Simplificação é aplicada APENAS em polígonos novos/editados no assistente
                
                // Buscar nome do centro a partir da chave
                let centroNome = row.centro_chave;
                if (window.RegionCenterUtils) {
                    const centerInfo = window.RegionCenterUtils.getCenterByChave(row.centro_chave);
                    if (centerInfo) {
                        centroNome = centerInfo.centro;
                    }
                }
                
                return {
                    location: location,
                    centro_chave: row.centro_chave,
                    centro_nome: centroNome,  // Nome real do centro
                    cliente: row.cliente_nome || 'Sem Cliente',
                    consultor: row.consultor || 'Sem Consultor',
                    insumos: row.customer_share_insumos || 0,
                    graos: row.customer_share_graos || 0,
                    tempo_atendimento: row.tempo_atendimento || 0,
                    regiao: row.regiao
                };
            }).filter(Boolean); // Remover nulls

            console.log(`✅ ${result.length} áreas processadas para visualização`);
            return { data: result, error: null };

        } catch (error) {
            console.error('❌ Erro ao buscar áreas por unidade:', error);
            return { data: [], error: error };
        }
    }

    // ==================== HISTÓRICO E VERSIONAMENTO ====================

    /**
     * Obtém histórico de versões de um território
     * @param {string} territoryId - UUID do território
     * @returns {Array} Lista de versões do território
     */
    async getTerritoryHistory(territoryId) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`📜 Buscando histórico do território: ${territoryId}`);

            const { data, error } = await this.supabase.rpc('get_territory_history', {
                p_territory_id: territoryId
            });

            if (error) {
                console.error('❌ Erro ao buscar histórico:', error);
                throw error;
            }

            console.log(`✅ ${data?.length || 0} versões encontradas`);
            return data || [];

        } catch (error) {
            console.error('❌ Erro ao buscar histórico do território:', error);
            throw error;
        }
    }

    /**
     * Obtém histórico de versões de um sub-território (carteira)
     * @param {string} subTerritoryId - UUID do sub-território
     * @returns {Array} Lista de versões do sub-território
     */
    async getSubTerritoryHistory(subTerritoryId) {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`📜 Buscando histórico do sub-território: ${subTerritoryId}`);

            const { data, error } = await this.supabase.rpc('get_sub_territory_history', {
                p_sub_territory_id: subTerritoryId
            });

            if (error) {
                console.error('❌ Erro ao buscar histórico:', error);
                throw error;
            }

            console.log(`✅ ${data?.length || 0} versões encontradas`);
            return data || [];

        } catch (error) {
            console.error('❌ Erro ao buscar histórico do sub-território:', error);
            throw error;
        }
    }

    /**
     * Restaura uma versão específica de um território
     * @param {string} historyId - UUID do registro de histórico
     * @param {string} user - Usuário que está restaurando (opcional)
     * @returns {Object} Resultado da restauração
     */
    async restoreTerritoryVersion(historyId, user = 'system') {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`🔄 Restaurando versão do território: ${historyId}`);

            const { data, error } = await this.supabase.rpc('restore_territory_version', {
                p_history_id: historyId,
                p_user: user
            });

            if (error) {
                console.error('❌ Erro ao restaurar versão:', error);
                throw error;
            }

            console.log('✅ Versão restaurada:', data);
            return data;

        } catch (error) {
            console.error('❌ Erro ao restaurar versão do território:', error);
            throw error;
        }
    }

    /**
     * Restaura uma versão específica de um sub-território
     * @param {string} historyId - UUID do registro de histórico
     * @param {string} user - Usuário que está restaurando (opcional)
     * @returns {Object} Resultado da restauração
     */
    async restoreSubTerritoryVersion(historyId, user = 'system') {
        try {
            if (!this.isConfigured()) {
                throw new Error('Supabase não configurado');
            }

            console.log(`🔄 Restaurando versão do sub-território: ${historyId}`);

            const { data, error } = await this.supabase.rpc('restore_sub_territory_version', {
                p_history_id: historyId,
                p_user: user
            });

            if (error) {
                console.error('❌ Erro ao restaurar versão:', error);
                throw error;
            }

            console.log('✅ Versão restaurada:', data);
            return data;

        } catch (error) {
            console.error('❌ Erro ao restaurar versão do sub-território:', error);
            throw error;
        }
    }
}

// Export
window.DataManager = DataManager;
