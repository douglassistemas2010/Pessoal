/**
 * ═══════════════════════════════════════════════════════════════════════════
 * VARIÁVEIS DE AMBIENTE - MapCarteiras v2.0
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * INSTRUÇÕES:
 * 1. Copie este arquivo para 'env.js' na mesma pasta
 * 2. Substitua os valores placeholder pelas suas credenciais
 * 3. O arquivo env.js NÃO deve ser commitado no git
 *
 * ═══════════════════════════════════════════════════════════════════════════
 */

window.ENV = {
    // ═══════════════════════════════════════════════════════════════════════
    // SUPABASE
    // ═══════════════════════════════════════════════════════════════════════
    // Para Supabase Cloud: https://[seu-projeto].supabase.co
    // Para Self-Hosted: http://[seu-servidor]:8000
    SUPABASE_URL: 'https://SEU-PROJETO.supabase.co',

    // Obtenha em: Settings > API > service_role key
    SUPABASE_SERVICE_ROLE_KEY: 'SUA_SERVICE_ROLE_KEY_AQUI',

    // ═══════════════════════════════════════════════════════════════════════
    // AMBIENTE
    // ═══════════════════════════════════════════════════════════════════════
    // Desativar em produção (false)
    DEBUG: false
};
