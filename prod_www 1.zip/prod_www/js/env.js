/**
 * ═══════════════════════════════════════════════════════════════════════════
 * VARIÁVEIS DE AMBIENTE - MapCarteiras v2.0
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ATENÇÃO: Este arquivo contém credenciais sensíveis!
 * NÃO commitar no repositório git.
 *
 * Para configurar:
 * 1. Copie env.example.js para env.js
 * 2. Substitua os valores pelas suas credenciais
 *
 * ═══════════════════════════════════════════════════════════════════════════
 */

window.ENV = {
    // ═══════════════════════════════════════════════════════════════════════
    // SUPABASE
    // ═══════════════════════════════════════════════════════════════════════
    SUPABASE_URL: 'http://xsn8nq01.cvale.com.br:8000',
    SUPABASE_SERVICE_ROLE_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIiwiaXNzIjoic3VwYWJhc2UiLCJpYXQiOjE3NTc5MDUyMDAsImV4cCI6MTkxNTY3MTYwMH0.9_c6rD9REQurr9gSc_pCi550lzCND_q_fWCd4fhSAAA',

    // ═══════════════════════════════════════════════════════════════════════
    // AMBIENTE
    // ═══════════════════════════════════════════════════════════════════════
    DEBUG: true
};
