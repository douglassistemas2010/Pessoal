/**
 * Map Manager - Gerenciamento do Mapa Leaflet
 * MapCarteiras v2.0
 */

class MapManager {
    constructor() {
        this.map = null;
        this.layers = {
            base: {},
            polygons: L.layerGroup(),
            car: L.layerGroup(),
            drawings: L.featureGroup(),
            consultores: L.layerGroup() // Camada para áreas por consultor
        };
        this.drawControl = null;
        this.currentPolygon = null;
        this.selectedPolygon = null;
        this.isDrawingSubTerritory = false; // Flag para indicar se está desenhando sub-território
        this.layerControl = null; // Controle de camadas do Leaflet
        this.consultoresLayerAdded = false; // Flag para evitar adicionar múltiplas vezes
        
        // Paleta de cores EXPANDIDA para centros/unidades (30 cores muito distintas)
        this.consultorColors = [
            '#FF0000', // Vermelho puro
            '#0000FF', // Azul puro
            '#00FF00', // Verde limão
            '#FF00FF', // Magenta
            '#00FFFF', // Ciano
            '#FF8C00', // Laranja escuro
            '#8B00FF', // Violeta
            '#00CED1', // Turquesa escuro
            '#FF1493', // Rosa profundo
            '#32CD32', // Verde limão
            '#FFD700', // Ouro
            '#DC143C', // Carmesim
            '#00FF7F', // Verde primavera
            '#FF69B4', // Rosa quente
            '#4169E1', // Azul royal
            '#FF4500', // Vermelho laranja
            '#9400D3', // Violeta escuro
            '#00FA9A', // Verde médio primavera
            '#FF6347', // Tomate
            '#4682B4', // Azul aço
            '#ADFF2F', // Verde amarelado
            '#FF00AB', // Rosa neon
            '#1E90FF', // Azul dodger
            '#FFB6C1', // Rosa claro
            '#00BFFF', // Azul céu profundo
            '#FFA500', // Laranja
            '#BA55D3', // Orquídea médio
            '#20B2AA', // Verde mar claro
            '#F08080', // Coral claro
            '#6495ED'  // Azul milho
        ];
        
        // Cores CHAMATIVAS para Territórios e Sub-Territórios (diferentes da paleta de consultores)
        this.territoryColors = {
            // Território: MAGENTA/PINK forte - muito chamativo e único
            territory: '#FF1493',      // Deep Pink (borda)
            territoryFill: '#FF69B4',  // Hot Pink (preenchimento mais claro)
            
            // Sub-Território: AMARELO/OURO - também chamativo e diferente
            subTerritory: '#FFD700',      // Gold (borda)
            subTerritoryFill: '#FFA500'   // Orange Gold (preenchimento)
        };
        
        this.init();
    }

    /**
     * Inicializa o mapa
     */
    init() {
        // Criar mapa
        this.map = L.map('map', {
            center: CONFIG.map.center,
            zoom: CONFIG.map.zoom,
            minZoom: CONFIG.map.minZoom,
            maxZoom: CONFIG.map.maxZoom,
            zoomControl: false,
            editable: true
        });

        // Criar pane customizado para CAR (z-index baixo = segundo plano)
        this.map.createPane('carPane');
        this.map.getPane('carPane').style.zIndex = 400; // Abaixo dos polígonos (default: 600)
        this.map.getPane('carPane').style.pointerEvents = 'auto'; // Permitir interação

        // Criar pane para áreas por consultor
        this.map.createPane('consultoresPane');
        this.map.getPane('consultoresPane').style.zIndex = 350;
        this.map.getPane('consultoresPane').style.pointerEvents = 'auto';

        // Criar pane para desenhos editáveis (PRIMEIRO PLANO - z-index alto)
        this.map.createPane('drawingsPane');
        this.map.getPane('drawingsPane').style.zIndex = 650; // Acima de tudo (default polygons: 600)
        this.map.getPane('drawingsPane').style.pointerEvents = 'auto';

        // Adicionar controle de zoom customizado
        L.control.zoom({
            position: 'topright'
        }).addTo(this.map);

        // Adicionar camadas base
        this.setupBaseLayers();

        // Adicionar camadas de polígonos
        this.layers.consultores.addTo(this.map); // Adicionar primeiro (mais ao fundo)
        this.layers.polygons.addTo(this.map);
        this.layers.car.addTo(this.map);
        this.layers.drawings.addTo(this.map);

        // Setup drawing controls
        this.setupDrawControls();

        // Setup event listeners
        this.setupEventListeners();

        // Adicionar escala
        L.control.scale({
            imperial: false,
            position: 'bottomleft'
        }).addTo(this.map);

        console.log('✅ Mapa inicializado');
    }

    /**
     * Configura as camadas base
     */
    setupBaseLayers() {
        // OpenStreetMap
        this.layers.base.osm = L.tileLayer(
            CONFIG.map.layers.openStreetMap.url,
            { attribution: CONFIG.map.layers.openStreetMap.attribution }
        ).addTo(this.map);

        // Satélite ESRI Híbrido (imagem + labels)
        const esriImagery = L.tileLayer(
            CONFIG.map.layers.satellite.url,
            { attribution: CONFIG.map.layers.satellite.attribution }
        );
        const esriLabels = L.tileLayer(
            CONFIG.map.layers.satellite.labelsUrl,
            { attribution: '' }
        );
        this.layers.base.satellite = L.layerGroup([esriImagery, esriLabels]);

        // Google Satélite
        this.layers.base.googleSat = L.tileLayer(
            CONFIG.map.layers.googleSat.url,
            { attribution: CONFIG.map.layers.googleSat.attribution }
        );

        // Camada ativa atual
        this.currentBaseLayer = 'osm';

        // Setup do seletor de camadas no header
        this.setupBaseLayerSelector();
    }

    /**
     * Configura o seletor de camadas base no header
     */
    setupBaseLayerSelector() {
        const select = document.getElementById('selectBaseLayer');
        if (!select) {
            console.warn('⚠️ Seletor de camadas não encontrado no header');
            return;
        }

        select.addEventListener('change', (e) => {
            const layerKey = e.target.value;
            this.changeBaseLayer(layerKey);
        });

        console.log('✅ Seletor de camadas configurado');
    }

    /**
     * Troca a camada base do mapa
     * @param {string} layerKey - Chave da camada (osm, satellite, googleSat)
     */
    changeBaseLayer(layerKey) {
        // Remover camada atual
        if (this.layers.base[this.currentBaseLayer]) {
            this.map.removeLayer(this.layers.base[this.currentBaseLayer]);
        }

        // Adicionar nova camada
        if (this.layers.base[layerKey]) {
            this.layers.base[layerKey].addTo(this.map);
            this.currentBaseLayer = layerKey;
            console.log(`🗺️ Camada base alterada para: ${layerKey}`);
        } else {
            console.warn(`⚠️ Camada ${layerKey} não encontrada`);
        }
    }

    /**
     * Configura controles de desenho
     */
    setupDrawControls() {
        // Configurar Leaflet.Draw
        this.drawControl = new L.Control.Draw({
            position: 'topright',
            draw: {
                polygon: {
                    allowIntersection: false,
                    showArea: true,
                    metric: ['ha', 'km']
                },
                polyline: false,
                rectangle: false,
                circle: false,
                marker: false,
                circlemarker: false
            },
            edit: {
                featureGroup: this.layers.drawings,
                remove: true
            }
        });

        // Não adicionar controle padrão (usaremos botões customizados)
        // this.map.addControl(this.drawControl);
    }

    /**
     * Configura event listeners
     */
    setupEventListeners() {
        const self = this;

        // Draw created
        this.map.on(L.Draw.Event.CREATED, async function(e) {
            const originalLayer = e.layer;
            
            // Desativar modo de desenho
            self.map._drawingMode = false;
            self.map.getContainer().style.cursor = '';
            console.log('📐 Novo polígono desenhado - modo de desenho desativado');
            
            // Limpar aviso de sobreposição em tempo real
            self.clearOverlapWarning();
            
            // DEBUG: Verificar estado dos territórios
            self.debugBackgroundTerritories();
            
            // VALIDAÇÃO CRÍTICA: Obter geometrias dos territórios existentes
            const existingGeometries = self.getExistingTerritoriesGeometries();
            
            console.log('🔍 VALIDAÇÃO FINAL DE SOBREPOSIÇÃO');
            console.log(`   - Territórios existentes para verificar: ${existingGeometries.length}`);
            
            if (existingGeometries.length > 0) {
                // Verificar se há sobreposição
                const overlapResult = self.checkOverlap(originalLayer, existingGeometries);
                
                if (overlapResult.hasOverlap) {
                    console.error(`❌ SOBREPOSIÇÃO CONFIRMADA com ${overlapResult.overlappedTerritories.length} território(s)!`);
                    console.error('   Territórios sobrepostos:', overlapResult.overlappedTerritories.map(t => t.properties.territory_id));
                    
                    // Se estiver desenhando SUB-TERRITÓRIO, NÃO abrir wizard global
                    // O wizard correto será aberto por drawSubTerritory
                    if (!self.isDrawingSubTerritory) {
                        console.log('🎯 Modo TERRITÓRIO - Abrindo wizard global via UI Controller');
                        // OBRIGATÓRIO: Abrir wizard de ajuste (CAR + Trim) através do UI Controller
                        if (window.app && window.app.uiController && typeof window.app.uiController.openTerritoryWizard === 'function') {
                            await window.app.uiController.openTerritoryWizard(originalLayer, overlapResult);
                        } else {
                            // Fallback para o comportamento antigo caso UI Controller não esteja disponível
                            console.warn('⚠️ openTerritoryWizard não disponível, usando window.app.wizard.open como fallback');
                            if (window.app && window.app.wizard && typeof window.app.wizard.open === 'function') {
                                await window.app.wizard.open(originalLayer, overlapResult);
                            }
                        }
                    } else {
                        console.log('🎯 Modo SUB-TERRITÓRIO - Wizard será aberto por drawSubTerritory');
                    }
                    return; // Aguardar decisão do usuário no wizard
                } else {
                    console.log('✅ VALIDAÇÃO APROVADA: Nenhuma sobreposição detectada');
                }
            } else {
                console.log('ℹ️ Nenhum território existente para validar');
            }
            
            // ================================================================
            // VERIFICAR MODO: Sub-território ou Território?
            // ================================================================
            
            // MODO SUB-TERRITÓRIO: Wizard será aberto pelo UI Controller
            if (self.isDrawingSubTerritory || (window.app && window.app.uiController && window.app.uiController.currentParentTerritory)) {
                console.log('🟠 Modo sub-território ativo - wizard será aberto pelo UI Controller');
                return; // Deixar o UI Controller lidar com o wizard
            }
            
            // MODO TERRITÓRIO: SEMPRE abrir wizard (com ou sem sobreposição)
            console.log('🎯 Modo TERRITÓRIO - Abrindo wizard (sem sobreposição detectada)');
            
            // Definir pane para primeiro plano
            originalLayer.options.pane = 'drawingsPane';
            
            // Adicionar layer temporariamente para o wizard trabalhar (PRIMEIRO PLANO)
            self.layers.drawings.addLayer(originalLayer);
            self.currentPolygon = originalLayer;
            
            // OBRIGATÓRIO: Abrir wizard de ajuste (CAR + validação)
            if (window.app && window.app.uiController && typeof window.app.uiController.openTerritoryWizard === 'function') {
                await window.app.uiController.openTerritoryWizard(originalLayer, null);
            } else {
                // Fallback para o comportamento antigo
                console.warn('⚠️ openTerritoryWizard não disponível, usando window.app.wizard.open como fallback');
                if (window.app && window.app.wizard && typeof window.app.wizard.open === 'function') {
                    await window.app.wizard.open(originalLayer, null);
                } else {
                    // Último fallback: modal de detalhes simples
                    const area = self.calculateArea(originalLayer);
                    console.log(`📊 Polígono finalizado: ${area.toFixed(2)} ha`);
                    self.showPolygonDetails(originalLayer, area);
                }
            }
        });

        // Draw edited
        this.map.on(L.Draw.Event.EDITED, async function(e) {
            const layers = e.layers;
            
            // Processar cada layer editado
            for (const [_, layer] of Object.entries(layers._layers)) {
                console.log('✏️ Polígono editado - verificando sobreposição...');
                
                const area = self.calculateArea(layer);
                
                // Obter geometrias dos territórios existentes (excluindo o atual se houver)
                let existingGeometries = self.getExistingTerritoriesGeometries();
                
                // Se o layer tem territoryData, excluir ele mesmo da verificação
                if (layer.territoryData && layer.territoryData.id) {
                    existingGeometries = existingGeometries.filter(
                        geo => geo.properties.id !== layer.territoryData.id
                    );
                }
                
                if (existingGeometries.length > 0) {
                    // Verificar se há sobreposição
                    const overlapResult = self.checkOverlap(layer, existingGeometries);
                    
                    if (overlapResult.hasOverlap) {
                        console.log(`⚠️ Sobreposição detectada após edição com ${overlapResult.overlappedTerritories.length} território(s)`);
                        
                        // Remover o layer editado temporariamente
                        self.layers.drawings.removeLayer(layer);
                        
                        // Calcular TRIM
                        const trimmedGeoJSON = window.app.polygonTools.quickTrim(
                            layer,
                            existingGeometries,
                            { margin: 0.02 }
                        );
                        
                        // Mostrar modal de confirmação com preview
                        await self.showTrimConfirmationModal(layer, trimmedGeoJSON, overlapResult, true);
                        return; // Aguardar decisão do usuário
                    } else {
                        console.log(`✅ Polígono editado sem sobreposição: ${area.toFixed(2)} ha`);
                        
                        // Atualizar área no banco se for território existente
                        if (layer.territoryData && layer.territoryData.id) {
                            try {
                                const geojson = layer.toGeoJSON();
                                await window.app.dataManager.updateTerritory(layer.territoryData.id, {
                                    geometry: geojson.geometry,
                                    area_hectares: area
                                });
                                console.log('✅ Território atualizado no banco');
                                
                                // Atualizar UI
                                if (window.app.uiController && layer.territoryData.center_key) {
                                    window.app.uiController.updateCenterItemArea(layer.territoryData.center_key, area);
                                }
                                
                                window.app.uiController.showNotification('✅ Território atualizado com sucesso', 'success');
                            } catch (error) {
                                console.error('Erro ao atualizar território:', error);
                                window.app.uiController.showNotification('❌ Erro ao atualizar território', 'error');
                            }
                        }
                    }
                } else {
                    console.log(`✅ Polígono editado: ${area.toFixed(2)} ha (sem territórios para verificar)`);
                }
            }
        });

        // Draw deleted
        this.map.on(L.Draw.Event.DELETED, function(e) {
            console.log('Polígonos deletados');
        });

        // Draw started (usuário começou a desenhar)
        this.map.on(L.Draw.Event.DRAWSTART, function(e) {
            console.log('🎨 Iniciando desenho...');
            self.map._drawingMode = true;
            self.map.getContainer().style.cursor = 'crosshair';
        });

        // Draw stopped (usuário cancelou ou terminou)
        this.map.on(L.Draw.Event.DRAWSTOP, function(e) {
            console.log('🛑 Desenho finalizado/cancelado');
            self.map._drawingMode = false;
            self.isDrawingSubTerritory = false; // Resetar flag
            self.map.getContainer().style.cursor = '';
            
            // Limpar aviso de sobreposição
            self.clearOverlapWarning();
        });

        // Vertex added (ponto adicionado ao polígono)
        this.map.on(L.Draw.Event.DRAWVERTEX, function(e) {
            const layers = e.layers;
            const vertexCount = layers.getLayers().length;
            console.log(`📍 Ponto ${vertexCount} adicionado`);
            
            // VALIDAÇÃO EM TEMPO REAL - Verificar sobreposição a cada 3+ pontos
            if (vertexCount >= 3) {
                self.validateDrawingInProgress(layers);
            }
            
            // Feedback visual
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    `📍 Ponto ${vertexCount} adicionado`, 
                    'info',
                    1000
                );
            }
        });

        // Click no mapa
        this.map.on('click', function(e) {
            self.updateMapInfo(e.latlng);
        });

        // Move do mouse
        this.map.on('mousemove', function(e) {
            self.updateMapInfo(e.latlng);
        });

        // Layer Control events - Sincronizar legenda com visibilidade
        this.map.on('overlayadd', function(e) {
            console.log('✅ Camada adicionada:', e.name);
            
            // Se for a camada de consultores, mostrar legenda
            if (e.name.includes('Áreas por Consultor')) {
                const legendElement = document.getElementById('consultorLegend');
                if (legendElement) {
                    legendElement.style.display = 'block';
                    console.log('📋 Legenda de consultores exibida');
                }
            }
        });

        this.map.on('overlayremove', function(e) {
            console.log('🔲 Camada removida:', e.name);
            
            // Se for a camada de consultores, ocultar legenda
            if (e.name.includes('Áreas por Consultor')) {
                const legendElement = document.getElementById('consultorLegend');
                if (legendElement) {
                    legendElement.style.display = 'none';
                    console.log('📋 Legenda de consultores ocultada');
                }
            }
        });
    }

    /**
     * Ativa modo de desenho de polígono
     */
    startDrawing(isSubTerritory = false) {
        // Definir se está desenhando sub-território
        this.isDrawingSubTerritory = isSubTerritory;
        
        // Marcar que está em modo de desenho
        this.map._drawingMode = true;
        console.log(`🎨 Modo de desenho ativado ${isSubTerritory ? '(SUB-TERRITÓRIO)' : '(TERRITÓRIO)'}`);
        
        // Mudar cursor
        this.map.getContainer().style.cursor = 'crosshair';
        
        new L.Draw.Polygon(this.map, this.drawControl.options.draw.polygon).enable();
    }

    /**
     * Ativa modo de edição
     */
    startEditing() {
        if (this.layers.drawings.getLayers().length === 0) {
            alert('Nenhum polígono para editar');
            return;
        }
        new L.EditToolbar.Edit(this.map, {
            featureGroup: this.layers.drawings
        }).enable();
    }

    /**
     * Ativa modo de edição para um polígono específico
     */
    enablePolygonEdit(polygon) {
        try {
            // Adicionar o polígono ao layer de desenho se não estiver
            if (!this.layers.drawings.hasLayer(polygon)) {
                // Remover da camada de polígonos
                this.layers.polygons.removeLayer(polygon);
                
                // Definir pane para primeiro plano
                polygon.options.pane = 'drawingsPane';
                
                // Adicionar à camada de desenho (editável - PRIMEIRO PLANO)
                this.layers.drawings.addLayer(polygon);
            }
            
            // Ativar edição Leaflet.Draw
            if (polygon.editing) {
                polygon.editing.enable();
                console.log('✅ Edição ativada via Leaflet.Draw');
            } else {
                // Criar nova instância de edição
                new L.EditToolbar.Edit(this.map, {
                    featureGroup: this.layers.drawings
                }).enable();
                console.log('✅ Edição ativada via EditToolbar');
            }
            
            // Armazenar como polígono atual
            this.currentPolygon = polygon;
            
            return true;
        } catch (error) {
            console.error('Erro ao ativar edição do polígono:', error);
            return false;
        }
    }

    /**
     * Desativa modo de edição para um polígono específico
     */
    disablePolygonEdit(polygon) {
        try {
            if (polygon.editing && polygon.editing.enabled()) {
                polygon.editing.disable();
                console.log('✅ Edição desativada');
            }
            return true;
        } catch (error) {
            console.error('Erro ao desativar edição:', error);
            return false;
        }
    }

    /**
     * Ativa modo de seleção de vértices por arrastar (drag selection)
     */
    enableVertexSelection(polygon) {
        try {
            if (!polygon) {
                console.error('❌ Polígono inválido');
                return false;
            }

            console.log('🎯 Ativando modo de seleção por arrastar...');
            
            // Ativar modo de edição para mostrar vértices
            if (!polygon.editing.enabled()) {
                polygon.editing.enable();
            }

            // Estado da ferramenta
            this.vertexSelectionState = {
                active: true,
                polygon: polygon,
                selectedIndices: new Set(),
                markers: [],
                dragging: false,
                startPoint: null,
                selectionBox: null
            };

            // Mostrar barra de ferramentas
            const editToolbar = document.querySelector('.edit-toolbar');
            if (editToolbar && !editToolbar.classList.contains('show')) {
                editToolbar.classList.add('show');
            }

            // Atualizar label
            const label = document.getElementById('editToolbarLabel');
            if (label) {
                label.textContent = 'Arraste para selecionar vértices • Clique para seleção individual';
                label.style.color = '#f97316';
            }

            // Desabilitar temporariamente a edição dos vértices para não interferir
            polygon.editing.disable();

            // Event handlers para drag selection
            this._dragStartHandler = (e) => this._onDragStart(e);
            this._dragMoveHandler = (e) => this._onDragMove(e);
            this._dragEndHandler = (e) => this._onDragEnd(e);
            
            this.map.on('mousedown', this._dragStartHandler);
            this.map.on('mousemove', this._dragMoveHandler);
            this.map.on('mouseup', this._dragEndHandler);

            // Feedback visual
            this.map.getContainer().style.cursor = 'crosshair';
            
            console.log('✅ Modo de seleção ativado - arraste para selecionar vértices');
            
            // Mostrar mensagem
            this._showDragSelectionMessage();
            
            return true;
            
        } catch (error) {
            console.error('❌ Erro ao ativar seleção:', error);
            return false;
        }
    }

    /**
     * Mostra mensagem informativa
     */
    _showDragSelectionMessage() {
        const message = document.createElement('div');
        message.id = 'vertex-selection-message';
        message.innerHTML = `
            <div style="position: fixed; top: 80px; left: 50%; transform: translateX(-50%); 
                        background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); 
                        color: white; padding: 12px 24px; border-radius: 8px; 
                        box-shadow: 0 4px 12px rgba(249, 115, 22, 0.4);
                        z-index: 10000; font-size: 14px; font-weight: 500;
                        animation: slideDown 0.3s ease-out;">
                <i class="bi bi-bounding-box"></i> 
                Arraste para criar área de seleção • 
                <span id="vertex-count">0 selecionados</span>
            </div>
        `;
        document.body.appendChild(message);

        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideDown {
                from { transform: translateX(-50%) translateY(-20px); opacity: 0; }
                to { transform: translateX(-50%) translateY(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * Início do arrasto (mousedown)
     */
    _onDragStart(e) {
        if (!this.vertexSelectionState || !this.vertexSelectionState.active) {
            return;
        }

        const originalEvent = e.originalEvent;
        originalEvent.preventDefault();
        originalEvent.stopPropagation();

        this.vertexSelectionState.dragging = true;
        this.vertexSelectionState.startPoint = e.latlng;

        // Criar retângulo de seleção visual
        const bounds = L.latLngBounds(e.latlng, e.latlng);
        this.vertexSelectionState.selectionBox = L.rectangle(bounds, {
            color: this.territoryColors.subTerritory,
            weight: 2,
            fillColor: this.territoryColors.subTerritoryFill,
            fillOpacity: 0.15,
            dashArray: '5, 5'
        }).addTo(this.map);

        console.log('🎯 Iniciando seleção por arrastar...');
    }

    /**
     * Movimento durante arrasto (mousemove)
     */
    _onDragMove(e) {
        if (!this.vertexSelectionState || !this.vertexSelectionState.dragging) {
            return;
        }

        const startPoint = this.vertexSelectionState.startPoint;
        const endPoint = e.latlng;

        // Atualizar retângulo de seleção
        const bounds = L.latLngBounds(startPoint, endPoint);
        if (this.vertexSelectionState.selectionBox) {
            this.vertexSelectionState.selectionBox.setBounds(bounds);
        }
    }

    /**
     * Fim do arrasto (mouseup)
     */
    _onDragEnd(e) {
        if (!this.vertexSelectionState) {
            return;
        }

        if (!this.vertexSelectionState.dragging) {
            // Clique simples - selecionar vértice individual
            this._handleSingleClick(e);
            return;
        }

        this.vertexSelectionState.dragging = false;

        const startPoint = this.vertexSelectionState.startPoint;
        const endPoint = e.latlng;
        const bounds = L.latLngBounds(startPoint, endPoint);

        // Encontrar vértices dentro do retângulo
        const polygon = this.vertexSelectionState.polygon;
        const latlngs = polygon.getLatLngs()[0];

        latlngs.forEach((vertex, index) => {
            if (bounds.contains(vertex)) {
                // Adicionar à seleção se não estiver
                if (!this.vertexSelectionState.selectedIndices.has(index)) {
                    this._addVertexToSelection(index, vertex);
                }
            }
        });

        // Remover retângulo de seleção
        if (this.vertexSelectionState.selectionBox) {
            this.map.removeLayer(this.vertexSelectionState.selectionBox);
            this.vertexSelectionState.selectionBox = null;
        }

        console.log(`✅ Seleção concluída: ${this.vertexSelectionState.selectedIndices.size} vértices`);
        
        this._updateVertexCount();
        this._toggleConfirmButton();
    }

    /**
     * Trata clique simples em vértice individual
     */
    _handleSingleClick(e) {
        const polygon = this.vertexSelectionState.polygon;
        const latlngs = polygon.getLatLngs()[0];
        
        // Encontrar vértice mais próximo
        const clickPoint = e.latlng;
        let closestIndex = -1;
        let minDistance = Infinity;
        const threshold = 20; // pixels

        latlngs.forEach((vertex, index) => {
            const point = this.map.latLngToContainerPoint(vertex);
            const clickPixel = this.map.latLngToContainerPoint(clickPoint);
            const distance = Math.sqrt(
                Math.pow(point.x - clickPixel.x, 2) + 
                Math.pow(point.y - clickPixel.y, 2)
            );
            
            if (distance < minDistance && distance < threshold) {
                minDistance = distance;
                closestIndex = index;
            }
        });

        if (closestIndex !== -1) {
            this._toggleVertexSelection(closestIndex, latlngs[closestIndex]);
        }
    }

    /**
     * Adiciona vértice à seleção
     */
    _addVertexToSelection(index, latlng) {
        const state = this.vertexSelectionState;
        
        if (!state.selectedIndices.has(index)) {
            state.selectedIndices.add(index);
            
            // Criar marcador visual vermelho pulsante
            const marker = L.circleMarker(latlng, {
                radius: 9,
                fillColor: '#ef4444',
                fillOpacity: 0.9,
                color: '#ffffff',
                weight: 3,
                interactive: false,
                className: 'selected-vertex-marker'
            }).addTo(this.map);
            
            state.markers.push({ index, marker });
            
            console.log(`� Vértice ${index} adicionado à seleção`);
        }
    }

    /**
     * Marca/desmarca um vértice (toggle)
     */
    _toggleVertexSelection(index, latlng) {
        const state = this.vertexSelectionState;
        
        if (state.selectedIndices.has(index)) {
            // Desmarcar
            state.selectedIndices.delete(index);
            
            const markerIndex = state.markers.findIndex(m => m.index === index);
            if (markerIndex !== -1) {
                this.map.removeLayer(state.markers[markerIndex].marker);
                state.markers.splice(markerIndex, 1);
            }
            
            console.log(`� Vértice ${index} desmarcado`);
        } else {
            // Marcar
            this._addVertexToSelection(index, latlng);
        }

        this._updateVertexCount();
        this._toggleConfirmButton();
    }

    /**
     * Atualiza contador de vértices selecionados
     */
    _updateVertexCount() {
        const countElement = document.getElementById('vertex-count');
        if (countElement && this.vertexSelectionState) {
            const count = this.vertexSelectionState.selectedIndices.size;
            countElement.textContent = `${count} selecionado${count !== 1 ? 's' : ''}`;
        }
    }

    /**
     * Mostra/esconde botão de confirmar deleção
     */
    _toggleConfirmButton() {
        const hasSelection = this.vertexSelectionState && 
                           this.vertexSelectionState.selectedIndices.size > 0;
        
        let confirmBtn = document.getElementById('btn-confirm-vertex-deletion');
        
        if (hasSelection && !confirmBtn) {
            // Criar botão de confirmar
            const editToolbar = document.querySelector('.edit-toolbar-actions');
            if (editToolbar) {
                confirmBtn = document.createElement('button');
                confirmBtn.id = 'btn-confirm-vertex-deletion';
                confirmBtn.className = 'btn-edit-action btn-confirm-delete';
                confirmBtn.innerHTML = '<i class="bi bi-check-circle"></i><span>Deletar Selecionados</span>';
                confirmBtn.onclick = () => this.confirmVertexDeletion();
                
                // Inserir antes do botão Cancelar
                const cancelBtn = document.getElementById('btnCancelEdit');
                if (cancelBtn) {
                    editToolbar.insertBefore(confirmBtn, cancelBtn);
                }
            }
        } else if (!hasSelection && confirmBtn) {
            // Remover botão se não há seleção
            confirmBtn.remove();
        }
    }

    /**
     * Confirma e executa a deleção dos vértices selecionados
     */
    confirmVertexDeletion() {
        if (!this.vertexSelectionState || this.vertexSelectionState.selectedIndices.size === 0) {
            return;
        }

        const polygon = this.vertexSelectionState.polygon;
        const latlngs = polygon.getLatLngs()[0];
        const selectedCount = this.vertexSelectionState.selectedIndices.size;
        const remainingCount = latlngs.length - selectedCount;

        // Validar mínimo de vértices
        if (remainingCount < 3) {
            alert(`❌ Não é possível deletar ${selectedCount} vértice(s).\n\nUm polígono precisa de no mínimo 3 vértices.\nAtualmente há ${latlngs.length} vértices.`);
            return;
        }

        // Confirmar ação
        if (!confirm(`🗑️ Deletar ${selectedCount} vértice(s)?\n\nRestarão ${remainingCount} vértices no polígono.`)) {
            return;
        }

        // Criar novo array sem os vértices selecionados
        const newLatLngs = latlngs.filter((_, index) => 
            !this.vertexSelectionState.selectedIndices.has(index)
        );

        // Atualizar polígono
        polygon.setLatLngs([newLatLngs]);

        console.log(`✅ ${selectedCount} vértice(s) deletado(s)`);

        // Limpar seleção
        this.disableVertexSelection();
        
        // Reativar modo de seleção para continuar editando se desejado
        this.enableVertexSelection(polygon);
    }

    /**
     * Desativa modo de seleção de vértices
     */
    disableVertexSelection() {
        if (!this.vertexSelectionState || !this.vertexSelectionState.active) {
            return;
        }

        console.log('🎯 Desativando seleção de vértices...');

        // Remover event listeners
        this.map.off('mousedown', this._dragStartHandler);
        this.map.off('mousemove', this._dragMoveHandler);
        this.map.off('mouseup', this._dragEndHandler);

        // Remover retângulo de seleção se existir
        if (this.vertexSelectionState.selectionBox) {
            this.map.removeLayer(this.vertexSelectionState.selectionBox);
        }

        // Remover marcadores visuais
        this.vertexSelectionState.markers.forEach(({ marker }) => {
            this.map.removeLayer(marker);
        });

        // Remover mensagem
        const message = document.getElementById('vertex-selection-message');
        if (message) {
            message.remove();
        }

        // Remover botão confirmar
        const confirmBtn = document.getElementById('btn-confirm-vertex-deletion');
        if (confirmBtn) {
            confirmBtn.remove();
        }

        // Reativar edição do polígono
        if (this.vertexSelectionState.polygon && this.vertexSelectionState.polygon.editing) {
            this.vertexSelectionState.polygon.editing.enable();
        }

        // Restaurar cursor
        this.map.getContainer().style.cursor = '';

        // Restaurar label
        const label = document.getElementById('editToolbarLabel');
        if (label) {
            label.textContent = 'Editando Polígono';
            label.style.color = '';
        }

        // Limpar estado
        this.vertexSelectionState = null;

        console.log('✅ Seleção desativada');
    }

    /**
     * Desativa modo de seleção por laço (DEPRECATED - mantido para compatibilidade)
     */
    disableLassoSelection() {
        // Redirecionar para nova função
        this.disableVertexSelection();
    }

    /**
     * Ativa modo de pincel para deletar vértices (versão direta sem toggle)
     * Círculo segue o mouse e deleta vértices dentro dele
     */
    _enableVertexEraserDirect(polygon) {
        console.log('🔵 _enableVertexEraserDirect() chamado');
        console.trace('🔍 STACK TRACE - Quem chamou _enableVertexEraserDirect():');
        return this._enableVertexEraserInternal(polygon);
    }

    /**
     * Ativa modo de pincel para deletar vértices
     * Círculo segue o mouse e deleta vértices dentro dele
     * TOGGLE: Se já estiver ativo, desativa
     */
    enableVertexEraser(polygon) {
        try {
            // TOGGLE: Se já estiver ativo, desativar
            if (this.eraserState && this.eraserState.active) {
                console.log('🔄 Borracha já ativa, desativando...');
                this.disableVertexEraser();
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification('🎨 Modo Apagar Vértices desativado', 'info');
                }
                return false;
            }
            
            return this._enableVertexEraserInternal(polygon);
        } catch (error) {
            console.error('❌ Erro ao ativar pincel:', error);
            return false;
        }
    }

    /**
     * Lógica interna de ativação do pincel (usado por ambas as funções)
     */
    _enableVertexEraserInternal(polygon) {
        console.log('🟢 _enableVertexEraserInternal() INICIANDO...');
        try {
            if (!polygon) {
                console.error('❌ Polígono inválido');
                return false;
            }

            console.log('🎨 Ativando pincel de apagar vértices...');
            console.log('🔍 Tipo do polígono:', polygon.constructor.name);
            
            // Verificar se polígono tem suporte a edição
            if (!polygon.editing && !polygon.editor) {
                console.error('❌ Polígono não possui suporte a edição (nem editing nem editor)');
                return false;
            }
            
            // Verificar se já está editável (por Leaflet.Draw OU Leaflet.Editable)
            const isEditableByDraw = polygon.editing && polygon.editing.enabled();
            const isEditableByEditable = polygon.editor !== undefined;
            
            console.log('🔍 Editável por Leaflet.Draw?', isEditableByDraw);
            console.log('🔍 Editável por Leaflet.Editable?', isEditableByEditable);
            
            if (!isEditableByDraw && !isEditableByEditable) {
                console.log('⚙️ Polígono não está editável, habilitando...');
                if (polygon.editing) {
                    polygon.editing.enable();
                    console.log('✅ Edição habilitada via Leaflet.Draw');
                } else if (polygon.enableEdit) {
                    polygon.enableEdit(this.map);
                    console.log('✅ Edição habilitada via Leaflet.Editable');
                }
            } else {
                console.log('✅ Edição já estava habilitada (não precisa reabilitar)');
            }

            // Obter estrutura de coordenadas correta
            let latLngs = polygon.getLatLngs();
            console.log('🔍 Estrutura getLatLngs():', latLngs.length, 'items');
            
            // Se for array de arrays (MultiPolygon ou Polygon com holes), pegar o primeiro anel
            if (Array.isArray(latLngs[0]) && latLngs[0][0] && latLngs[0][0].lat !== undefined) {
                latLngs = latLngs[0];
                console.log('🔍 Usando primeiro anel, vértices:', latLngs.length);
            }
            
            // Estado da ferramenta
            // Fazer backup simples dos vértices (apenas lat/lng, sem referências circulares)
            const backupLatLngs = latLngs.map(v => ({
                lat: v.lat,
                lng: v.lng
            }));
            
            this.eraserState = {
                active: true,
                polygon: polygon,
                radius: 30, // raio inicial em pixels
                minRadius: 10,
                maxRadius: 100,
                isErasing: false, // se está com botão pressionado
                eraserCircle: null,
                deletedIndices: new Set(),
                hasChanges: false, // controla se houve alterações
                originalLatLngs: backupLatLngs, // backup simples (sem referências circulares)
                originalVertexCount: latLngs.length, // contador inicial
                deletedCount: 0, // contador de deletados
                history: [] // histórico de estados para Ctrl+Z
            };

            // Criar círculo visual
            this._createEraserCircle();

            // Event handlers
            this._eraserMoveHandler = (e) => this._onEraserMove(e);
            this._eraserDownHandler = (e) => this._onEraserDown(e);
            this._eraserUpHandler = (e) => this._onEraserUp(e);
            this._eraserWheelHandler = (e) => this._onEraserWheel(e);
            this._eraserKeyHandler = (e) => this._onEraserKey(e);
            
            this.map.on('mousemove', this._eraserMoveHandler);
            this.map.on('mousedown', this._eraserDownHandler);
            this.map.on('mouseup', this._eraserUpHandler);
            
            // Wheel para ajustar tamanho do pincel
            const mapContainer = this.map.getContainer();
            mapContainer.addEventListener('wheel', this._eraserWheelHandler, { passive: false });
            
            // Teclado para ESC e Enter
            document.addEventListener('keydown', this._eraserKeyHandler);

            // Feedback visual
            console.log('🖱️ Alterando cursor para "none"');
            console.log('🔍 Container do mapa:', mapContainer);
            mapContainer.style.cursor = 'none';
            console.log('🔍 Cursor aplicado:', mapContainer.style.cursor);
            
            // Mostrar barra de ferramentas
            const editToolbar = document.querySelector('.edit-toolbar');
            if (editToolbar && !editToolbar.classList.contains('show')) {
                editToolbar.classList.add('show');
                console.log('✅ Barra de ferramentas exibida');
            }

            // Atualizar label
            const label = document.getElementById('editToolbarLabel');
            if (label) {
                label.innerHTML = '<i class="bi bi-mouse"></i> Clique e arraste para apagar • Scroll para ajustar tamanho';
                label.style.color = '#ef4444';
            }
            
            this._showEraserMessage();
            
            console.log('✅ Pincel de apagar ativado');
            console.log('🟢 _enableVertexEraserInternal() FINALIZADO COM SUCESSO');
            return true;
            
        } catch (error) {
            console.error('❌ Erro ao ativar pincel:', error);
            return false;
        }
    }

    /**
     * Cria círculo visual do pincel
     */
    _createEraserCircle() {
        console.log('🎨 _createEraserCircle() chamado');
        console.log('🔍 this.map existe?', !!this.map);
        console.log('🔍 this.eraserState existe?', !!this.eraserState);
        
        if (this.eraserState.eraserCircle) {
            console.log('🗑️ Removendo círculo antigo');
            this.map.removeLayer(this.eraserState.eraserCircle);
        }

        // Criar círculo inicial (será atualizado no mousemove)
        const center = this.map.getCenter();
        console.log('📍 Centro do mapa:', center);
        
        const radiusMeters = this._getEraserRadiusInMeters();
        console.log('📏 Raio calculado (metros):', radiusMeters);
        
        this.eraserState.eraserCircle = L.circle(center, {
            radius: radiusMeters,
            color: '#ef4444',
            weight: 2,
            fillColor: '#ef4444',
            fillOpacity: 0.1,
            interactive: false,
            className: 'eraser-circle'
        }).addTo(this.map);
        
        console.log('✅ Círculo criado e adicionado ao mapa');
        console.log('🔍 Círculo no mapa?', this.map.hasLayer(this.eraserState.eraserCircle));
    }

    /**
     * Converte raio de pixels para metros baseado no zoom
     */
    _getEraserRadiusInMeters() {
        const map = this.map;
        const centerPoint = map.getSize().divideBy(2);
        const pointA = L.point(centerPoint.x, centerPoint.y);
        const pointB = L.point(centerPoint.x + this.eraserState.radius, centerPoint.y);
        
        const latLngA = map.containerPointToLatLng(pointA);
        const latLngB = map.containerPointToLatLng(pointB);
        
        return latLngA.distanceTo(latLngB);
    }

    /**
     * Mostra mensagem informativa
     */
    _showEraserMessage() {
        const message = document.createElement('div');
        message.id = 'eraser-message';
        message.innerHTML = `
            <div style="position: fixed; top: 80px; left: 50%; transform: translateX(-50%); 
                        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); 
                        color: white; padding: 12px 24px; border-radius: 8px; 
                        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
                        z-index: 10000; font-size: 14px; font-weight: 500;
                        animation: slideDown 0.3s ease-out;">
                <i class="bi bi-eraser"></i> 
                <span id="eraser-info">Raio: ${this.eraserState.radius}px • SHIFT + Scroll • Ctrl+Z desfazer • ESC sair</span>
            </div>
        `;
        document.body.appendChild(message);

        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideDown {
                from { opacity: 0; }
                to { opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * Atualiza mensagem com info do pincel
     */
    _updateEraserInfo() {
        const info = document.getElementById('eraser-info');
        if (info) {
            info.textContent = `Raio: ${this.eraserState.radius}px • SHIFT + Scroll • Ctrl+Z desfazer • ESC sair`;
        }
    }

    /**
     * Handler: movimento do mouse (atualiza posição e apaga se botão pressionado)
     */
    _onEraserMove(e) {
        if (!this.eraserState || !this.eraserState.active) return;

        // DEBUG: Log apenas a cada 100 eventos para não poluir console
        if (!this._eraserMoveCount) this._eraserMoveCount = 0;
        this._eraserMoveCount++;
        if (this._eraserMoveCount === 1) {
            console.log('👆 Primeiro evento de movimento do mouse detectado');
            console.log('🔍 eraserCircle existe?', !!this.eraserState.eraserCircle);
            console.log('🔍 Posição do mouse:', e.latlng);
        }
        if (this._eraserMoveCount % 100 === 0) {
            console.log(`👆 ${this._eraserMoveCount} eventos de movimento processados`);
        }

        // Atualizar posição do círculo
        if (this.eraserState.eraserCircle) {
            this.eraserState.eraserCircle.setLatLng(e.latlng);
            this.eraserState.eraserCircle.setRadius(this._getEraserRadiusInMeters());
        }

        // Se estiver com botão pressionado, deletar vértices
        if (this.eraserState.isErasing) {
            this._eraseVerticesUnderCursor(e.latlng);
        }
    }

    /**
     * Handler: botão do mouse pressionado
     */
    _onEraserDown(e) {
        if (!this.eraserState || !this.eraserState.active) return;
        
        e.originalEvent.preventDefault();
        this.eraserState.isErasing = true;
        
        // SALVAR ESTADO ATUAL NO HISTÓRICO (antes de modificar)
        // Extrair apenas lat/lng para evitar referências circulares
        const currentLatLngs = this.eraserState.polygon.getLatLngs()[0];
        const snapshot = currentLatLngs.map(v => ({
            lat: v.lat,
            lng: v.lng
        }));
        this.eraserState.history.push(snapshot);
        
        // Mudar visual do círculo
        if (this.eraserState.eraserCircle) {
            this.eraserState.eraserCircle.setStyle({
                fillOpacity: 0.25,
                weight: 3
            });
        }
        
        // Começar a apagar
        this._eraseVerticesUnderCursor(e.latlng);
    }

    /**
     * Handler: botão do mouse solto
     */
    _onEraserUp(e) {
        if (!this.eraserState || !this.eraserState.active) return;
        
        this.eraserState.isErasing = false;
        
        // Restaurar visual do círculo
        if (this.eraserState.eraserCircle) {
            this.eraserState.eraserCircle.setStyle({
                fillOpacity: 0.1,
                weight: 2
            });
        }

        // Se deletou vértices, validar polígono
        if (this.eraserState.deletedIndices.size > 0) {
            const remaining = this.eraserState.polygon.getLatLngs()[0].length;
            console.log(`✅ ${this.eraserState.deletedIndices.size} vértices deletados, ${remaining} restantes`);
            this.eraserState.deletedIndices.clear();
        }
    }

    /**
     * Handler: scroll do mouse (ajusta tamanho do pincel APENAS com SHIFT)
     */
    _onEraserWheel(e) {
        if (!this.eraserState || !this.eraserState.active) return;
        
        // APENAS com SHIFT pressionado
        if (!e.shiftKey) return;
        
        e.preventDefault();
        e.stopPropagation();
        
        const delta = e.deltaY > 0 ? -5 : 5;
        const newRadius = this.eraserState.radius + delta;
        
        // Limitar entre min e max
        this.eraserState.radius = Math.max(
            this.eraserState.minRadius, 
            Math.min(this.eraserState.maxRadius, newRadius)
        );
        
        // Atualizar círculo
        if (this.eraserState.eraserCircle) {
            this.eraserState.eraserCircle.setRadius(this._getEraserRadiusInMeters());
        }
        
        this._updateEraserInfo();
    }

    /**
     * Desfazer última ação do pincel (Ctrl+Z)
     */
    _undoLastErase() {
        if (!this.eraserState || !this.eraserState.active) return;
        
        // Verificar se há histórico de ações
        if (!this.eraserState.history || this.eraserState.history.length === 0) {
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification('⚠️ Nada para desfazer', 'warning');
            }
            return;
        }
        
        // Recuperar estado anterior
        const previousState = this.eraserState.history.pop();
        
        // Restaurar vértices
        this.eraserState.polygon.setLatLngs([previousState]);
        
        // Atualizar contador
        const currentVertexCount = previousState.length;
        this.eraserState.deletedCount = this.eraserState.originalVertexCount - currentVertexCount;
        
        // Verificar se ainda há mudanças
        this.eraserState.hasChanges = this.eraserState.history.length > 0;
        
        console.log(`↶ Desfez última ação - ${currentVertexCount} vértices`);
        
        if (window.app && window.app.uiController) {
            window.app.uiController.showNotification(`↶ Desfeito - ${currentVertexCount} vértices`, 'info');
        }
    }

    /**
     * Handler: teclado (ESC = cancelar, Enter = salvar, Ctrl+Z = desfazer)
     */
    _onEraserKey(e) {
        if (!this.eraserState || !this.eraserState.active) return;
        
        // ESC - Perguntar se quer cancelar
        if (e.key === 'Escape') {
            e.preventDefault();
            this._confirmExitEraser('cancel');
        }
        
        // Enter - Perguntar se quer salvar
        if (e.key === 'Enter') {
            e.preventDefault();
            this._confirmExitEraser('save');
        }
        
        // Ctrl+Z - Desfazer última deleção
        if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
            e.preventDefault();
            this._undoLastErase();
        }
    }

    /**
     * Confirma saída do modo pincel (com modal)
     */
    async _confirmExitEraser(action) {
        // Se não houve mudanças, sair direto
        if (!this.eraserState.hasChanges) {
            this.disableVertexEraser();
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification('Nenhuma alteração feita', 'info');
            }
            return;
        }

        // Calcular vértices atuais vs originais
        const currentVertexCount = this.eraserState.polygon.getLatLngs()[0].length;
        const verticesDeleted = this.eraserState.originalVertexCount - currentVertexCount;
        
        // Criar modal customizado
        const modal = document.createElement('div');
        modal.id = 'eraser-exit-modal';
        modal.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; 
                        background: rgba(0, 0, 0, 0.7); z-index: 10001; 
                        display: flex; align-items: center; justify-content: center;
                        animation: fadeIn 0.2s ease-out;">
                <div style="background: white; border-radius: 12px; padding: 28px; 
                            max-width: 420px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                            animation: slideUp 0.3s ease-out;">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                        <i class="bi bi-question-circle-fill" style="font-size: 2.5rem; color: #f97316;"></i>
                        <h3 style="margin: 0; color: #1e293b; font-size: 1.4rem;">Salvar alterações?</h3>
                    </div>
                    <div style="background: #f1f5f9; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
                        <p style="margin: 0; color: #475569; font-size: 0.95rem;">
                            <strong style="color: #ef4444; font-size: 1.3rem;">${verticesDeleted}</strong> 
                            <span style="color: #64748b;">vértice(s) deletado(s)</span>
                        </p>
                        <p style="margin: 8px 0 0 0; color: #64748b; font-size: 0.85rem;">
                            De ${this.eraserState.originalVertexCount} para ${currentVertexCount} vértices
                        </p>
                    </div>
                    <p style="color: #64748b; margin-bottom: 24px; font-size: 0.9rem;">
                        Deseja salvar as alterações no polígono?
                    </p>
                    <div style="display: flex; gap: 12px; justify-content: flex-end;">
                        <button id="btn-eraser-discard" 
                                style="padding: 12px 24px; border: 2px solid #ef4444; 
                                       background: white; color: #ef4444; border-radius: 8px; 
                                       font-weight: 600; cursor: pointer; transition: all 0.2s;
                                       font-size: 0.95rem;">
                            <i class="bi bi-x-circle"></i> Descartar
                        </button>
                        <button id="btn-eraser-save" 
                                style="padding: 12px 24px; border: none; 
                                       background: linear-gradient(135deg, #10b981 0%, #059669 100%); 
                                       color: white; border-radius: 8px; 
                                       font-weight: 600; cursor: pointer; transition: all 0.2s;
                                       box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
                                       font-size: 0.95rem;">
                            <i class="bi bi-check-circle"></i> Salvar
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            @keyframes slideUp {
                from { transform: translateY(20px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            #btn-eraser-discard:hover { background: #ef4444; color: white; }
            #btn-eraser-save:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4); }
        `;
        document.head.appendChild(style);
        document.body.appendChild(modal);

        // Adicionar event listeners APÓS adicionar ao DOM, mas usar querySelectorAll dentro do modal
        // para garantir que pegamos os botões corretos
        const btnDiscard = modal.querySelector('#btn-eraser-discard');
        const btnSave = modal.querySelector('#btn-eraser-save');
        
        console.log('🔍 Botões encontrados:', { btnDiscard: !!btnDiscard, btnSave: !!btnSave });
        
        if (btnDiscard) {
            btnDiscard.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🗑️ Botão Descartar clicado');
                
                // Restaurar polígono original
                const originalCoords = this.eraserState.originalLatLngs.map(coord => 
                    L.latLng(coord.lat, coord.lng)
                );
                
                // Verificar estrutura atual do polígono
                const currentLatLngs = this.eraserState.polygon.getLatLngs();
                if (Array.isArray(currentLatLngs[0]) && currentLatLngs[0][0] && currentLatLngs[0][0].lat !== undefined) {
                    // Estrutura multi-dimensional
                    this.eraserState.polygon.setLatLngs([originalCoords]);
                } else {
                    // Estrutura simples
                    this.eraserState.polygon.setLatLngs(originalCoords);
                }
                
                this.eraserState.polygon.redraw();
                
                modal.remove();
                this.disableVertexEraser();
                
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification('❌ Alterações descartadas', 'warning');
                }
            });
        } else {
            console.error('❌ Botão Descartar não encontrado!');
        }
        
        if (btnSave) {
            btnSave.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('💾 Botão Salvar clicado');
                
                // SALVAR REFERÊNCIAS ANTES DE DESATIVAR PINCEL
                const polygon = this.eraserState?.polygon;
                const isSubTerritory = polygon && polygon.subTerritoryData;
                
                modal.remove();
                
                // 🔧 VALIDAÇÃO E CORREÇÃO AUTOMÁTICA PARA SUB-TERRITÓRIOS
                if (isSubTerritory) {
                    console.log('🔧 SUB-TERRITÓRIO detectado - Aplicando validação e correção automática...');
                    
                    // Desabilitar pincel ANTES de processar
                    this.disableVertexEraser();
                    
                    // Aplicar TRIM automático
                    const correctionResult = await this._autoCorrectSubTerritoryGeometry(polygon);
                    
                    if (!correctionResult.success) {
                        if (window.app && window.app.uiController) {
                            window.app.uiController.showNotification(
                                '❌ Não foi possível corrigir a geometria: ' + correctionResult.error, 
                                'error'
                            );
                        }
                        return;
                    }
                    
                    // Se houve correção, atualizar o polígono
                    if (correctionResult.corrected) {
                        console.log('✂️ Geometria corrigida automaticamente:');
                        console.log(`   • Área antes: ${correctionResult.areaBefore.toFixed(2)} ha`);
                        console.log(`   • Área depois: ${correctionResult.areaAfter.toFixed(2)} ha`);
                        console.log(`   • Correções: ${correctionResult.corrections.join(', ')}`);
                        
                        // Atualizar polígono no mapa
                        polygon.setLatLngs(correctionResult.newCoordinates);
                        
                        // Notificar usuário sobre correções
                        if (window.app && window.app.uiController) {
                            window.app.uiController.showNotification(
                                `🔧 Geometria corrigida: ${correctionResult.corrections.join(', ')}`, 
                                'info',
                                5000
                            );
                        }
                    }
                    
                    // Agora salvar com geometria corrigida
                    console.log('📦 Salvando CARTEIRA (geometria validada)...');
                    if (window.app && window.app.uiController && window.app.uiController.handleSaveSubTerritoryEdit) {
                        await window.app.uiController.handleSaveSubTerritoryEdit();
                    }
                } else {
                    console.log('🗺️ Salvando TERRITÓRIO (sem verificação de sobreposição)...');
                    this.disableVertexEraser();
                    
                    // Salvar território (sem verificação de sobreposição)
                    if (window.app && window.app.uiController && window.app.uiController.handleSaveEdit) {
                        await window.app.uiController.handleSaveEdit();
                    }
                }
            });
        } else {
            console.error('❌ Botão Salvar não encontrado!');
        }
    }

    /**
     * Apaga vértices sob o cursor (simula clique nos marcadores)
     * Comportamento idêntico a clicar manualmente em cada ponto
     */
    _eraseVerticesUnderCursor(centerLatLng) {
        const polygon = this.eraserState.polygon;
        const radius = this.eraserState.radius;
        
        // Verificar se é Leaflet.Editable ou Leaflet.Draw
        let markers = [];
        
        // LEAFLET.EDITABLE (polygon.editor)
        if (polygon.editor && polygon.editor.editLayer && polygon.editor.editLayer.eachLayer) {
            console.log('🔍 Usando Leaflet.Editable para obter marcadores');
            polygon.editor.editLayer.eachLayer(layer => {
                if (layer instanceof L.Marker) {
                    markers.push(layer);
                }
            });
            console.log('📍 Encontrados', markers.length, 'marcadores (Leaflet.Editable)');
        }
        // LEAFLET.DRAW (polygon.editing._verticesHandlers)
        else if (polygon.editing && polygon.editing._verticesHandlers && 
                 polygon.editing._verticesHandlers.length > 0) {
            console.log('🔍 Usando Leaflet.Draw para obter marcadores');
            const vertexHandler = polygon.editing._verticesHandlers[0];
            if (vertexHandler && vertexHandler._markers) {
                markers = vertexHandler._markers;
                console.log('📍 Encontrados', markers.length, 'marcadores (Leaflet.Draw)');
            }
        }
        
        // Se não encontrou marcadores, retornar
        if (markers.length === 0) {
            console.warn('⚠️ Nenhum marcador de vértice encontrado');
            return;
        }
        
        // Converter centro para ponto de tela
        const centerPoint = this.map.latLngToContainerPoint(centerLatLng);
        const markersToClick = [];
        
        // Encontrar marcadores dentro do círculo
        markers.forEach((marker, index) => {
            if (!marker) return;
            
            // Criar ID único baseado na posição do marcador
            const markerLatLng = marker.getLatLng();
            const markerId = `${markerLatLng.lat.toFixed(6)}_${markerLatLng.lng.toFixed(6)}`;
            
            // Pular se já foi deletado neste arrasto
            if (this.eraserState.deletedIndices.has(markerId)) return;
            
            const markerPoint = this.map.latLngToContainerPoint(markerLatLng);
            
            const distance = Math.sqrt(
                Math.pow(centerPoint.x - markerPoint.x, 2) + 
                Math.pow(centerPoint.y - markerPoint.y, 2)
            );
            
            if (distance <= radius) {
                markersToClick.push({ marker, markerId });
            }
        });
        
        // Validar que não vai deletar demais (mínimo 3 vértices)
        if (markers.length - markersToClick.length < 3) {
            return; // Não deletar se sobrar menos de 3
        }
        
        // SIMULAR CLIQUE em cada marcador (comportamento idêntico ao clique manual)
        if (markersToClick.length > 0) {
            markersToClick.forEach(({ marker, markerId }) => {
                // Disparar evento de clique no marcador (exatamente como Leaflet.Draw faz)
                if (marker && marker._icon) {
                    // Criar evento de clique real
                    const clickEvent = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    });
                    
                    // Disparar clique no ícone do marcador
                    marker._icon.dispatchEvent(clickEvent);
                    
                    // Marcar como deletado e incrementar contador
                    this.eraserState.deletedIndices.add(markerId);
                    this.eraserState.deletedCount++;
                }
            });
            
            // Marcar como modificado
            this.eraserState.hasChanges = true;
        }
    }

    /**
     * Desativa modo pincel
     */
    disableVertexEraser() {
        if (!this.eraserState || !this.eraserState.active) {
            return;
        }

        console.log('🎨 Desativando pincel...');
        console.trace('🔍 STACK TRACE - Quem chamou disableVertexEraser():');

        // Remover event listeners
        this.map.off('mousemove', this._eraserMoveHandler);
        this.map.off('mousedown', this._eraserDownHandler);
        this.map.off('mouseup', this._eraserUpHandler);
        
        const mapContainer = this.map.getContainer();
        mapContainer.removeEventListener('wheel', this._eraserWheelHandler);
        document.removeEventListener('keydown', this._eraserKeyHandler);

        // Remover círculo
        if (this.eraserState.eraserCircle) {
            this.map.removeLayer(this.eraserState.eraserCircle);
        }

        // Remover mensagem
        const message = document.getElementById('eraser-message');
        if (message) {
            message.remove();
        }

        // Restaurar cursor
        this.map.getContainer().style.cursor = '';

        // Restaurar label
        const label = document.getElementById('editToolbarLabel');
        if (label) {
            label.textContent = 'Editando Polígono';
            label.style.color = '';
        }

        // Limpar estado
        this.eraserState = null;

        console.log('✅ Pincel desativado');
    }

    /**
     * 🎨 VISUALIZAÇÃO: Mostra vértices problemáticos em vermelho no mapa
     */
    _visualizeProblematicGeometry(subFeature, parentFeature) {
        console.log('🎨 Visualizando geometrias problemáticas...');
        
        try {
            // Criar layer para sub-território (vermelho)
            const subLayer = L.geoJSON(subFeature, {
                style: {
                    color: '#ef4444',
                    fillColor: '#fca5a5',
                    fillOpacity: 0.3,
                    weight: 3,
                    dashArray: '10, 5'
                }
            }).addTo(this.map);
            
            // Criar layer para território pai (magenta chamativo)
            const parentLayer = L.geoJSON(parentFeature, {
                style: {
                    color: this.territoryColors.territory,
                    fillColor: this.territoryColors.territoryFill,
                    fillOpacity: 0.25,
                    weight: 3
                }
            }).addTo(this.map);
            
            // Marcar vértices problemáticos
            const coords = subFeature.geometry.coordinates[0];
            const problemMarkers = [];
            
            coords.forEach((coord, index) => {
                const marker = L.circleMarker([coord[1], coord[0]], {
                    radius: 6,
                    fillColor: '#dc2626',
                    fillOpacity: 0.9,
                    color: '#fff',
                    weight: 2
                }).addTo(this.map);
                
                marker.bindPopup(`
                    <strong>🔴 Vértice ${index + 1}</strong><br>
                    Lat: ${coord[1].toFixed(6)}<br>
                    Lng: ${coord[0].toFixed(6)}
                `);
                
                problemMarkers.push(marker);
            });
            
            console.log(`✅ ${problemMarkers.length} vértices visualizados em vermelho`);
            
            // Centralizar no problema
            this.map.fitBounds(subLayer.getBounds(), { padding: [50, 50] });
            
            // Auto-remover após 10 segundos
            setTimeout(() => {
                subLayer.remove();
                parentLayer.remove();
                problemMarkers.forEach(m => m.remove());
                console.log('🧹 Visualização removida');
            }, 10000);
            
        } catch (err) {
            console.error('❌ Erro ao visualizar geometria:', err);
        }
    }

    /**
     * 🔧 CORREÇÃO AUTOMÁTICA: Valida e corrige geometria de sub-território
     * Garante que está dentro do território pai e sem sobrepor outras carteiras
     */
    async _autoCorrectSubTerritoryGeometry(polygon) {
        try {
            console.log('🔧 Iniciando correção automática de geometria...');
            
            if (!polygon || !polygon.subTerritoryData) {
                return {
                    success: false,
                    error: 'Polígono inválido ou não é um sub-território'
                };
            }
            
            const subTerritoryData = polygon.subTerritoryData;
            const territoryId = subTerritoryData.territory_id;
            
            // Obter geometria atual
            let currentGeometry = polygon.toGeoJSON();
            const areaBefore = this.calculateArea(polygon);
            
            let corrections = [];
            let geometryModified = false;
            
            // ================================================================
            // PASSO 1: CORTAR DENTRO DO TERRITÓRIO PAI (INTERSECT)
            // ================================================================
            console.log('🔍 PASSO 1: Verificando se está dentro do território pai...');
            
            // Buscar território pai
            const territories = await window.app.dataManager.listTerritories();
            const parentTerritory = territories.find(t => t.id === territoryId);
            
            if (!parentTerritory) {
                return {
                    success: false,
                    error: 'Território pai não encontrado'
                };
            }
            
            const parentGeo = typeof parentTerritory.geometry === 'string' 
                ? JSON.parse(parentTerritory.geometry) 
                : parentTerritory.geometry;
            
            // 🔧 VALIDAÇÃO CRÍTICA: Garantir geometrias válidas antes de usar Turf
            console.log('🔍 DEBUG - currentGeometry:', currentGeometry);
            console.log('🔍 DEBUG - currentGeometry.type:', currentGeometry.type);
            console.log('🔍 DEBUG - currentGeometry.geometry:', currentGeometry.geometry);
            console.log('🔍 DEBUG - parentGeo:', parentGeo);
            console.log('🔍 DEBUG - parentGeo.type:', parentGeo.type);
            
            // Extrair SOMENTE geometry (não Feature) do sub-território
            let subGeometry;
            if (currentGeometry.type === 'Feature' && currentGeometry.geometry) {
                subGeometry = currentGeometry.geometry;
            } else if (currentGeometry.geometry) {
                subGeometry = currentGeometry.geometry;
            } else {
                subGeometry = currentGeometry;
            }
            
            // Extrair SOMENTE geometry (não Feature) do parent
            let parentGeometry;
            if (parentGeo.type === 'Feature' && parentGeo.geometry) {
                parentGeometry = parentGeo.geometry;
            } else if (parentGeo.geometry) {
                parentGeometry = parentGeo.geometry;
            } else {
                parentGeometry = parentGeo;
            }
            
            console.log('🔍 Geometries extraídas:');
            console.log('   • subGeometry.type:', subGeometry.type);
            console.log('   • parentGeometry.type:', parentGeometry.type);
            
            // Criar Features válidos (geometry → Feature)
            const subFeature = turf.feature(subGeometry);
            const parentFeature = turf.feature(parentGeometry);
            
            console.log('✅ Features criadas:');
            console.log('   • Sub-território:', subFeature.geometry.type);
            console.log('   • Território pai:', parentFeature.geometry.type);
            
            // ================================================================
            // PASSO 1: GARANTIR QUE ESTÁ DENTRO DO TERRITÓRIO PAI (SEMPRE)
            // ================================================================
            console.log('🔍 PASSO 1: Aplicando INTERSECT com território pai (obrigatório)...');
            
            // SEMPRE aplicar intersect para garantir que está dentro
            const intersected = turf.intersect(subFeature, parentFeature);
            
            if (!intersected) {
                return {
                    success: false,
                    error: 'Sub-território está completamente fora do território pai'
                };
            }
            
            // Atualizar geometria com o resultado do intersect
            currentGeometry.geometry = intersected.geometry;
            geometryModified = true;
            corrections.push('Ajustado aos limites do território pai');
            console.log('✅ INTERSECT aplicado - Sub-território ajustado aos limites do pai');
            
            // ================================================================
            // PASSO 2: TRIM CONTRA OUTRAS CARTEIRAS
            // ================================================================
            console.log('🔍 PASSO 2: Verificando sobreposição com outras carteiras...');
            
            // Buscar outras carteiras do mesmo território
            const allSubTerritories = await window.app.dataManager.listSubTerritories(territoryId);
            const otherSubTerritories = allSubTerritories.filter(st => st.id !== subTerritoryData.id);
            
            if (otherSubTerritories.length > 0) {
                console.log(`   • Encontradas ${otherSubTerritories.length} outras carteiras`);
                
                for (const otherSub of otherSubTerritories) {
                    const otherGeo = typeof otherSub.geometry === 'string'
                        ? JSON.parse(otherSub.geometry)
                        : otherSub.geometry;
                    
                    // Garantir Features válidas (extrair geometries puras)
                    const currentFeature = currentGeometry.type === 'Feature'
                        ? currentGeometry
                        : turf.feature(currentGeometry.geometry);
                    
                    // Extrair geometry pura do outro sub-território
                    const otherGeometry = otherGeo.type === 'Feature' ? otherGeo.geometry : otherGeo;
                    const otherFeature = turf.feature(otherGeometry);
                    
                    // Verificar interseção
                    const hasIntersection = turf.booleanIntersects(currentFeature, otherFeature);
                    
                    if (hasIntersection) {
                        console.log(`   ⚠️ Sobreposição com ${otherSub.carteira_id}, aplicando TRIM...`);
                        
                        // Aplicar buffer de segurança (2cm)
                        const buffered = turf.buffer(otherFeature, 0.00002, { units: 'kilometers' });
                        
                        // Aplicar difference
                        const trimmed = turf.difference(currentFeature, buffered);
                        
                        if (!trimmed) {
                            return {
                                success: false,
                                error: `Sub-território completamente sobreposto por ${otherSub.carteira_id}`
                            };
                        }
                        
                        currentGeometry.geometry = trimmed.geometry;
                        geometryModified = true;
                        corrections.push(`Recortado contra ${otherSub.carteira_id}`);
                        console.log(`   ✅ TRIM aplicado contra ${otherSub.carteira_id}`);
                    }
                }
            } else {
                console.log('✅ Nenhuma outra carteira para verificar');
            }
            
            // ================================================================
            // PASSO 3: VALIDAR GEOMETRIA FINAL
            // ================================================================
            if (geometryModified) {
                // Converter geometria corrigida para coordenadas Leaflet
                const correctedLayer = L.geoJSON(currentGeometry);
                const newCoordinates = correctedLayer.getLayers()[0].getLatLngs()[0];
                
                const areaAfter = turf.area(turf.feature(currentGeometry.geometry)) / 10000;
                
                // Validar área mínima
                if (areaAfter < 0.5) {
                    return {
                        success: false,
                        error: 'Área resultante muito pequena (< 0.5 ha)'
                    };
                }
                
                console.log('✅ Correção automática concluída:');
                console.log(`   • Área antes: ${areaBefore.toFixed(2)} ha`);
                console.log(`   • Área depois: ${areaAfter.toFixed(2)} ha`);
                console.log(`   • Perda: ${(areaBefore - areaAfter).toFixed(2)} ha (${((1 - areaAfter/areaBefore) * 100).toFixed(1)}%)`);
                
                return {
                    success: true,
                    corrected: true,
                    newCoordinates: newCoordinates,
                    newGeometry: currentGeometry.geometry,
                    areaBefore: areaBefore,
                    areaAfter: areaAfter,
                    corrections: corrections
                };
            } else {
                console.log('✅ Nenhuma correção necessária');
                return {
                    success: true,
                    corrected: false
                };
            }
            
        } catch (error) {
            console.error('❌ Erro ao corrigir geometria:', error);
            return {
                success: false,
                error: error.message || 'Erro desconhecido'
            };
        }
    }

    /**
     * Alias para compatibilidade
     */
    enableLassoSelection(polygon) {
        return this.enableVertexEraser(polygon);
    }

    disableLassoSelection() {
        return this.disableVertexEraser();
    }

    /**
     * Deleta polígonos selecionados
     */
    deleteSelected() {
        if (this.layers.drawings.getLayers().length === 0) {
            alert('Nenhum polígono para deletar');
            return;
        }
        new L.EditToolbar.Delete(this.map, {
            featureGroup: this.layers.drawings
        }).enable();
    }

    /**
     * Adiciona um polígono GeoJSON ao mapa
     */
    addGeoJSONPolygon(geojson, options = {}) {
        const layer = L.geoJSON(geojson, {
            style: {
                color: options.color || CONFIG.ui.colors.territory,
                fillOpacity: CONFIG.ui.opacity.fill,
                weight: 2
            },
            onEachFeature: (feature, layer) => {
                if (options.popup) {
                    layer.bindPopup(options.popup);
                }
                if (options.click) {
                    layer.on('click', options.click);
                }
            }
        });

        if (options.type === 'car') {
            layer.addTo(this.layers.car);
        } else {
            layer.addTo(this.layers.polygons);
        }

        return layer;
    }

    /**
     * Remove todos os polígonos de uma camada
     */
    clearLayer(layerName) {
        if (this.layers[layerName]) {
            this.layers[layerName].clearLayers();
        }
    }

    /**
     * Calcula área de um polígono em hectares
     */
    calculateArea(layer) {
        const latlngs = layer.getLatLngs()[0];
        const geojson = {
            type: 'Feature',
            geometry: {
                type: 'Polygon',
                coordinates: [latlngs.map(ll => [ll.lng, ll.lat])]
            }
        };
        return turf.area(geojson) / 10000; // Converter m² para hectares
    }

    /**
     * Zoom para um polígono
     */
    zoomToPolygon(layer) {
        this.map.fitBounds(layer.getBounds(), { padding: [50, 50] });
    }

    /**
     * Mostra detalhes do polígono
     */
    /**
     * Salva território pendente após desenho
     */
    async savePendingTerritory(layer, area) {
        try {
            const territory = window.app.uiController.pendingTerritory;
            
            console.log('💾 TENTANDO SALVAR TERRITÓRIO...');
            console.log(`   - Território: ${territory.id}`);
            console.log(`   - Área: ${area.toFixed(2)} ha`);
            
            // Verificar se este polígono já teve TRIM aplicado e aprovado pelo usuário
            if (layer._skipOverlapValidation || layer._trimApplied) {
                console.log('⚡ Polígono com TRIM aprovado - pulando validação de sobreposição');
            } else {
                // VALIDAÇÃO CRÍTICA TRIPLA: Verificar sobreposição antes de salvar
                const existingGeometries = this.getExistingTerritoriesGeometries();
                console.log(`   - Territórios existentes: ${existingGeometries.length}`);
                
                const overlapCheck = this.checkOverlap(layer, existingGeometries);
                
                if (overlapCheck.hasOverlap) {
                console.error('');
                console.error('═══════════════════════════════════════════════════════');
                console.error('❌ BLOQUEIO DE SEGURANÇA: SOBREPOSIÇÃO DETECTADA!');
                console.error('═══════════════════════════════════════════════════════');
                console.error('Tentativa de salvar território COM SOBREPOSIÇÃO bloqueada!');
                console.error('Territórios sobrepostos:', overlapCheck.overlappedTerritories.map(t => t.properties.territory_id).join(', '));
                console.error('Este território NÃO FOI SALVO no banco de dados.');
                console.error('═══════════════════════════════════════════════════════');
                console.error('');
                
                // Alerta visual forte
                alert('⛔ ERRO DE SEGURANÇA!\n\nTentativa de salvar território COM SOBREPOSIÇÃO foi BLOQUEADA!\n\n' +
                      'Territórios sobrepostos: ' + overlapCheck.overlappedTerritories.map(t => t.properties.territory_id).join(', ') +
                      '\n\nVocê DEVE aplicar o TRIM ou redesenhar o território.');
                
                window.app.uiController.showNotification(
                    '⛔ BLOQUEADO: Território sobrepõe áreas existentes! Use o TRIM obrigatoriamente.', 
                    'error',
                    10000
                );
                
                    // Remover layer inválido do mapa
                    this.layers.drawings.removeLayer(layer);
                    
                    // Forçar recarregamento dos territórios
                    await this.loadBackgroundTerritories();
                    
                    return false;
                }
                
                console.log('✅ Validação de sobreposição APROVADA - prosseguindo com salvamento...');
            }
            
            // Converter layer para GeoJSON
            const geojson = layer.toGeoJSON();
            
            // Salvar no banco de dados
            await window.app.dataManager.createTerritory({
                territory_id: territory.id,
                name: territory.name,
                center_name: territory.centerName,
                center_key: territory.centerKey,
                region_name: territory.regionName,
                geometry: geojson.geometry,
                area_hectares: area
            });
            
            // Limpar território pendente
            window.app.uiController.pendingTerritory = null;
            
            // Recarregar territórios de fundo IMEDIATAMENTE
            await this.loadBackgroundTerritories();
            console.log('✅ Territórios de fundo recarregados após salvar');
            
            // Atualizar árvore
            await window.app.uiController.loadRegionsTree();
            
            // Mostrar notificação
            window.app.uiController.showNotification(
                `✅ Território ${territory.id} criado com sucesso!`, 
                'success'
            );
            
        } catch (error) {
            console.error('Erro ao salvar território:', error);
            window.app.uiController.showNotification(
                '❌ Erro ao salvar território: ' + error.message,
                'error'
            );
            // Re-throw para que o chamador saiba que falhou
            throw error;
        }
    }

    showPolygonDetails(layer, area) {
        const modal = new bootstrap.Modal(document.getElementById('modalPolygonDetails'));
        document.getElementById('polygonArea').value = area.toFixed(2);
        modal.show();
    }

    /**
     * Atualiza informações do mapa
     */
    updateMapInfo(latlng) {
        const info = `Lat: ${latlng.lat.toFixed(5)}, Lng: ${latlng.lng.toFixed(5)} | Zoom: ${this.map.getZoom()}`;
        document.getElementById('mapInfo').innerHTML = `<small class="text-muted">${info}</small>`;
    }

    /**
     * Obtém bounds do mapa atual
     */
    getCurrentBounds() {
        return this.map.getBounds();
    }

    /**
     * Obtém referência do mapa
     */
    getMap() {
        return this.map;
    }

    /**
     * VALIDAÇÃO EM TEMPO REAL durante o desenho
     * Verifica se o polígono em progresso está sobrepondo territórios existentes
     */
    validateDrawingInProgress(layers) {
        try {
            // Obter pontos do desenho atual
            const points = [];
            layers.eachLayer(marker => {
                if (marker.getLatLng) {
                    const ll = marker.getLatLng();
                    points.push([ll.lng, ll.lat]);
                }
            });

            console.log(`🔍 Validação em tempo real: ${points.length} pontos`);

            if (points.length < 3) return; // Precisa de pelo menos 3 pontos

            // Criar polígono temporário (fechar o polígono adicionando primeiro ponto no final)
            const closedPoints = [...points, points[0]];
            const tempPolygon = turf.polygon([closedPoints]);

            // Obter territórios existentes
            const existingGeometries = this.getExistingTerritoriesGeometries();
            
            console.log(`📍 Territórios existentes para verificar: ${existingGeometries.length}`);
            
            if (existingGeometries.length === 0) {
                console.log('⚠️ Nenhum território existente para validar!');
                this.clearOverlapWarning();
                return;
            }

            // Verificar sobreposição
            let hasOverlap = false;
            let overlappedNames = [];

            existingGeometries.forEach(existing => {
                try {
                    const intersects = turf.booleanIntersects(tempPolygon, existing);
                    if (intersects) {
                        hasOverlap = true;
                        const territoryId = existing.properties?.territory_id || 'Desconhecido';
                        overlappedNames.push(territoryId);
                        console.log(`⚠️ SOBREPOSIÇÃO com: ${territoryId}`);
                    }
                } catch (err) {
                    // Ignorar erros de geometria inválida durante desenho
                    console.log('⚠️ Erro validando geometria:', err.message);
                }
            });

            // Mostrar/ocultar aviso de sobreposição
            if (hasOverlap) {
                console.log(`🚫 SOBREPOSIÇÃO DETECTADA: ${overlappedNames.join(', ')}`);
                this.showOverlapWarning(overlappedNames);
            } else {
                console.log('✅ Sem sobreposição');
                this.clearOverlapWarning();
            }

        } catch (error) {
            // Ignorar erros durante validação em tempo real
            console.log('⚠️ Validação em tempo real (geometria incompleta):', error.message);
        }
    }

    /**
     * Mostra aviso de sobreposição em tempo real
     */
    showOverlapWarning(overlappedNames) {
        // Remover aviso anterior se existir
        this.clearOverlapWarning();

        // Criar elemento de aviso fixo na tela
        const warning = document.createElement('div');
        warning.id = 'overlap-warning';
        warning.className = 'overlap-warning-realtime';
        warning.innerHTML = `
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-exclamation-triangle-fill text-warning fs-4"></i>
                <div>
                    <strong>⚠️ SOBREPOSIÇÃO DETECTADA!</strong><br>
                    <small>Sobrepondo: ${overlappedNames.join(', ')}</small><br>
                    <small class="text-danger">Não será possível salvar sem aplicar TRIM</small>
                </div>
            </div>
        `;
        
        document.body.appendChild(warning);

        // Adicionar classe ao container do mapa para feedback visual
        const mapContainer = this.map.getContainer();
        mapContainer.classList.add('has-overlap');
    }

    /**
     * Remove aviso de sobreposição
     */
    clearOverlapWarning() {
        const warning = document.getElementById('overlap-warning');
        if (warning) {
            warning.remove();
        }

        const mapContainer = this.map.getContainer();
        if (mapContainer) {
            mapContainer.classList.remove('has-overlap');
        }
    }

    /**
     * DEBUG: Verifica estado atual dos territórios de fundo
     */
    debugBackgroundTerritories() {
        console.log('=== DEBUG: Territórios de Fundo ===');
        console.log('Layers na camada polygons:', this.layers.polygons.getLayers().length);
        
        let count = 0;
        this.layers.polygons.eachLayer(layer => {
            count++;
            console.log(`Layer ${count}:`, layer);
            if (layer.territoryData) {
                console.log('  - TerritoryData:', layer.territoryData);
            }
            if (layer.getLayers) {
                console.log('  - SubLayers:', layer.getLayers().length);
                layer.eachLayer(sub => {
                    console.log('    - SubLayer:', sub);
                    if (sub.territoryData) {
                        console.log('      TerritoryData:', sub.territoryData);
                    }
                });
            }
        });
        
        const geometries = this.getExistingTerritoriesGeometries();
        console.log('Geometrias extraídas:', geometries.length);
        console.log('===================================');
    }

    /**
     * Carrega e exibe territórios existentes em segundo plano
     * Mostra polígonos com cor esmaecida para indicar áreas já ocupadas
     */
    async loadBackgroundTerritories() {
        try {
            console.log('🔄 Carregando territórios e sub-territórios de fundo...');

            // Buscar territórios simplificados do banco
            const territories = await window.app.dataManager.getAllTerritoriesForBackground();

            if (!territories || territories.length === 0) {
                console.log('ℹ️ Nenhum território existente para exibir');
                return;
            }

            // Limpar camada de fundo anterior
            this.layers.polygons.clearLayers();
            
            // Buscar TODOS os sub-territórios de uma vez
            let allSubTerritories = [];
            try {
                // Buscar sub-territórios de todos os territórios
                const subTerritoriesPromises = territories.map(t => 
                    window.app.dataManager.listSubTerritories(t.id).catch(() => [])
                );
                const subTerritoriesArrays = await Promise.all(subTerritoriesPromises);
                allSubTerritories = subTerritoriesArrays.flat();
                console.log(`📋 ${allSubTerritories.length} sub-territórios encontrados`);
            } catch (err) {
                console.warn('⚠️ Erro ao buscar sub-territórios:', err);
            }

            // Adicionar territórios em lote (mais eficiente)
            const batchSize = 10; // Processar 10 por vez para não travar UI
            for (let i = 0; i < territories.length; i += batchSize) {
                const batch = territories.slice(i, i + batchSize);
                
                // Processar lote
                batch.forEach(territory => {
                try {
                    if (!territory.geometry) return;

                    // Criar layer do polígono
                    const layer = L.geoJSON(territory.geometry, {
                        style: {
                            color: '#7c8c9a',           // Cinza médio
                            fillColor: '#b0bec5',       // Cinza azulado
                            fillOpacity: 0.35,          // Mais visível mas ainda em segundo plano
                            weight: 2,                  // Borda mais visível
                            dashArray: '5, 5',          // Linha tracejada
                            opacity: 0.6
                        },
                        pane: 'carPane' // Usar pane de segundo plano
                    });

                    // IMPORTANTE: Armazenar territoryData em TODOS os sublayers
                    layer.territoryData = territory;
                    layer.eachLayer(subLayer => {
                        subLayer.territoryData = territory;
                    });

                    // Referência ao map manager para usar no evento
                    const mapManagerRef = this;

                    // Função para gerar tooltip dinâmico com percentuais de sobreposição
                    const generateTooltipContent = (terr, overlapInfo = null) => {
                        let overlapHtml = '';
                        if (overlapInfo && overlapInfo.length > 0) {
                            // Ordenar por percentual (maior para menor)
                            const sorted = [...overlapInfo].sort((a, b) => b.percent - a.percent);

                            // Calcular total e limite de 80% do total
                            const totalPercent = sorted.reduce((sum, o) => sum + o.percent, 0);
                            const threshold = totalPercent * 0.8;

                            // Mostrar itens até acumular 80% do total, resto vai para "Outros"
                            const mainItems = [];
                            const otherItems = [];
                            let accumulated = 0;

                            for (const item of sorted) {
                                if (accumulated < threshold) {
                                    mainItems.push(item);
                                    accumulated += item.percent;
                                } else {
                                    otherItems.push(item);
                                }
                            }

                            // Agrupar itens restantes em "Outros"
                            let otherEntry = null;
                            if (otherItems.length > 0) {
                                const otherPercent = otherItems.reduce((sum, o) => sum + o.percent, 0);
                                const otherArea = otherItems.reduce((sum, o) => sum + o.area, 0);
                                otherEntry = { centro: 'Outros', percent: otherPercent, area: otherArea, color: '#6b7280' };
                            }

                            // Montar lista final
                            const displayItems = [...mainItems];
                            if (otherEntry) displayItems.push(otherEntry);

                            overlapHtml = `
                                <hr style="margin: 6px 0; border-color: #e2e8f0;">
                                <small class="text-muted"><b>Áreas por Centro:</b></small><br>
                                ${displayItems.map(o => `
                                    <small style="color: ${o.color};">● ${o.centro}: <b>${o.percent.toFixed(1)}%</b> (${o.area.toFixed(2)} ha)</small>
                                `).join('<br>')}
                            `;
                        }

                        return `
                            <div class="bg-white p-2 shadow-sm rounded" style="min-width: 180px;">
                                <div style="border-bottom: 2px solid #3b82f6; padding-bottom: 4px; margin-bottom: 6px;">
                                    <strong style="color: #1e40af;">${terr.territory_id || 'N/A'}</strong>
                                    ${terr.center_key ? `<span class="badge bg-primary ms-1" style="font-size: 0.65rem;">${terr.center_key}</span>` : ''}
                                </div>
                                <small><b>Nome:</b> ${terr.name || 'N/A'}</small><br>
                                <small><b>Centro:</b> ${terr.center_name || 'N/A'}</small><br>
                                <small><b>Área Total:</b> <span style="color: #059669; font-weight: 600;">${terr.area_hectares?.toFixed(2) || 0} ha</span></small>
                                ${overlapHtml}
                            </div>
                        `;
                    };

                    // Tooltip inicial (sem percentuais)
                    layer.bindTooltip(generateTooltipContent(territory), {
                        sticky: true,
                        className: 'territory-tooltip'
                    });

                    // Eventos de hover para destacar e calcular sobreposição
                    layer.on('mouseover', function(e) {
                        const targetLayer = e.target;
                        targetLayer.setStyle({
                            fillOpacity: 0.6,
                            weight: 3,
                            color: '#546e7a',
                            opacity: 0.9
                        });

                        // Calcular sobreposição com propriedades do layer "Áreas por Unidade"
                        if (mapManagerRef.layers?.consultores && mapManagerRef.layers.consultores.getLayers().length > 0) {
                            try {
                                const territoryGeo = targetLayer.territoryData?.geometry || targetLayer.toGeoJSON();
                                const territoryFeature = territoryGeo.type === 'Feature' ? territoryGeo : turf.feature(territoryGeo);
                                const territoryArea = turf.area(territoryFeature) / 10000; // em hectares

                                // Agrupar áreas por centro
                                const centroAreas = new Map();

                                mapManagerRef.layers.consultores.eachLayer(propLayer => {
                                    try {
                                        const propGeo = propLayer.toGeoJSON();
                                        if (!propGeo.features || propGeo.features.length === 0) return;

                                        propGeo.features.forEach(feat => {
                                            const centro = feat.properties?.centro || 'Sem Centro';
                                            const color = propLayer.options?.style?.color || '#666';

                                            // Calcular interseção
                                            const intersection = turf.intersect(territoryFeature, feat);
                                            if (intersection) {
                                                const intersectArea = turf.area(intersection) / 10000;

                                                if (!centroAreas.has(centro)) {
                                                    centroAreas.set(centro, { area: 0, color: color });
                                                }
                                                centroAreas.get(centro).area += intersectArea;
                                            }
                                        });
                                    } catch (err) {
                                        // Ignorar erros de geometria inválida
                                    }
                                });

                                // Converter para array e calcular percentuais
                                const overlapInfo = [];
                                centroAreas.forEach((value, key) => {
                                    overlapInfo.push({
                                        centro: key,
                                        area: value.area,
                                        color: value.color,
                                        percent: (value.area / territoryArea) * 100
                                    });
                                });

                                // Ordenar por percentual (maior primeiro)
                                overlapInfo.sort((a, b) => b.percent - a.percent);

                                // Atualizar tooltip com percentuais
                                if (overlapInfo.length > 0) {
                                    targetLayer.setTooltipContent(generateTooltipContent(targetLayer.territoryData, overlapInfo));
                                }
                            } catch (err) {
                                console.warn('Erro ao calcular sobreposição:', err);
                            }
                        }
                    });

                    layer.on('mouseout', function(e) {
                        const targetLayer = e.target;
                        targetLayer.setStyle({
                            fillOpacity: 0.35,
                            weight: 2,
                            color: '#7c8c9a',
                            opacity: 0.6
                        });

                        // Restaurar tooltip original (sem percentuais para performance)
                        targetLayer.setTooltipContent(generateTooltipContent(targetLayer.territoryData));
                    });

                    // Adicionar à camada de polígonos
                    layer.addTo(this.layers.polygons);

                } catch (err) {
                    console.error('Erro ao processar território:', territory.territory_id, err);
                }
            });

                // Pequeno delay entre lotes para não travar UI
                if (i + batchSize < territories.length) {
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            }

            console.log(`✅ ${territories.length} territórios carregados em segundo plano`);
            
            // NOVO: Adicionar sub-territórios esmaecidos com cor diferente
            if (allSubTerritories.length > 0) {
                console.log(`🟠 Renderizando ${allSubTerritories.length} sub-territórios...`);
                
                let renderedCount = 0;
                
                allSubTerritories.forEach(subTerritory => {
                    try {
                        if (!subTerritory.geometry) {
                            console.warn(`⚠️ Sub-território ${subTerritory.carteira_id} sem geometria, pulando...`);
                            return;
                        }
                        
                        const geometry = typeof subTerritory.geometry === 'string' 
                            ? JSON.parse(subTerritory.geometry) 
                            : subTerritory.geometry;
                        
                        console.log(`   📌 Renderizando: ${subTerritory.carteira_id} (${subTerritory.area_hectares?.toFixed(2)} ha)`);
                        
                        // Criar layer do sub-território com cor DOURADA CHAMATIVA
                        const layer = L.geoJSON(geometry, {
                            style: {
                                color: this.territoryColors.subTerritory,      // Gold/Ouro
                                fillColor: this.territoryColors.subTerritoryFill, // Orange Gold
                                fillOpacity: 0.25,          // Visível mas não domina
                                weight: 2,                  // Borda visível
                                dashArray: '3, 3',          // Linha tracejada
                                opacity: 0.8                // Borda bem visível
                            },
                            pane: 'carPane' // Usar pane de segundo plano
                        });
                        
                        // Armazenar dados do sub-território
                        layer.subTerritoryData = subTerritory;
                        layer.eachLayer(subLayer => {
                            subLayer.subTerritoryData = subTerritory;
                        });
                        
                        // Adicionar tooltip
                        const tooltipContent = `
                            <div class="bg-warning bg-opacity-10 p-2 shadow-sm rounded border border-warning">
                                <strong class="text-warning">🟠 ${subTerritory.carteira_id || 'N/A'}</strong><br>
                                <small>${subTerritory.name || ''}</small><br>
                                <small class="text-muted">${subTerritory.area_hectares?.toFixed(2) || 0} ha</small>
                            </div>
                        `;
                        
                        layer.bindTooltip(tooltipContent, {
                            sticky: true,
                            className: 'sub-territory-tooltip'
                        });
                        
                        // Eventos de hover para destacar
                        layer.on('mouseover', function(e) {
                            const targetLayer = e.target;
                            targetLayer.setStyle({
                                fillOpacity: 0.35,
                                weight: 2.5,
                                color: '#ea580c',
                                opacity: 0.7
                            });
                        });
                        
                        layer.on('mouseout', function(e) {
                            const targetLayer = e.target;
                            const colors = window.app.map.territoryColors;
                            targetLayer.setStyle({
                                fillOpacity: 0.25,
                                weight: 2,
                                color: colors.subTerritory,
                                opacity: 0.8
                            });
                        });
                        
                        // Adicionar à camada de polígonos
                        layer.addTo(this.layers.polygons);
                        renderedCount++;
                        
                    } catch (err) {
                        console.error('Erro ao processar sub-território:', subTerritory.carteira_id, err);
                    }
                });
                
                console.log(`✅ ${renderedCount}/${allSubTerritories.length} sub-territórios renderizados com sucesso`);
            }

            // Armazenar para uso no trim
            this.backgroundTerritories = territories;
            this.backgroundSubTerritories = allSubTerritories;

        } catch (error) {
            console.error('❌ Erro ao carregar territórios de fundo:', error);
        }
    }

    /**
     * Carrega e exibe áreas (propriedades) coloridas por consultor
     * Layer de fundo não editável para visualização
     * @param {string} centerKey - Chave do centro (ex: 'C001')
     */
    async loadAreasByConsultor(centerKey) {
        try {
            console.log(`🎨 Carregando áreas por consultor para centro: ${centerKey}`);

            // Limpar camada anterior
            this.layers.consultores.clearLayers();

            // Buscar dados do banco
            const result = await window.app.dataManager.getAreasByConsultor(centerKey);
            
            if (!result || result.error) {
                console.error('❌ Erro ao buscar áreas por consultor:', result?.error);
                return;
            }

            const data = result.data || [];

            if (!data || data.length === 0) {
                console.log('ℹ️ Nenhuma área encontrada para este centro');
                return;
            }

            console.log(`📊 ${data.length} áreas encontradas`);

            // Criar mapa de cores por consultor
            const consultorColorMap = new Map();
            let colorIndex = 0;

            data.forEach(item => {
                const consultor = item.consultor || 'Sem Consultor';
                if (!consultorColorMap.has(consultor)) {
                    consultorColorMap.set(consultor, this.consultorColors[colorIndex % this.consultorColors.length]);
                    colorIndex++;
                }
            });

            // Renderizar áreas
            let areasRendered = 0;
            
            data.forEach(area => {
                try {
                    if (!area.location) return;

                    const consultor = area.consultor || 'Sem Consultor';
                    const color = consultorColorMap.get(consultor);

                    // Parse da geometria (agora é GeoJSON direto da função)
                    const geometry = area.location;

                        // Criar layer
                        const layer = L.geoJSON(geometry, {
                            style: {
                                color: color,
                                fillColor: color,
                                fillOpacity: 0.45,      // Mais vívido (era 0.25)
                                weight: 2,              // Borda um pouco mais grossa
                                opacity: 0.75,          // Borda mais visível (era 0.5)
                                dashArray: '4, 4'       // Linha tracejada
                            },
                            pane: 'consultoresPane',    // Usar pane de fundo
                            interactive: false          // Não interferir com interações
                        });

                        // Adicionar tooltip com informações
                        const tooltipContent = `
                            <div class="p-2 shadow-sm rounded" style="background: ${color}20; border: 1px solid ${color};">
                                <strong style="color: ${color};">👤 ${consultor}</strong><br>
                                <small><b>Cliente:</b> ${area.cliente || 'N/A'}</small><br>
                                <small><b>Insumos:</b> ${area.insumos || 0}%</small><br>
                                <small><b>Grãos:</b> ${area.graos || 'N/A'}</small><br>
                                <small><b>Tempo:</b> ${area.tempo_atendimento || 'N/A'}</small>
                            </div>
                        `;

                        layer.bindTooltip(tooltipContent, {
                            sticky: true,
                            className: 'consultor-tooltip',
                            opacity: 0.95
                        });

                        // Hover para destacar levemente
                        layer.on('mouseover', function(e) {
                            const targetLayer = e.target;
                            targetLayer.setStyle({
                                fillOpacity: 0.65,      // Destaque maior no hover
                                weight: 3,
                                opacity: 0.9
                            });
                        });

                        layer.on('mouseout', function(e) {
                            const targetLayer = e.target;
                            targetLayer.setStyle({
                                fillOpacity: 0.45,      // Volta ao estado vívido
                                weight: 2,
                                opacity: 0.75
                            });
                        });

                    // Adicionar à camada
                    layer.addTo(this.layers.consultores);
                    areasRendered++;

                } catch (err) {
                    console.error('Erro ao processar área:', err);
                }
            });

            console.log(`✅ ${areasRendered} áreas renderizadas por consultor`);
            
            // Log da legenda de cores
            console.log('🎨 Legenda de cores:');
            consultorColorMap.forEach((color, consultor) => {
                console.log(`   ${consultor}: ${color}`);
            });

            // Atualizar legenda visual
            this.updateConsultorLegend(consultorColorMap, data);

            // Adicionar ao Layer Control se ainda não foi adicionado
            if (this.layerControl && !this.consultoresLayerAdded) {
                this.layerControl.addOverlay(this.layers.consultores, '🎨 Áreas por Consultor');
                this.consultoresLayerAdded = true;
                console.log('✅ Camada Consultores adicionada ao Layer Control');
            }

        } catch (error) {
            console.error('❌ Erro ao carregar áreas por consultor:', error);
        }
    }

    /**
     * Atualiza a legenda visual de consultores
     * @param {Map} consultorColorMap - Mapa de consultor -> cor
     * @param {Array} data - Array de áreas para contar por consultor
     */
    updateConsultorLegend(consultorColorMap, data) {
        const legendElement = document.getElementById('consultorLegend');
        const legendContent = document.getElementById('legendContent');

        if (!legendElement || !legendContent) return;

        // Contar áreas por consultor
        const consultorCounts = new Map();
        data.forEach(area => {
            const consultor = area.consultor || 'Sem Consultor';
            consultorCounts.set(consultor, (consultorCounts.get(consultor) || 0) + 1);
        });

        // Limpar conteúdo anterior
        legendContent.innerHTML = '';

        // Criar itens da legenda ordenados alfabeticamente
        const sortedConsultores = Array.from(consultorColorMap.keys()).sort();

        sortedConsultores.forEach(consultor => {
            const color = consultorColorMap.get(consultor);
            const count = consultorCounts.get(consultor) || 0;

            const legendItem = document.createElement('div');
            legendItem.className = 'legend-item';
            legendItem.innerHTML = `
                <div class="legend-color" style="background-color: ${color};"></div>
                <div class="legend-label">${consultor}</div>
                <div class="legend-count">${count}</div>
            `;

            legendContent.appendChild(legendItem);
        });

        // Mostrar legenda
        legendElement.style.display = 'block';

        console.log('📋 Legenda de consultores atualizada');
    }

    /**
     * Esconde a legenda de consultores
     */
    hideConsultorLegend() {
        const legendElement = document.getElementById('consultorLegend');
        if (legendElement) {
            legendElement.style.display = 'none';
        }
    }

    /**
     * Limpa a camada de áreas por consultor
     */
    clearAreasByConsultor() {
        if (this.layers.consultores) {
            this.layers.consultores.clearLayers();
            console.log('🗑️ Camada de áreas por consultor limpa');
        }
        // Esconder legenda
        this.hideConsultorLegend();
    }

    /**
     * Carrega áreas por unidade (centro) - todas as propriedades da região
     * Usa cores e legendas de Centro ao invés de Consultor
     * Layer de fundo não editável para visualização
     * @param {string} centerKey - Chave do centro (ex: 'C001')
     */
    async loadAreasByUnidade(centerKey) {
        try {
            console.log(`🏢 Carregando áreas por unidade (centro) para: ${centerKey}`);

            // Limpar camada anterior
            this.layers.consultores.clearLayers();

            // Buscar dados do banco usando a nova função
            const result = await window.app.dataManager.getAreasByUnidade(centerKey);
            
            if (!result || result.error) {
                console.error('❌ Erro ao buscar áreas por unidade:', result?.error);
                return;
            }

            const data = result.data || [];

            if (!data || data.length === 0) {
                console.log('ℹ️ Nenhuma área encontrada para esta região');
                return;
            }

            console.log(`📊 ${data.length} áreas encontradas na região`);

            // Criar mapa de cores por CENTRO (unidade) ao invés de consultor
            const centroColorMap = new Map();
            let colorIndex = 0;

            data.forEach(item => {
                const centro = item.centro_nome || item.centro_chave || 'Sem Centro';
                if (!centroColorMap.has(centro)) {
                    // Usar as mesmas cores de consultor, mas agora para centros
                    centroColorMap.set(centro, this.consultorColors[colorIndex % this.consultorColors.length]);
                    colorIndex++;
                }
            });

            // Renderizar áreas
            let areasRendered = 0;
            
            data.forEach(area => {
                try {
                    if (!area.location) return;

                    const centro = area.centro_nome || area.centro_chave || 'Sem Centro';
                    const color = centroColorMap.get(centro);

                    // Criar Feature GeoJSON completo
                    const feature = {
                        type: 'Feature',
                        geometry: area.location, // ST_AsGeoJSON já retorna geometria válida
                        properties: {
                            centro: centro,
                            cliente: area.cliente,
                            consultor: area.consultor
                        }
                    };

                    // Criar layer
                    const layer = L.geoJSON(feature, {
                        style: {
                            color: color,
                            fillColor: color,
                            fillOpacity: 0.45,      // Mais vívido
                            weight: 2,              // Borda um pouco mais grossa
                            opacity: 0.75,          // Borda mais visível
                            dashArray: '4, 4'       // Linha tracejada
                        },
                        pane: 'consultoresPane',    // Usar pane de fundo
                        interactive: false          // Não interferir com interações
                    });

                    // Adicionar tooltip com informações
                    const tooltipContent = `
                        <div class="p-2 shadow-sm rounded" style="background: ${color}20; border: 1px solid ${color};">
                            <strong style="color: ${color};">🏢 ${centro}</strong><br>
                            <small><b>Consultor:</b> ${area.consultor || 'N/A'}</small><br>
                            <small><b>Cliente:</b> ${area.cliente || 'N/A'}</small><br>
                            <small><b>Insumos:</b> ${area.insumos || 0}%</small><br>
                            <small><b>Grãos:</b> ${area.graos || 'N/A'}</small><br>
                            <small><b>Tempo:</b> ${area.tempo_atendimento || 'N/A'}</small>
                        </div>
                    `;

                    layer.bindTooltip(tooltipContent, {
                        sticky: true,
                        className: 'consultor-tooltip',
                        opacity: 0.95
                    });

                    // Hover para destacar levemente
                    layer.on('mouseover', function(e) {
                        const targetLayer = e.target;
                        targetLayer.setStyle({
                            fillOpacity: 0.65,      // Destaque maior no hover
                            weight: 3,
                            opacity: 0.9
                        });
                    });

                    layer.on('mouseout', function(e) {
                        const targetLayer = e.target;
                        targetLayer.setStyle({
                            fillOpacity: 0.45,      // Volta ao estado vívido
                            weight: 2,
                            opacity: 0.75
                        });
                    });

                    // Adicionar à camada
                    layer.addTo(this.layers.consultores);
                    areasRendered++;

                } catch (err) {
                    console.error('Erro ao processar área:', err);
                }
            });

            console.log(`✅ ${areasRendered} áreas renderizadas por unidade (centro)`);
            
            // Log da legenda de cores
            console.log('🎨 Legenda de cores por centro:');
            centroColorMap.forEach((color, centro) => {
                console.log(`   ${centro}: ${color}`);
            });

            // Atualizar legenda visual (usando a mesma função, mas com dados de centro)
            this.updateUnidadeLegend(centroColorMap, data);

            // Adicionar ao Layer Control se ainda não foi adicionado
            if (this.layerControl && !this.consultoresLayerAdded) {
                this.layerControl.addOverlay(this.layers.consultores, '🏢 Áreas por Unidade');
                this.consultoresLayerAdded = true;
                console.log('✅ Camada Unidades adicionada ao Layer Control');
            }

        } catch (error) {
            console.error('❌ Erro ao carregar áreas por unidade:', error);
        }
    }

    /**
     * Atualiza a legenda visual de unidades (centros)
     * @param {Map} centroColorMap - Mapa de centro -> cor
     * @param {Array} data - Array de áreas para contar por centro
     */
    updateUnidadeLegend(centroColorMap, data) {
        const legendElement = document.getElementById('consultorLegend');
        const legendContent = document.getElementById('legendContent');

        if (!legendElement || !legendContent) return;

        // Contar áreas por centro
        const centroCounts = new Map();
        data.forEach(area => {
            const centro = area.centro_nome || area.centro_chave || 'Sem Centro';
            centroCounts.set(centro, (centroCounts.get(centro) || 0) + 1);
        });

        // Limpar conteúdo anterior
        legendContent.innerHTML = '';

        // Criar itens da legenda ordenados alfabeticamente
        const sortedCentros = Array.from(centroColorMap.keys()).sort();

        sortedCentros.forEach(centro => {
            const color = centroColorMap.get(centro);
            const count = centroCounts.get(centro) || 0;

            const legendItem = document.createElement('div');
            legendItem.className = 'legend-item';
            legendItem.innerHTML = `
                <div class="legend-color" style="background-color: ${color};"></div>
                <div class="legend-label">🏢 ${centro}</div>
                <div class="legend-count">${count}</div>
            `;

            legendContent.appendChild(legendItem);
        });

        // Mostrar legenda
        legendElement.style.display = 'block';

        console.log('📋 Legenda de unidades (centros) atualizada');
    }

    /**
     * Obtém todas as geometrias dos territórios existentes para Trim
     * @returns {Array} Array de GeoJSON Features
     */
    getExistingTerritoriesGeometries() {
        const geometries = [];
        
        console.log('🔍 getExistingTerritoriesGeometries: Iniciando busca...');
        console.log(`   Layers na camada polygons: ${this.layers.polygons.getLayers().length}`);
        
        // Percorrer camada de polígonos (territórios de fundo)
        this.layers.polygons.eachLayer(layer => {
            try {
                console.log('   Layer:', layer.constructor.name, 'tem getLayers?', !!layer.getLayers);
                
                // Se é GeoJSON layer, percorrer sublayers
                if (layer.getLayers) {
                    const sublayers = layer.getLayers();
                    console.log(`     Sublayers encontrados: ${sublayers.length}`);
                    
                    layer.eachLayer(subLayer => {
                        console.log('       Sublayer:', subLayer.constructor.name, 'tem territoryData?', !!subLayer.territoryData, 'tem subTerritoryData?', !!subLayer.subTerritoryData);
                        
                        // 🔧 CORREÇÃO: Capturar tanto territórios quanto sub-territórios
                        if (subLayer.territoryData && subLayer.territoryData.geometry) {
                            console.log(`       ✅ Adicionando TERRITÓRIO: ${subLayer.territoryData.territory_id}`);
                            
                            // Garantir que geometry é um objeto, não string
                            let rawGeometry = typeof subLayer.territoryData.geometry === 'string' 
                                ? JSON.parse(subLayer.territoryData.geometry) 
                                : subLayer.territoryData.geometry;
                            
                            // Se rawGeometry é um Feature, extrair apenas a geometria
                            const geometry = rawGeometry.type === 'Feature' ? rawGeometry.geometry : rawGeometry;
                            
                            console.log(`          📐 Tipo de geometria: ${geometry.type || 'DESCONHECIDO'}`);
                            
                            geometries.push({
                                type: 'Feature',
                                geometry: geometry,
                                properties: {
                                    id: subLayer.territoryData.id,
                                    territory_id: subLayer.territoryData.territory_id,
                                    type: 'territory'
                                }
                            });
                        }
                        
                        // 🟠 NOVO: Adicionar sub-territórios (carteiras)
                        if (subLayer.subTerritoryData && subLayer.subTerritoryData.geometry) {
                            let rawGeometry = typeof subLayer.subTerritoryData.geometry === 'string' 
                                ? JSON.parse(subLayer.subTerritoryData.geometry) 
                                : subLayer.subTerritoryData.geometry;
                            
                            // Se rawGeometry é um Feature, extrair apenas a geometria
                            const geometry = rawGeometry.type === 'Feature' ? rawGeometry.geometry : rawGeometry;
                            
                            console.log(`       🟠 Adicionando SUB-TERRITÓRIO: ${subLayer.subTerritoryData.carteira_id}`);
                            console.log(`          📐 Tipo de geometria: ${geometry.type || 'DESCONHECIDO'}`);
                            
                            geometries.push({
                                type: 'Feature',
                                geometry: geometry,
                                properties: {
                                    id: subLayer.subTerritoryData.id,
                                    territory_id: subLayer.subTerritoryData.carteira_id,
                                    type: 'sub-territory'
                                }
                            });
                        }
                    });
                } else if (layer.territoryData && layer.territoryData.geometry) {
                    // Layer direto com territoryData
                    console.log(`     ✅ Layer direto - Adicionando território: ${layer.territoryData.territory_id}`);
                    
                    // Garantir que geometry é um objeto, não string
                    let rawGeometry = typeof layer.territoryData.geometry === 'string' 
                        ? JSON.parse(layer.territoryData.geometry) 
                        : layer.territoryData.geometry;
                    
                    // Se rawGeometry é um Feature, extrair apenas a geometria
                    const geometry = rawGeometry.type === 'Feature' ? rawGeometry.geometry : rawGeometry;
                    
                    console.log(`        📐 Tipo de geometria: ${geometry.type || 'DESCONHECIDO'}`);
                    
                    geometries.push({
                        type: 'Feature',
                        geometry: geometry,
                        properties: {
                            id: layer.territoryData.id,
                            territory_id: layer.territoryData.territory_id,
                            type: 'territory'
                        }
                    });
                } else if (layer.subTerritoryData && layer.subTerritoryData.geometry) {
                    // 🟠 NOVO: Layer direto com subTerritoryData
                    let rawGeometry = typeof layer.subTerritoryData.geometry === 'string' 
                        ? JSON.parse(layer.subTerritoryData.geometry) 
                        : layer.subTerritoryData.geometry;
                    
                    // Se rawGeometry é um Feature, extrair apenas a geometria
                    const geometry = rawGeometry.type === 'Feature' ? rawGeometry.geometry : rawGeometry;
                    
                    console.log(`     🟠 Layer direto - Adicionando sub-território: ${layer.subTerritoryData.carteira_id}`);
                    console.log(`        📐 Tipo de geometria: ${geometry.type || 'DESCONHECIDO'}`);
                    
                    geometries.push({
                        type: 'Feature',
                        geometry: geometry,
                        properties: {
                            id: layer.subTerritoryData.id,
                            territory_id: layer.subTerritoryData.carteira_id,
                            type: 'sub-territory'
                        }
                    });
                }
            } catch (err) {
                console.error('❌ Erro ao processar layer para geometrias:', err);
            }
        });

        console.log(`🔍 Geometrias existentes encontradas: ${geometries.length}`);
        if (geometries.length > 0) {
            const territories = geometries.filter(g => g.properties.type === 'territory');
            const subTerritories = geometries.filter(g => g.properties.type === 'sub-territory');
            console.log(`   • Territórios: ${territories.length} (${territories.map(g => g.properties.territory_id).join(', ')})`);
            console.log(`   • Sub-territórios: ${subTerritories.length} (${subTerritories.map(g => g.properties.territory_id).join(', ')})`);
        } else {
            console.warn('⚠️ NENHUMA geometria encontrada!');
        }

        return geometries;
    }

    /**
     * Aplica destaque visual ao território quando selecionado
     */
    highlightTerritory(territoryId) {
        this.layers.polygons.eachLayer(layer => {
            if (layer.territoryData && layer.territoryData.territory_id === territoryId) {
                layer.setStyle({
                    color: '#3498db',
                    fillColor: '#3498db',
                    fillOpacity: 0.4,
                    weight: 3,
                    dashArray: null
                });
            }
        });
    }

    /**
     * Remove destaque visual do território
     */
    unhighlightTerritory(territoryId) {
        this.layers.polygons.eachLayer(layer => {
            if (layer.territoryData && layer.territoryData.territory_id === territoryId) {
                layer.setStyle({
                    color: '#95a5a6',
                    fillColor: '#ecf0f1',
                    fillOpacity: 0.2,
                    weight: 1,
                    dashArray: '5, 5'
                });
            }
        });
    }

    /**
     * Verifica sobreposição com territórios existentes
     * @param {L.Layer} newLayer - Novo polígono desenhado
     * @param {Array} existingGeometries - Geometrias existentes
     * @returns {Object} Resultado da verificação
     */
    checkOverlap(newLayer, existingGeometries) {
        try {
            console.log('🔍 Verificando sobreposição...');
            console.log(`   - Territórios existentes: ${existingGeometries.length}`);
            
            const newGeoJSON = window.app.polygonTools._toGeoJSON(newLayer);
            console.log('   - Novo polígono convertido para GeoJSON');
            
            const overlappedTerritories = [];
            
            existingGeometries.forEach((existing, index) => {
                try {
                    const intersects = turf.booleanIntersects(newGeoJSON, existing);
                    console.log(`   - Território ${index + 1} (${existing.properties.territory_id}): ${intersects ? 'SOBREPÕE' : 'OK'}`);
                    if (intersects) {
                        overlappedTerritories.push(existing);
                    }
                } catch (err) {
                    console.error(`   - Erro ao verificar território ${existing.properties.territory_id}:`, err);
                }
            });
            
            console.log(`   - Total de sobreposições: ${overlappedTerritories.length}`);
            
            return {
                hasOverlap: overlappedTerritories.length > 0,
                overlappedTerritories: overlappedTerritories,
                count: overlappedTerritories.length
            };
        } catch (error) {
            console.error('❌ Erro ao verificar sobreposição:', error);
            console.error('Stack:', error.stack);
            return {
                hasOverlap: false,
                overlappedTerritories: [],
                count: 0
            };
        }
    }

    /**
     * Mostra modal de confirmação de TRIM com preview visual
     * @param {L.Layer} originalLayer - Polígono original
     * @param {GeoJSON} trimmedGeoJSON - Polígono após TRIM
     * @param {Object} overlapResult - Resultado da verificação de sobreposição
     * @param {Boolean} isEdit - Se true, está editando território existente
     */
    async showTrimConfirmationModal(originalLayer, trimmedGeoJSON, overlapResult, isEdit = false) {
        const self = this;
        
        // Calcular estatísticas
        const originalGeoJSON = window.app.polygonTools._toGeoJSON(originalLayer);
        const originalArea = turf.area(originalGeoJSON) / 10000; // hectares
        const trimmedArea = turf.area(trimmedGeoJSON) / 10000; // hectares
        const areaLoss = originalArea - trimmedArea;
        const areaLossPercent = (areaLoss / originalArea) * 100;
        
        const originalVertices = originalGeoJSON.geometry.coordinates[0].length;
        const trimmedVertices = trimmedGeoJSON.geometry.coordinates[0].length;

        // Encontrar pontos de interseção
        const intersectionPoints = window.app.polygonTools.findAllIntersectionPoints(
            originalLayer, 
            overlapResult.overlappedTerritories
        );
        console.log(`🎯 ${intersectionPoints.length} pontos de interseção encontrados`);
        
        // Preencher dados no modal (apenas campos que existem)
        const trimBeforeArea = document.getElementById('trimBeforeArea');
        const trimBeforeVertices = document.getElementById('trimBeforeVertices');
        const trimAfterArea = document.getElementById('trimAfterArea');
        const trimAfterVertices = document.getElementById('trimAfterVertices');
        
        if (trimBeforeArea) trimBeforeArea.textContent = `${originalArea.toFixed(2)} ha`;
        if (trimBeforeVertices) trimBeforeVertices.textContent = originalVertices;
        if (trimAfterArea) trimAfterArea.textContent = `${trimmedArea.toFixed(2)} ha`;
        if (trimAfterVertices) trimAfterVertices.textContent = trimmedVertices;
        
        // Listar territórios sobrepostos
        const listContainer = document.getElementById('trimOverlappedList');
        if (listContainer) {
            listContainer.innerHTML = '';
            overlapResult.overlappedTerritories.forEach(territory => {
                const item = document.createElement('div');
                item.className = 'list-group-item';
                item.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${territory.properties.territory_id || 'N/A'}</strong>
                            <br>
                            <small class="text-muted">${territory.properties.name || 'Sem nome'}</small>
                        </div>
                        <i class="bi bi-exclamation-triangle text-warning"></i>
                    </div>
                `;
                listContainer.appendChild(item);
            });
        }
        
        // Criar layers de preview no mapa
        const previewLayers = {
            original: null,
            trimmed: null,
            intersectionMarkers: []
        };
        
        // Preview do polígono original (vermelho tracejado)
        previewLayers.original = L.geoJSON(originalGeoJSON, {
            className: 'trim-preview-original',
            style: {
                color: '#dc3545',
                fillColor: '#dc3545',
                fillOpacity: 0.1,
                weight: 3,
                dashArray: '10, 5'
            }
        }).addTo(this.map);
        
        // Preview do polígono trimmed (verde)
        previewLayers.trimmed = L.geoJSON(trimmedGeoJSON, {
            className: 'trim-preview-trimmed',
            style: {
                color: '#28a745',
                fillColor: '#28a745',
                fillOpacity: 0.3,
                weight: 3
            }
        }).addTo(this.map);

        // Adicionar marcadores nos pontos de interseção
        intersectionPoints.forEach(point => {
            // point.coordinates é [lng, lat], precisamos [lat, lng] para Leaflet
            const lat = point.coordinates[1];
            const lng = point.coordinates[0];
            
            const marker = L.circleMarker([lat, lng], {
                radius: 8,
                fillColor: '#ff0000',
                color: '#ffffff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8,
                className: 'intersection-point-marker'
            }).addTo(this.map);

            // Adicionar tooltip ao marcador
            marker.bindTooltip(`
                <div class="text-center">
                    <strong class="text-danger">⚠️ Interseção</strong><br>
                    <small>com ${point.territory}</small>
                </div>
            `, {
                permanent: false,
                direction: 'top',
                className: 'intersection-tooltip'
            });

            previewLayers.intersectionMarkers.push(marker);
        });
        
        // Zoom para visualizar ambos
        const bounds = L.geoJSON(originalGeoJSON).getBounds();
        this.map.fitBounds(bounds, { padding: [50, 50] });
        
        // Abrir modal
        const modal = new bootstrap.Modal(document.getElementById('modalTrimConfirmation'));
        modal.show();
        
        // Aguardar decisão do usuário
        return new Promise((resolve) => {
            const btnConfirm = document.getElementById('btnTrimConfirm');
            const btnCancel = document.getElementById('btnTrimCancel');
            
            const handleConfirm = async function() {
                console.log('✅ Usuário confirmou TRIM');
                
                // IMPORTANTE: Remover polígono original do mapa ANTES de adicionar o recortado
                console.log('🗑️ Removendo polígono original do mapa...');
                if (self.layers.drawings.hasLayer(originalLayer)) {
                    self.layers.drawings.removeLayer(originalLayer);
                    console.log('   ✅ Polígono original removido da camada de desenhos');
                } else if (self.map.hasLayer(originalLayer)) {
                    self.map.removeLayer(originalLayer);
                    console.log('   ✅ Polígono original removido do mapa direto');
                }
                
                // Remover previews
                self.map.removeLayer(previewLayers.original);
                self.map.removeLayer(previewLayers.trimmed);
                console.log('   ✅ Previews removidos');
                
                // Remover marcadores de interseção
                previewLayers.intersectionMarkers.forEach(marker => {
                    self.map.removeLayer(marker);
                });
                console.log('   ✅ Marcadores de interseção removidos');
                
                // Criar layer final com polígono trimmed
                const finalLayer = L.geoJSON(trimmedGeoJSON, {
                    style: {
                        color: CONFIG.ui.colors.territory,
                        fillOpacity: CONFIG.ui.opacity.fill,
                        weight: 2
                    }
                }).getLayers()[0];
                
                // Transferir dados do território se existir
                if (originalLayer.territoryData) {
                    finalLayer.territoryData = originalLayer.territoryData;
                    finalLayer.centerKey = originalLayer.centerKey;
                }
                
                // Definir pane para primeiro plano
                finalLayer.options.pane = 'drawingsPane';
                
                console.log('✅ Adicionando polígono recortado ao mapa (PRIMEIRO PLANO)...');
                self.layers.drawings.addLayer(finalLayer);
                self.currentPolygon = finalLayer;
                console.log('   ✅ Polígono recortado adicionado');
                
                // Fechar modal
                modal.hide();
                
                // Mostrar notificação de sucesso
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification(
                        `✅ TRIM aplicado com sucesso! Área ajustada: ${trimmedArea.toFixed(2)} ha`,
                        'success'
                    );
                }
                
                // VALIDAÇÃO CRÍTICA: Verificar se o TRIM realmente funcionou
                // Se as áreas são iguais, o trim falhou!
                if (Math.abs(originalArea - trimmedArea) < 0.01) {
                    console.error('❌ TRIM FALHOU - Áreas iguais após recorte!');
                    console.error(`   Original: ${originalArea.toFixed(2)} ha`);
                    console.error(`   Trimmed: ${trimmedArea.toFixed(2)} ha`);
                    console.error('   Diferença: 0.00 ha - NENHUMA MUDANÇA!');
                    
                    alert('❌ ERRO NO RECORTE!\n\n' +
                          'O sistema tentou aplicar o recorte mas FALHOU.\n' +
                          'As áreas antes e depois são idênticas.\n\n' +
                          'Possíveis causas:\n' +
                          '• Os polígonos se tocam mas não se sobrepõem\n' +
                          '• Erro na geometria do território existente\n\n' +
                          'Por favor, redesenhe o território evitando sobreposição.');
                    
                    // Remover previews
                    self.map.removeLayer(previewLayers.original);
                    self.map.removeLayer(previewLayers.trimmed);
                    previewLayers.intersectionMarkers.forEach(marker => self.map.removeLayer(marker));
                    
                    // Remover polígono original do mapa
                    self.layers.drawings.removeLayer(originalLayer);
                    
                    modal.hide();
                    resolve(false);
                    return;
                }
                
                console.log('✅ TRIM validado - diferença de área detectada');
                
                // Marcar que este polígono já passou pela validação de TRIM
                finalLayer._trimApplied = true;
                finalLayer._skipOverlapValidation = true;
                
                // Prosseguir com salvamento
                const area = self.calculateArea(finalLayer);
                
                if (isEdit && finalLayer.territoryData && finalLayer.territoryData.id) {
                    // Atualizar território existente no banco
                    try {
                        const geojson = finalLayer.toGeoJSON();
                        await window.app.dataManager.updateTerritory(finalLayer.territoryData.id, {
                            geometry: geojson.geometry,
                            area_hectares: area
                        });
                        console.log('✅ Território atualizado no banco');
                        
                        // Atualizar UI
                        if (window.app.uiController && finalLayer.territoryData.center_key) {
                            window.app.uiController.updateCenterItemArea(finalLayer.territoryData.center_key, area);
                        }
                        
                        window.app.uiController.showNotification('✅ Território atualizado com sucesso', 'success');
                    } catch (error) {
                        console.error('Erro ao atualizar território:', error);
                        window.app.uiController.showNotification('❌ Erro ao atualizar território', 'error');
                    }
                } else if (window.app && window.app.uiController && window.app.uiController.pendingTerritory) {
                    // Criar novo território
                    await self.savePendingTerritory(finalLayer, area);
                } else {
                    self.showPolygonDetails(finalLayer, area);
                }
                
                // Limpar event listeners
                btnConfirm.removeEventListener('click', handleConfirm);
                btnCancel.removeEventListener('click', handleCancel);
                
                resolve(true);
            };
            
            const handleCancel = function() {
                console.log('❌ Usuário cancelou TRIM - removendo polígono (sobreposição não permitida)');
                
                // IMPORTANTE: Remover polígono original se for novo desenho
                if (!isEdit) {
                    console.log('🗑️ Removendo polígono original (desenho novo)...');
                    if (self.layers.drawings.hasLayer(originalLayer)) {
                        self.layers.drawings.removeLayer(originalLayer);
                        console.log('   ✅ Polígono original removido da camada de desenhos');
                    } else if (self.map.hasLayer(originalLayer)) {
                        self.map.removeLayer(originalLayer);
                        console.log('   ✅ Polígono original removido do mapa direto');
                    }
                }
                
                // Remover previews
                self.map.removeLayer(previewLayers.original);
                self.map.removeLayer(previewLayers.trimmed);
                console.log('   ✅ Previews removidos');
                
                // Remover marcadores de interseção
                previewLayers.intersectionMarkers.forEach(marker => {
                    self.map.removeLayer(marker);
                });
                console.log('   ✅ Marcadores de interseção removidos');
                
                // Fechar modal
                modal.hide();
                
                if (isEdit) {
                    // Se está editando, reverter para o estado anterior
                    // O polígono original já estava no mapa
                    console.log('⚠️ Edição cancelada - polígono mantido no estado anterior');
                    
                    // Definir pane para primeiro plano
                    originalLayer.options.pane = 'drawingsPane';
                    
                    // Re-adicionar o layer original (PRIMEIRO PLANO)
                    self.layers.drawings.addLayer(originalLayer);
                    
                    if (window.app && window.app.uiController) {
                        window.app.uiController.showNotification(
                            '⚠️ Edição cancelada. Território mantido no estado anterior.',
                            'warning',
                            5000
                        );
                    }
                } else {
                    // Se é novo polígono, foi removido - sobreposição não é permitida
                    console.log('✅ Polígono novo removido - sobreposição não permitida');
                    
                    if (window.app && window.app.uiController) {
                        window.app.uiController.showNotification(
                            '❌ Polígono removido. Sobreposição não permitida. Por favor, redesenhe o território.',
                            'warning',
                            5000
                        );
                    }
                }
                
                // Limpar event listeners
                btnConfirm.removeEventListener('click', handleConfirm);
                btnCancel.removeEventListener('click', handleCancel);
                
                resolve(false);
            };
            
            btnConfirm.addEventListener('click', handleConfirm);
            btnCancel.addEventListener('click', handleCancel);
            
            // Também tratar fechamento do modal (X ou ESC)
            document.getElementById('modalTrimConfirmation').addEventListener('hidden.bs.modal', function handler() {
                if (previewLayers.original && self.map.hasLayer(previewLayers.original)) {
                    handleCancel();
                }
                this.removeEventListener('hidden.bs.modal', handler);
            });
        });
    }
}

// Export
window.MapManager = MapManager;
