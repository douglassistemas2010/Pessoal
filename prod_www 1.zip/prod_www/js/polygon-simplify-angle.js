/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Polygon Simplification by Angle - MapCarteiras v2.0
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Algoritmo de simplificação de polígonos baseado no ângulo entre vértices.
 * Remove vértices intermediários quando três pontos consecutivos formam
 * uma linha quase reta (ângulo próximo de 180°).
 * 
 * Performance: O(n) por anel, otimizado para polígonos com 10.000+ vértices.
 * 
 * Uso:
 *   const simplified = PolygonSimplifyAngle.simplifyFeature(feature, {
 *     toleranceDeg: 5,    // Desvio máximo de 180° (graus)
 *     minDist: 0.00001    // Distância mínima entre pontos (graus)
 *   });
 * 
 * @author MapCarteiras Team
 * @version 2.0.0
 * ═══════════════════════════════════════════════════════════════════════════
 */

const PolygonSimplifyAngle = (function() {
    'use strict';

    // ═══════════════════════════════════════════════════════════════════════
    // UTILITÁRIOS GEOMÉTRICOS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Produto escalar entre dois vetores 2D
     * @param {[number, number]} a - Vetor A
     * @param {[number, number]} b - Vetor B
     * @returns {number} Produto escalar
     */
    function dot(a, b) {
        return a[0] * b[0] + a[1] * b[1];
    }

    /**
     * Comprimento (magnitude) de um vetor 2D
     * @param {[number, number]} v - Vetor
     * @returns {number} Comprimento
     */
    function length(v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1]);
    }

    /**
     * Distância euclidiana entre dois pontos
     * @param {[number, number]} a - Ponto A
     * @param {[number, number]} b - Ponto B
     * @returns {number} Distância
     */
    function distance(a, b) {
        const dx = b[0] - a[0];
        const dy = b[1] - a[1];
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Calcula o ângulo em graus no vértice B de uma tripla A-B-C
     * @param {[number, number]} a - Ponto anterior
     * @param {[number, number]} b - Ponto central (vértice)
     * @param {[number, number]} c - Ponto seguinte
     * @returns {number} Ângulo em graus (0-180)
     */
    function angleAtVertex(a, b, c) {
        // Vetores BA e BC
        const ba = [a[0] - b[0], a[1] - b[1]];
        const bc = [c[0] - b[0], c[1] - b[1]];

        // Produto escalar
        const dotProduct = dot(ba, bc);
        
        // Magnitudes
        const lenBA = length(ba);
        const lenBC = length(bc);

        // Evitar divisão por zero
        if (lenBA === 0 || lenBC === 0) {
            return 0;
        }

        // cos(θ) = dot(BA, BC) / (|BA| * |BC|)
        let cosTheta = dotProduct / (lenBA * lenBC);
        
        // Garantir que está no intervalo [-1, 1] (precisão numérica)
        cosTheta = Math.max(-1, Math.min(1, cosTheta));

        // Converter para graus
        const theta = Math.acos(cosTheta) * (180 / Math.PI);
        
        return theta;
    }

    /**
     * Verifica se três pontos consecutivos formam uma linha quase reta
     * @param {[number, number]} a - Ponto anterior
     * @param {[number, number]} b - Ponto central
     * @param {[number, number]} c - Ponto seguinte
     * @param {number} toleranceDeg - Tolerância em graus (ex: 5°)
     * @returns {boolean} True se o ângulo está próximo de 180°
     */
    function isNearlyStraight(a, b, c, toleranceDeg) {
        const angle = angleAtVertex(a, b, c);
        const deviation = Math.abs(180 - angle);
        return deviation < toleranceDeg;
    }

    /**
     * Verifica se dois pontos são iguais (com tolerância numérica)
     * @param {[number, number]} a - Ponto A
     * @param {[number, number]} b - Ponto B
     * @param {number} epsilon - Tolerância (padrão: 1e-10)
     * @returns {boolean} True se os pontos são iguais
     */
    function pointsEqual(a, b, epsilon = 1e-10) {
        return Math.abs(a[0] - b[0]) < epsilon && Math.abs(a[1] - b[1]) < epsilon;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SIMPLIFICAÇÃO DE ANEL (CORE ALGORITHM)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Simplifica um anel de polígono baseado em ângulos
     * Complexidade: O(n) - um único loop linear
     * 
     * @param {Array<[number, number]>} ring - Anel de coordenadas [lng, lat]
     * @param {Object} options - Opções de simplificação
     * @param {number} options.toleranceDeg - Desvio máximo de 180° em graus (padrão: 5)
     * @param {number} options.minDist - Distância mínima entre pontos (padrão: 0)
     * @returns {Array<[number, number]>} Anel simplificado
     */
    function simplifyRingByAngle(ring, options = {}) {
        const toleranceDeg = options.toleranceDeg ?? 5;
        const minDist = options.minDist ?? 0;

        // Validação básica
        if (!ring || ring.length < 4) {
            return ring; // Anel muito pequeno, retornar original
        }

        // Detectar se o anel é fechado
        const isClosed = pointsEqual(ring[0], ring[ring.length - 1]);
        
        // Trabalhar com cópia sem o último ponto (se fechado)
        const workingRing = isClosed ? ring.slice(0, -1) : ring.slice();
        const n = workingRing.length;

        if (n < 3) {
            return ring; // Mínimo necessário
        }

        // Array para armazenar pontos simplificados
        const simplified = [];
        
        // Sempre manter o primeiro ponto
        simplified.push(workingRing[0]);
        let lastKept = workingRing[0];

        // Loop linear O(n) sobre os pontos intermediários
        for (let i = 1; i < n - 1; i++) {
            const prev = lastKept;
            const curr = workingRing[i];
            const next = workingRing[i + 1];

            // Verificar distância mínima (se especificado)
            if (minDist > 0) {
                const dist = distance(prev, curr);
                if (dist < minDist) {
                    continue; // Ponto muito próximo, descartar
                }
            }

            // Verificar se forma linha quase reta
            if (isNearlyStraight(prev, curr, next, toleranceDeg)) {
                continue; // Ponto redundante, descartar
            }

            // Ponto relevante, manter
            simplified.push(curr);
            lastKept = curr;
        }

        // Sempre adicionar o último ponto
        simplified.push(workingRing[n - 1]);

        // Fechar o anel se era fechado originalmente
        if (isClosed) {
            simplified.push(simplified[0]);
        }

        // Proteção: garantir mínimo de 4 coordenadas para anel fechado válido
        if (isClosed && simplified.length < 4) {
            console.warn('⚠️ Simplificação resultou em anel inválido, retornando original');
            return ring;
        }

        return simplified;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SIMPLIFICAÇÃO DE GEOMETRIA GEOJSON
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Simplifica uma geometria Polygon ou MultiPolygon
     * @param {Object} geometry - Geometria GeoJSON
     * @param {Object} options - Opções de simplificação
     * @returns {Object} Geometria simplificada
     */
    function simplifyGeometry(geometry, options = {}) {
        if (!geometry || !geometry.type) {
            return geometry;
        }

        const newGeometry = {
            type: geometry.type,
            coordinates: []
        };

        if (geometry.type === 'Polygon') {
            // Polygon: array de anéis (externo + buracos)
            newGeometry.coordinates = geometry.coordinates.map(ring => 
                simplifyRingByAngle(ring, options)
            );
        } 
        else if (geometry.type === 'MultiPolygon') {
            // MultiPolygon: array de polígonos, cada um com array de anéis
            newGeometry.coordinates = geometry.coordinates.map(polygon =>
                polygon.map(ring => simplifyRingByAngle(ring, options))
            );
        }
        else {
            // Outros tipos de geometria não suportados, retornar original
            return geometry;
        }

        return newGeometry;
    }

    /**
     * Simplifica uma Feature GeoJSON
     * @param {Object} feature - Feature GeoJSON
     * @param {Object} options - Opções de simplificação
     * @returns {Object} Feature simplificada (preserva properties)
     */
    function simplifyFeature(feature, options = {}) {
        if (!feature || feature.type !== 'Feature') {
            return feature;
        }

        return {
            type: 'Feature',
            properties: feature.properties || {},
            geometry: simplifyGeometry(feature.geometry, options)
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // HELPER PARA LEAFLET
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Aplica simplificação a um layer Leaflet
     * @param {L.Layer} layer - Layer Leaflet (Polygon, Polyline ou GeoJSON)
     * @param {Object} options - Opções de simplificação
     * @returns {Object} Feature simplificada
     */
    function simplifyLeafletLayer(layer, options = {}) {
        if (!layer || !layer.toGeoJSON) {
            console.error('❌ Layer inválido para simplificação');
            return null;
        }

        // Converter para GeoJSON
        const geoJSON = layer.toGeoJSON();
        
        // Aplicar simplificação
        const simplified = simplifyFeature(geoJSON, options);
        
        // Atualizar layer se possível
        if (layer.setLatLngs && simplified.geometry && simplified.geometry.coordinates) {
            try {
                const latLngs = coordsToLatLngs(simplified.geometry.coordinates, simplified.geometry.type);
                layer.setLatLngs(latLngs);
            } catch (error) {
                console.warn('⚠️ Não foi possível atualizar layer:', error);
            }
        }

        return simplified;
    }

    /**
     * Converte coordenadas GeoJSON [lng, lat] para Leaflet LatLngs [lat, lng]
     * @param {Array} coords - Coordenadas GeoJSON
     * @param {string} type - Tipo de geometria
     * @returns {Array} LatLngs para Leaflet
     */
    function coordsToLatLngs(coords, type) {
        if (type === 'Polygon') {
            return coords.map(ring => 
                ring.map(coord => [coord[1], coord[0]]) // Inverter lng,lat para lat,lng
            );
        } else if (type === 'MultiPolygon') {
            return coords.map(polygon =>
                polygon.map(ring => 
                    ring.map(coord => [coord[1], coord[0]])
                )
            );
        }
        return coords;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // BENCHMARK E TESTES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Gera um anel sintético para testes
     * @param {number} numPoints - Número de pontos
     * @returns {Array<[number, number]>} Anel sintético
     */
    function generateTestRing(numPoints) {
        const ring = [];
        const centerLng = -52.0;
        const centerLat = -24.0;
        const radius = 0.5;

        for (let i = 0; i < numPoints; i++) {
            const angle = (i / numPoints) * 2 * Math.PI;
            const lng = centerLng + radius * Math.cos(angle);
            const lat = centerLat + radius * Math.sin(angle);
            
            // Adicionar ruído para criar segmentos quase retos
            const noise = (Math.random() - 0.5) * 0.001;
            ring.push([lng + noise, lat + noise]);
        }

        // Fechar o anel
        ring.push(ring[0]);
        
        return ring;
    }

    /**
     * Executa benchmark de simplificação
     * @param {number} numPoints - Número de pontos no anel de teste
     * @returns {Object} Resultados do benchmark
     */
    function runBenchmark(numPoints = 10000) {
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('🔬 BENCHMARK - Simplificação por Ângulo');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        
        // Gerar anel de teste
        console.log(`📊 Gerando anel de teste com ${numPoints} pontos...`);
        const testRing = generateTestRing(numPoints);
        
        // Benchmark
        const options = { toleranceDeg: 5, minDist: 0.00001 };
        
        console.log(`⏱️  Iniciando simplificação...`);
        const startTime = performance.now();
        const simplified = simplifyRingByAngle(testRing, options);
        const endTime = performance.now();
        
        const duration = endTime - startTime;
        const reduction = ((testRing.length - simplified.length) / testRing.length * 100).toFixed(2);
        
        console.log(`✅ Simplificação concluída!`);
        console.log(`   📍 Pontos originais: ${testRing.length}`);
        console.log(`   📍 Pontos simplificados: ${simplified.length}`);
        console.log(`   📍 Redução: ${reduction}%`);
        console.log(`   ⏱️  Tempo: ${duration.toFixed(2)}ms`);
        console.log(`   ⚡ Performance: ${(testRing.length / duration * 1000).toFixed(0)} pontos/seg`);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        
        return {
            original: testRing.length,
            simplified: simplified.length,
            reduction: parseFloat(reduction),
            duration: duration,
            pointsPerSecond: testRing.length / duration * 1000
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // API PÚBLICA
    // ═══════════════════════════════════════════════════════════════════════

    return {
        // Funções principais
        simplifyRing: simplifyRingByAngle,
        simplifyGeometry: simplifyGeometry,
        simplifyFeature: simplifyFeature,
        simplifyLeafletLayer: simplifyLeafletLayer,
        
        // Utilitários
        angleAtVertex: angleAtVertex,
        isNearlyStraight: isNearlyStraight,
        distance: distance,
        
        // Benchmark
        runBenchmark: runBenchmark,
        generateTestRing: generateTestRing
    };

})();

// Exportar para uso global
if (typeof window !== 'undefined') {
    window.PolygonSimplifyAngle = PolygonSimplifyAngle;
}

// Log de inicialização
console.log('✅ Polygon Simplify Angle módulo carregado');
