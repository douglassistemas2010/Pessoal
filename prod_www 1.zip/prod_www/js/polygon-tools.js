/**
 * PolygonTools - Ferramentas para manipulação de polígonos
 * VERSÃO 3.0 - Com Turf.js v6.5.0 + Martinez Polygon Clipping
 * Changelog: Reimplementação completa do método trimPolygonAgainstExisting
 */

class PolygonTools {
    constructor() {
        console.log('✅ PolygonTools v3.0 inicializado (Turf v6.5.0 + Martinez)');
    }

    /**
     * Trim (recortar) um novo polígono para evitar sobreposição com polígonos existentes
     * VERSÃO 3.0 - Usando Turf.js v6.5.0 + Martinez Polygon Clipping
     * @param {L.Polygon|GeoJSON} newPolygon - Novo polígono a ser ajustado
     * @param {Array} existingPolygons - Array de polígonos existentes (GeoJSON Features)
     * @param {Object} options - Opções de configuração
     * @returns {GeoJSON} Polígono ajustado (trimmed)
     */
    trimPolygonAgainstExisting(newPolygon, existingPolygons, options = {}) {
        try {
            console.log('✂️ TRIM v3.0 - Iniciando com Turf v6.5.0 + Martinez...');
            
            // Configurações
            const margin = options.margin || 0.02; // 2cm em metros (padrão)
            const marginMeters = margin;
            const marginKm = marginMeters / 1000;
            
            // Converter novo polígono para GeoJSON
            let trimmedPolygon = this._toGeoJSON(newPolygon);
            
            if (!existingPolygons || existingPolygons.length === 0) {
                console.log('ℹ️ Nenhum território existente, sem necessidade de trim');
                return trimmedPolygon;
            }

            console.log(`🔍 Verificando sobreposição com ${existingPolygons.length} territórios...`);
            console.log(`   - Margem de segurança: ${(marginMeters * 100).toFixed(1)}cm`);
            
            let hasIntersections = false;
            let trimCount = 0;

            // Verificar e aplicar trim contra cada polígono existente
            for (let i = 0; i < existingPolygons.length; i++) {
                const existing = existingPolygons[i];
                const territoryId = existing.properties?.territory_id || `T${i+1}`;
                
                try {
                    // Verificar se há interseção usando Turf v6.5.0
                    const intersects = turf.booleanIntersects(trimmedPolygon, existing);
                    
                    if (intersects) {
                        console.log(`⚠️ Interseção detectada com território ${territoryId}`);
                        hasIntersections = true;
                        trimCount++;

                        try {
                            // PASSO 1: Aplicar buffer no território existente (margem de segurança)
                            console.log(`   [${territoryId}] Aplicando buffer de ${(marginMeters * 100).toFixed(1)}cm...`);
                            
                            const existingBuffered = turf.buffer(existing, marginKm, { units: 'kilometers' });
                            console.log(`   [${territoryId}] ✅ Buffer aplicado`);
                            
                            // PASSO 2: Aplicar turf.difference (Turf v6.5.0 é estável)
                            console.log(`   [${territoryId}] Calculando diferença (turf.difference)...`);
                            
                            const difference = turf.difference(trimmedPolygon, existingBuffered);
                            
                            if (difference) {
                                console.log(`   [${territoryId}] ✅ Diferença calculada com sucesso`);
                                console.log(`   [${territoryId}] Tipo de geometria: ${difference.geometry.type}`);
                                
                                // Se o resultado é um MultiPolygon, pegar a maior parte
                                if (difference.geometry.type === 'MultiPolygon') {
                                    console.log(`   [${territoryId}] ⚠️ MultiPolygon detectado, selecionando maior parte...`);
                                    
                                    // Calcular área de cada parte
                                    const parts = difference.geometry.coordinates.map((coords, idx) => {
                                        const poly = turf.polygon(coords);
                                        return {
                                            index: idx,
                                            area: turf.area(poly),
                                            polygon: poly
                                        };
                                    });
                                    
                                    // Ordenar por área (maior primeiro)
                                    parts.sort((a, b) => b.area - a.area);
                                    
                                    // Usar a maior parte
                                    trimmedPolygon = parts[0].polygon;
                                    console.log(`   [${territoryId}] ✅ Maior parte selecionada: ${(parts[0].area / 10000).toFixed(2)} ha`);
                                } else {
                                    // Usar o resultado diretamente
                                    trimmedPolygon = difference;
                                }
                                
                                console.log(`   [${territoryId}] ✂️ Trim aplicado com sucesso`);
                                
                            } else {
                                console.warn(`   [${territoryId}] ⚠️ Diferença retornou null - polígono pode estar completamente sobreposto`);
                                
                                // Se difference retorna null, o polígono novo está completamente dentro do existente
                                // Neste caso, retornamos null para indicar erro
                                throw new Error('Polígono completamente sobreposto');
                            }
                            
                        } catch (diffError) {
                            console.error(`   [${territoryId}] ❌ Erro ao calcular diferença:`, diffError.message);
                            
                            // Se turf.difference falhar, tentar com martinez-polygon-clipping
                            console.log(`   [${territoryId}] 🔄 Tentando com Martinez Polygon Clipping...`);
                            
                            try {
                                // Verificar se Martinez está disponível
                                if (typeof martinez === 'undefined') {
                                    throw new Error('Martinez Polygon Clipping não está carregado');
                                }
                                
                                // Extrair coordenadas dos polígonos
                                const poly1Coords = trimmedPolygon.geometry.coordinates;
                                const poly2Coords = existingBuffered.geometry.coordinates;
                                
                                // Usar martinez para calcular diferença
                                const diffCoords = martinez.diff(poly1Coords, poly2Coords);
                                
                                if (diffCoords && diffCoords.length > 0) {
                                    console.log(`   [${territoryId}] ✅ Martinez conseguiu calcular diferença`);
                                    
                                    // Se martinez retorna múltiplos polígonos, pegar o maior
                                    if (diffCoords.length > 1) {
                                        console.log(`   [${territoryId}] ⚠️ Martinez retornou ${diffCoords.length} polígonos`);
                                        
                                        const parts = diffCoords.map((coords, idx) => {
                                            const poly = turf.polygon(coords);
                                            return {
                                                index: idx,
                                                area: turf.area(poly),
                                                polygon: poly
                                            };
                                        });
                                        
                                        parts.sort((a, b) => b.area - a.area);
                                        trimmedPolygon = parts[0].polygon;
                                        
                                        console.log(`   [${territoryId}] ✅ Maior polígono selecionado: ${(parts[0].area / 10000).toFixed(2)} ha`);
                                    } else {
                                        // Um único polígono
                                        trimmedPolygon = turf.polygon(diffCoords[0]);
                                        console.log(`   [${territoryId}] ✅ Polígono único processado`);
                                    }
                                } else {
                                    console.error(`   [${territoryId}] ❌ Martinez também falhou - resultado vazio`);
                                    throw new Error('Ambos métodos falharam - polígono completamente sobreposto');
                                }
                                
                            } catch (martinezError) {
                                console.error(`   [${territoryId}] ❌ Martinez Error:`, martinezError.message);
                                throw martinezError;
                            }
                        }
                    }
                } catch (err) {
                    console.error(`   [${territoryId}] ❌ Erro fatal ao processar:`, err.message);
                    // Propagar erro para indicar falha no trim
                    throw err;
                }
            }

            // RELATÓRIO FINAL
            if (hasIntersections) {
                const originalArea = turf.area(this._toGeoJSON(newPolygon)) / 10000;
                const trimmedArea = turf.area(trimmedPolygon) / 10000;
                const areaLoss = originalArea - trimmedArea;
                const areaLossPercent = (areaLoss / originalArea) * 100;

                console.log('✅ TRIM CONCLUÍDO COM SUCESSO:');
                console.log(`   - Interseções processadas: ${trimCount}`);
                console.log(`   - Área original: ${originalArea.toFixed(2)} ha`);
                console.log(`   - Área final: ${trimmedArea.toFixed(2)} ha`);
                console.log(`   - Perda: ${areaLoss.toFixed(2)} ha (${areaLossPercent.toFixed(1)}%)`);
                console.log(`   - Margem aplicada: ${(marginMeters * 100).toFixed(1)} cm`);
                console.log(`   - Método: Turf v6.5.0 + Martinez Clipping`);
            } else {
                console.log('✅ Nenhuma sobreposição detectada - polígono mantido original');
            }

            // Validar polígono final
            if (!this.validatePolygon(trimmedPolygon)) {
                console.error('❌ Polígono trimmed é inválido após processamento');
                throw new Error('Polígono resultante é inválido');
            }

            return trimmedPolygon;

        } catch (error) {
            console.error('❌ ERRO FATAL no trimPolygonAgainstExisting:', error);
            console.error('   Stack:', error.stack);
            
            // Retornar polígono original em caso de erro
            // O sistema de validação vai detectar que não houve trim e bloquear
            return this._toGeoJSON(newPolygon);
        }
    }

    /**
     * Converter polígono para GeoJSON
     */
    _toGeoJSON(polygon) {
        if (!polygon) return null;
        
        // Se já é GeoJSON Feature
        if (polygon.type === 'Feature') {
            return polygon;
        }
        
        // Se é GeoJSON Geometry
        if (polygon.type === 'Polygon' || polygon.type === 'MultiPolygon') {
            return turf.feature(polygon);
        }
        
        // Se é Leaflet Layer
        if (polygon.toGeoJSON) {
            const geojson = polygon.toGeoJSON();
            return geojson.type === 'Feature' ? geojson : turf.feature(geojson);
        }
        
        // Se tem getLatLngs (Leaflet)
        if (polygon.getLatLngs) {
            const coords = this._leafletCoordsToGeoJSON(polygon.getLatLngs());
            return turf.polygon(coords);
        }
        
        console.error('❌ Formato de polígono não reconhecido:', polygon);
        return null;
    }

    /**
     * Converter coordenadas Leaflet para GeoJSON
     */
    _leafletCoordsToGeoJSON(latlngs) {
        if (!Array.isArray(latlngs)) return [];
        
        // Se é array de arrays (MultiPolygon ou Polygon com holes)
        if (Array.isArray(latlngs[0])) {
            return latlngs.map(ring => this._leafletCoordsToGeoJSON(ring));
        }
        
        // Se é array de LatLngs
        return latlngs.map(ll => [ll.lng, ll.lat]);
    }

    /**
     * Validar polígono GeoJSON
     */
    validatePolygon(geojson) {
        if (!geojson) return false;
        
        try {
            // Verificar estrutura básica
            if (!geojson.geometry || !geojson.geometry.coordinates) {
                return false;
            }
            
            const type = geojson.geometry.type;
            if (type !== 'Polygon' && type !== 'MultiPolygon') {
                return false;
            }
            
            // Verificar se tem coordenadas válidas
            const coords = geojson.geometry.coordinates;
            if (!coords || coords.length === 0) {
                return false;
            }
            
            // Para Polygon, verificar primeiro anel
            if (type === 'Polygon') {
                const ring = coords[0];
                if (!ring || ring.length < 4) { // Mínimo 4 pontos (3 + fechamento)
                    return false;
                }
            }
            
            // Verificar área mínima (evitar polígonos degenerados)
            const area = turf.area(geojson);
            if (area < 1) { // Menos de 1 m²
                console.warn('⚠️ Polígono com área muito pequena:', area);
                return false;
            }
            
            return true;
            
        } catch (err) {
            console.error('❌ Erro ao validar polígono:', err);
            return false;
        }
    }

    /**
     * Quick Trim - Método rápido para recorte de polígonos
     * Filtrar polígonos que realmente intersectam antes de aplicar trim
     */
    quickTrim(newPolygon, allTerritories, options = {}) {
        console.log('🔍 Quick Trim v3.0 INICIADO');
        console.log(`   - Territórios recebidos: ${allTerritories.length}`);
        
        try {
            // Converter novo polígono para GeoJSON
            const newGeoJSON = this._toGeoJSON(newPolygon);
            
            if (!newGeoJSON) {
                console.error('❌ Falha ao converter novo polígono');
                return null;
            }
            
            console.log('   - Novo polígono convertido para GeoJSON');
            
            // Filtrar apenas territórios que realmente intersectam
            const intersectingTerritories = [];
            
            for (const territory of allTerritories) {
                const territoryId = territory.properties?.territory_id || 'unknown';
                
                try {
                    const intersects = turf.booleanIntersects(newGeoJSON, territory);
                    
                    if (intersects) {
                        console.log(`   - Testando ${territoryId}: INTERSECTA`);
                        intersectingTerritories.push(territory);
                    }
                } catch (err) {
                    console.warn(`   - Erro ao testar ${territoryId}:`, err.message);
                }
            }
            
            console.log(`   - Total de interseções encontradas: ${intersectingTerritories.length}`);
            
            // Se não há interseções, retornar original
            if (intersectingTerritories.length === 0) {
                console.log('✅ Quick Trim: Sem interseções, polígono mantido original');
                return newGeoJSON;
            }
            
            // Aplicar trim apenas contra territórios que intersectam
            console.log(`🔍 Quick Trim: ${intersectingTerritories.length} interseção(ões) detectada(s), aplicando recorte...`);
            
            const trimmed = this.trimPolygonAgainstExisting(newPolygon, intersectingTerritories, options);
            
            return trimmed;
            
        } catch (error) {
            console.error('❌ Erro no Quick Trim:', error);
            return null;
        }
    }

    /**
     * Calcular área de um polígono em hectares
     */
    calculateArea(polygon) {
        try {
            const geojson = this._toGeoJSON(polygon);
            if (!geojson) return 0;
            
            const areaM2 = turf.area(geojson);
            const areaHa = areaM2 / 10000;
            
            return areaHa;
        } catch (err) {
            console.error('❌ Erro ao calcular área:', err);
            return 0;
        }
    }

    /**
     * Remove buracos (holes/inner rings) de um polígono, mantendo apenas o contorno externo
     * @param {GeoJSON} geojson - Polygon ou MultiPolygon GeoJSON
     * @returns {GeoJSON} Polygon ou MultiPolygon sem buracos
     */
    removeHoles(geojson) {
        try {
            console.log('🕳️ Removendo buracos do polígono...');
            
            const geometry = geojson.geometry || geojson;
            let holesRemoved = 0;
            let cleanGeometry;

            if (geometry.type === 'Polygon') {
                // Polygon: coordinates[0] = outer ring, coordinates[1...n] = holes
                const outerRing = geometry.coordinates[0];
                const totalRings = geometry.coordinates.length;
                holesRemoved = totalRings - 1;
                
                cleanGeometry = {
                    type: 'Polygon',
                    coordinates: [outerRing]  // Apenas o anel externo
                };
                
                console.log(`   Polygon: ${holesRemoved} buraco(s) removido(s)`);
                
            } else if (geometry.type === 'MultiPolygon') {
                // MultiPolygon: array de Polygons
                cleanGeometry = {
                    type: 'MultiPolygon',
                    coordinates: geometry.coordinates.map((polygonCoords, idx) => {
                        const outerRing = polygonCoords[0];
                        const holes = polygonCoords.length - 1;
                        holesRemoved += holes;
                        
                        if (holes > 0) {
                            console.log(`   Polygon ${idx + 1}: ${holes} buraco(s) removido(s)`);
                        }
                        
                        return [outerRing];  // Apenas o anel externo de cada polígono
                    })
                };
                
            } else {
                console.warn('⚠️ Tipo de geometria não suportado:', geometry.type);
                return geojson;
            }

            // Retornar como Feature se o input era Feature
            if (geojson.type === 'Feature') {
                const result = {
                    type: 'Feature',
                    geometry: cleanGeometry,
                    properties: geojson.properties || {}
                };
                
                console.log(`✅ Total de ${holesRemoved} buraco(s) removido(s)`);
                return result;
            }

            console.log(`✅ Total de ${holesRemoved} buraco(s) removido(s)`);
            return cleanGeometry;

        } catch (error) {
            console.error('❌ Erro ao remover buracos:', error);
            return geojson;  // Retornar original em caso de erro
        }
    }

    /**
     * Conta o número de buracos em um polígono
     * @param {GeoJSON} geojson - Polygon ou MultiPolygon GeoJSON
     * @returns {number} Número total de buracos
     */
    countHoles(geojson) {
        try {
            const geometry = geojson.geometry || geojson;
            let totalHoles = 0;

            if (geometry.type === 'Polygon') {
                // Polygon: coordinates.length - 1 = número de buracos
                totalHoles = geometry.coordinates.length - 1;
                
            } else if (geometry.type === 'MultiPolygon') {
                // MultiPolygon: somar buracos de todos os polígonos
                geometry.coordinates.forEach(polygonCoords => {
                    totalHoles += polygonCoords.length - 1;
                });
            }

            return totalHoles;

        } catch (error) {
            console.error('❌ Erro ao contar buracos:', error);
            return 0;
        }
    }

    /**
     * Aplicar buffer em um polígono
     */
    applyBuffer(polygon, distance, units = 'meters') {
        try {
            const geojson = this._toGeoJSON(polygon);
            if (!geojson) return null;
            
            const buffered = turf.buffer(geojson, distance, { units: units });
            
            return buffered;
        } catch (err) {
            console.error('❌ Erro ao aplicar buffer:', err);
            return null;
        }
    }

    /**
     * Encontrar pontos de interseção entre dois polígonos
     * NOTA: Esta função usa turf.intersect que pode falhar em v7.0.0
     * Com v6.5.0 deve funcionar corretamente
     */
    findIntersectionPoints(poly1, poly2) {
        try {
            const geojson1 = this._toGeoJSON(poly1);
            const geojson2 = this._toGeoJSON(poly2);
            
            if (!geojson1 || !geojson2) {
                return [];
            }
            
            // turf.intersect retorna a geometria de interseção
            const intersection = turf.intersect(geojson1, geojson2);
            
            if (!intersection) {
                return [];
            }
            
            // Extrair pontos da linha de interseção
            const points = [];
            
            if (intersection.geometry.type === 'Point') {
                points.push(intersection.geometry.coordinates);
            } else if (intersection.geometry.type === 'LineString') {
                points.push(...intersection.geometry.coordinates);
            } else if (intersection.geometry.type === 'Polygon') {
                // Pegar vértices do polígono de interseção
                intersection.geometry.coordinates[0].forEach(coord => {
                    points.push(coord);
                });
            } else if (intersection.geometry.type === 'MultiPolygon') {
                intersection.geometry.coordinates.forEach(poly => {
                    poly[0].forEach(coord => {
                        points.push(coord);
                    });
                });
            }
            
            return points;
            
        } catch (err) {
            console.error('❌ Erro ao encontrar pontos de interseção:', err);
            return [];
        }
    }

    /**
     * Encontrar todos os pontos de interseção entre um polígono e vários outros
     */
    findAllIntersectionPoints(newPolygon, existingPolygons) {
        const allPoints = [];
        
        existingPolygons.forEach(existing => {
            const territoryId = existing.properties?.territory_id || 'unknown';
            const points = this.findIntersectionPoints(newPolygon, existing);
            
            // Adicionar metadados ao ponto
            points.forEach(coord => {
                allPoints.push({
                    coordinates: coord,
                    territory: territoryId
                });
            });
        });
        
        console.log(`📍 Total de ${allPoints.length} pontos de interseção encontrados`);
        
        return allPoints;
    }

    /**
     * Simplifica uma geometria removendo vértices desnecessários
     * Usa algoritmo Douglas-Peucker do Turf.js
     * @param {GeoJSON} geojson - Geometria GeoJSON (Polygon, MultiPolygon ou Feature)
     * @param {Object} options - Opções de simplificação
     * @param {number} options.tolerance - Tolerância em km (padrão: 0.001 = 1 metro)
     * @param {boolean} options.highQuality - Usar alta qualidade (mais lento, padrão: false)
     * @returns {GeoJSON} Geometria simplificada
     */
    simplifyGeometry(geojson, options = {}) {
        try {
            // Configurações padrão
            const tolerance = options.tolerance || 0.001; // 1 metro em km
            const highQuality = options.highQuality !== false; // true por padrão

            // Contar vértices antes
            const verticesBefore = this._countVertices(geojson);

            // Aplicar simplificação usando Turf.js
            const simplified = turf.simplify(geojson, {
                tolerance: tolerance,
                highQuality: highQuality,
                mutate: false
            });

            // Contar vértices depois
            const verticesAfter = this._countVertices(simplified);
            const reduction = ((1 - verticesAfter / verticesBefore) * 100).toFixed(1);

            console.log(`🔧 Simplificação aplicada:`);
            console.log(`   Vértices antes: ${verticesBefore}`);
            console.log(`   Vértices depois: ${verticesAfter}`);
            console.log(`   Redução: ${reduction}% (${verticesBefore - verticesAfter} vértices removidos)`);
            console.log(`   Tolerância: ${(tolerance * 1000).toFixed(1)}m`);

            return simplified;

        } catch (error) {
            console.error('❌ Erro ao simplificar geometria:', error);
            return geojson; // Retornar original em caso de erro
        }
    }

    /**
     * Conta o número total de vértices em uma geometria
     * @param {GeoJSON} geojson - Geometria GeoJSON
     * @returns {number} Total de vértices
     */
    _countVertices(geojson) {
        let count = 0;

        const geometry = geojson.geometry || geojson;

        if (geometry.type === 'Polygon') {
            geometry.coordinates.forEach(ring => {
                count += ring.length;
            });
        } else if (geometry.type === 'MultiPolygon') {
            geometry.coordinates.forEach(polygon => {
                polygon.forEach(ring => {
                    count += ring.length;
                });
            });
        } else if (geometry.type === 'Point') {
            count = 1;
        } else if (geometry.type === 'LineString') {
            count = geometry.coordinates.length;
        } else if (geometry.type === 'MultiLineString') {
            geometry.coordinates.forEach(line => {
                count += line.length;
            });
        }

        return count;
    }

    /**
     * Simplifica múltiplas geometrias em lote
     * @param {Array} geojsonArray - Array de geometrias GeoJSON
     * @param {Object} options - Opções de simplificação
     * @returns {Array} Array de geometrias simplificadas
     */
    simplifyBatch(geojsonArray, options = {}) {
        console.log(`🔧 Simplificando ${geojsonArray.length} geometrias em lote...`);
        
        const startTime = Date.now();
        let totalBefore = 0;
        let totalAfter = 0;

        const simplified = geojsonArray.map((geojson, index) => {
            const before = this._countVertices(geojson);
            const result = this.simplifyGeometry(geojson, options);
            const after = this._countVertices(result);
            
            totalBefore += before;
            totalAfter += after;
            
            return result;
        });

        const elapsed = Date.now() - startTime;
        const reduction = ((1 - totalAfter / totalBefore) * 100).toFixed(1);

        console.log(`✅ Simplificação em lote concluída:`);
        console.log(`   Total de geometrias: ${geojsonArray.length}`);
        console.log(`   Vértices antes: ${totalBefore.toLocaleString()}`);
        console.log(`   Vértices depois: ${totalAfter.toLocaleString()}`);
        console.log(`   Redução: ${reduction}% (${(totalBefore - totalAfter).toLocaleString()} vértices)`);
        console.log(`   Tempo: ${elapsed}ms`);

        return simplified;
    }
}

// Exportar instância global
if (typeof window !== 'undefined') {
    window.PolygonTools = PolygonTools;
}

