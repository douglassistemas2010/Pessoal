/**
 * Region and Center Data
 * MapCarteiras v2.0
 * Dados extraídos de Regiao-Unidades.csv
 */

const REGION_CENTER_DATA = {
    "Região MS": [
        { centro: "AMAMBAI 2", centroChave: "C089" },
        { centro: "ANTÔNIO JOÃO II", centroChave: "C177" },
        { centro: "BANDEIRANTES", centroChave: "C234" },
        { centro: "BANDEIRANTES II", centroChave: "C258" },
        { centro: "CAARAPO", centroChave: "C075" },
        { centro: "CHAPADÃO DO SUL", centroChave: "C240" },
        { centro: "CHAPADÃO DO SUL II", centroChave: "C255" },
        { centro: "COSTA RICA II", centroChave: "C245" },
        { centro: "DOURADOS II", centroChave: "C136" },
        { centro: "FATIMA DO SUL", centroChave: "C066" },
        { centro: "INDAPOLIS", centroChave: "C097" },
        { centro: "ITAPORA", centroChave: "C079" },
        { centro: "LAGUNA CARAPA II", centroChave: "C120" },
        { centro: "MARACAJU", centroChave: "C256" },
        { centro: "MUNDO NOVO", centroChave: "C241" },
        { centro: "MUNDO NOVO II", centroChave: "C248" },
        { centro: "NAVIRAI", centroChave: "C081" },
        { centro: "RIO BRILHANTE", centroChave: "C064" },
        { centro: "TACURU", centroChave: "C084" },
        { centro: "VILA VARGAS", centroChave: "C210" }
    ],
    "Região MT": [
        { centro: "CLAUDIA III", centroChave: "C244" },
        { centro: "DIAMANTINO", centroChave: "C012" },
        { centro: "DIAMANTINO II", centroChave: "C200" },
        { centro: "FELIZ NATAL II", centroChave: "C142" },
        { centro: "NOVA MUTUM II", centroChave: "C201" },
        { centro: "NOVA UBIRATA", centroChave: "C093" },
        { centro: "NOVA UBIRATA II", centroChave: "C172" },
        { centro: "NOVO HORIZONTE", centroChave: "C038" },
        { centro: "NOVO HORIZONTE II", centroChave: "C202" },
        { centro: "REFLO SORRISO", centroChave: "C198" },
        { centro: "SANTA CARMEM III", centroChave: "C203" },
        { centro: "SANTA RITA DO TRIVELATO II", centroChave: "C205" },
        { centro: "SAO LUIZ GONZAGA", centroChave: "C094" },
        { centro: "SÃO LUIZ GONZAGA III", centroChave: "C206" },
        { centro: "SINOP II", centroChave: "C207" },
        { centro: "SORRISO III", centroChave: "C208" },
        { centro: "VERA II", centroChave: "C204" }
    ],
    "Região PR I": [
        { centro: "ALTO PIQUIRI II", centroChave: "C175" },
        { centro: "ALTO SANTA FE", centroChave: "C032" },
        { centro: "ASSIS CHATEAUBRIAND", centroChave: "C003" },
        { centro: "ASSIS CHATEAUBRIAND III", centroChave: "C192" },
        { centro: "BAIRRO CATARINENSE", centroChave: "C047" },
        { centro: "BARREIRO", centroChave: "C191" },
        { centro: "BELA VISTA", centroChave: "C046" },
        { centro: "BRASILANDIA DO SUL", centroChave: "C061" },
        { centro: "CANDEIA", centroChave: "C002" },
        { centro: "CLEVELANDIA", centroChave: "C086" },
        { centro: "ENCANTADO DO OESTE", centroChave: "C026" },
        { centro: "GUAIRA", centroChave: "C091" },
        { centro: "MARIPA", centroChave: "C011" },
        { centro: "NICE", centroChave: "C027" },
        { centro: "NOVA SANTA ROSA", centroChave: "C212" },
        { centro: "PALOTINA", centroChave: "C001" },
        { centro: "PAULISTANIA", centroChave: "C059" },
        { centro: "PEROLA", centroChave: "C016" },
        { centro: "REFLORESTAMENTO IPORÃ", centroChave: "C243" },
        { centro: "SANTA RITA DO OESTE", centroChave: "C004" },
        { centro: "SAO CAMILO", centroChave: "C033" },
        { centro: "SAO FRANCISCO", centroChave: "C058" },
        { centro: "TERRA NOVA", centroChave: "C028" },
        { centro: "TERRA ROXA", centroChave: "C007" }
    ],
    "Região PR II": [
        { centro: "CAMPINA DA LAGOA", centroChave: "C104" },
        { centro: "CAMPO MOURAO", centroChave: "C106" },
        { centro: "DOUTOR CAMARGO", centroChave: "C111" },
        { centro: "FLORESTA", centroChave: "C112" },
        { centro: "GOIOERE", centroChave: "C103" },
        { centro: "GUARAPUAVA", centroChave: "C116" },
        { centro: "JARDIM ALEGRE II", centroChave: "C131" },
        { centro: "MAMBORE", centroChave: "C102" },
        { centro: "MANOEL RIBAS", centroChave: "C108" },
        { centro: "NOVA CANTU II", centroChave: "C139" },
        { centro: "PITANGA", centroChave: "C115" },
        { centro: "QUINTA DO SOL", centroChave: "C101" },
        { centro: "RONCADOR", centroChave: "C100" },
        { centro: "SAO JOAO DO IVAI", centroChave: "C110" },
        { centro: "SAO JORGE DO IVAI", centroChave: "C113" },
        { centro: "SARANDI", centroChave: "C107" },
        { centro: "TERRA BOA", centroChave: "C098" },
        { centro: "TURVO II", centroChave: "C130" },
        { centro: "UMUARAMA", centroChave: "C099" }
    ],
    "Região PR III": [
        { centro: "BRAGANEY", centroChave: "C220" },
        { centro: "CASCAVEL II", centroChave: "C230" },
        { centro: "CONCORDIA DO OESTE - TOLEDO", centroChave: "C215" },
        { centro: "CORBELIA", centroChave: "C217" },
        { centro: "MARECHAL CANDIDO RONDON", centroChave: "C221" },
        { centro: "NOVA AURORA", centroChave: "C225" },
        { centro: "NOVO SOBRADINHO - TOLEDO", centroChave: "C218" },
        { centro: "SÃO LUIZ - TOLEDO", centroChave: "C226" },
        { centro: "SÃO PEDRO DO IGUAÇU", centroChave: "C213" },
        { centro: "TOLEDO", centroChave: "C231" },
        { centro: "TUPASSI", centroChave: "C222" },
        { centro: "VILA IPIRANGA - TOLEDO", centroChave: "C219" },
        { centro: "VILA NOVA - TOLEDO", centroChave: "C227" }
    ],
    "Região RS": [
        { centro: "BAGÉ", centroChave: "C164" },
        { centro: "BOZANO", centroChave: "C159" },
        { centro: "CATUIPE", centroChave: "C156" },
        { centro: "CRUZ ALTA", centroChave: "C144" },
        { centro: "DILERMANDO DE AGUIAR", centroChave: "C168" },
        { centro: "DOM PEDRITO", centroChave: "C163" },
        { centro: "FORTALEZA DOS VALOS", centroChave: "C154" },
        { centro: "JÓIA", centroChave: "C160" },
        { centro: "JULIO DE CASTILHOS", centroChave: "C145" },
        { centro: "PALMEIRA DAS MISSÕES", centroChave: "C161" },
        { centro: "SANTA BÁRBARA DO SUL", centroChave: "C150" },
        { centro: "SANTO ANGELO", centroChave: "C174" },
        { centro: "SÃO BORJA", centroChave: "C155" },
        { centro: "SÃO LUIZ GONZAGA RS", centroChave: "C149" },
        { centro: "SELBACH", centroChave: "C162" },
        { centro: "TAPERA II", centroChave: "C147" },
        { centro: "TUPANCIRETÃ", centroChave: "C148" }
    ],
    "Região SC": [
        { centro: "ABELARDO LUZ", centroChave: "C023" },
        { centro: "FAXINAL DOS GUEDES", centroChave: "C025" }
    ]
};

/**
 * Get all regions
 */
function getAllRegions() {
    return Object.keys(REGION_CENTER_DATA);
}

/**
 * Get centers for a specific region
 */
function getCentersByRegion(region) {
    return REGION_CENTER_DATA[region] || [];
}

/**
 * Get center by Centro Chave
 */
function getCenterByChave(centroChave) {
    for (const region in REGION_CENTER_DATA) {
        const center = REGION_CENTER_DATA[region].find(c => c.centroChave === centroChave);
        if (center) {
            return {
                region: region,
                ...center
            };
        }
    }
    return null;
}

/**
 * Get region by Centro Chave
 */
function getRegionByChave(centroChave) {
    const result = getCenterByChave(centroChave);
    return result ? result.region : null;
}

/**
 * Validate Centro Chave format
 */
function isValidCentroChave(chave) {
    return /^C\d{3}$/.test(chave);
}

/**
 * Get total count
 */
function getCounts() {
    const regions = getAllRegions();
    let totalCenters = 0;
    
    regions.forEach(region => {
        totalCenters += REGION_CENTER_DATA[region].length;
    });
    
    return {
        regions: regions.length,
        centers: totalCenters
    };
}

// Make available globally
window.REGION_CENTER_DATA = REGION_CENTER_DATA;
window.RegionCenterUtils = {
    getAllRegions,
    getCentersByRegion,
    getCenterByChave,
    getRegionByChave,
    isValidCentroChave,
    getCounts
};

console.log('📊 Region/Center Data loaded:', getCounts());
