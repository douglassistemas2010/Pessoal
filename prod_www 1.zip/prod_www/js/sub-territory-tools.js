/**
 * SubTerritoryTools - Ferramentas para manipulação de sub-territórios
 * VERSÃO 1.0
 * 
 * Sub-territórios são "filhos" de territórios e seguem regras específicas:
 * 1. Devem estar completamente dentro do território pai
 * 2. Não podem sobrepor outros sub-territórios do mesmo território
 * 3. Utilizam a mesma lógica de trim/recorte dos territórios
 */

class SubTerritoryTools {
    constructor(polygonTools) {
        this.polygonTools = polygonTools || new PolygonTools();
        console.log('✅ SubTerritoryTools v1.0 inicializado');
    }

    /**
     * Valida se um sub-território está completamente dentro do território pai
     * @param {GeoJSON} subTerritoryGeoJSON - GeoJSON do sub-território
     * @param {GeoJSON} parentTerritoryGeoJSON - GeoJSON do território pai
     * @returns {Object} { isValid: boolean, message: string, coverage: number }
     */
    validateWithinParent(subTerritoryGeoJSON, parentTerritoryGeoJSON) {
        try {
            console.log('🔍 Validando se sub-território está dentro do pai...');
            
            // Converter para GeoJSON se necessário
            const subGeo = this.polygonTools._toGeoJSON(subTerritoryGeoJSON);
            const parentGeo = this.polygonTools._toGeoJSON(parentTerritoryGeoJSON);
            
            // Verificar se o sub-território está completamente contido no pai
            const isWithin = turf.booleanWithin(subGeo, parentGeo);
            
            if (isWithin) {
                console.log('✅ Sub-território está completamente dentro do pai');
                return {
                    isValid: true,
                    message: 'Sub-território está completamente dentro do território pai',
                    coverage: 100
                };
            }
            
            // Calcular o percentual de sobreposição
            const intersection = turf.intersect(subGeo, parentGeo);
            
            if (!intersection) {
                console.log('❌ Sub-território está completamente fora do pai');
                return {
                    isValid: false,
                    message: 'Sub-território está completamente fora do território pai',
                    coverage: 0
                };
            }
            
            const subArea = turf.area(subGeo);
            const intersectionArea = turf.area(intersection);
            const coverage = (intersectionArea / subArea) * 100;
            
            console.log(`⚠️ Sub-território parcialmente fora do pai (${coverage.toFixed(1)}% dentro)`);
            
            return {
                isValid: false,
                message: `Sub-território está parcialmente fora do território pai (${coverage.toFixed(1)}% dentro)`,
                coverage: coverage
            };
            
        } catch (error) {
            console.error('❌ Erro ao validar sub-território:', error);
            return {
                isValid: false,
                message: 'Erro ao validar sub-território',
                coverage: 0,
                error: error.message
            };
        }
    }

    /**
     * Recorta um sub-território para mantê-lo dentro do território pai
     * @param {GeoJSON} subTerritoryGeoJSON - GeoJSON do sub-território
     * @param {GeoJSON} parentTerritoryGeoJSON - GeoJSON do território pai
     * @returns {GeoJSON} Sub-território recortado
     */
    clipToParent(subTerritoryGeoJSON, parentTerritoryGeoJSON) {
        try {
            console.log('✂️ Recortando sub-território para manter dentro do pai...');
            
            // Converter para GeoJSON se necessário
            const subGeo = this.polygonTools._toGeoJSON(subTerritoryGeoJSON);
            const parentGeo = this.polygonTools._toGeoJSON(parentTerritoryGeoJSON);
            
            // Verificar se já está dentro
            const validation = this.validateWithinParent(subGeo, parentGeo);
            if (validation.isValid) {
                console.log('ℹ️ Sub-território já está dentro do pai, sem necessidade de recorte');
                return subGeo;
            }
            
            // Calcular interseção (parte que está dentro do pai)
            const clipped = turf.intersect(subGeo, parentGeo);
            
            if (!clipped) {
                throw new Error('Sub-território está completamente fora do território pai');
            }
            
            // TIPO PREENCHIMENTO: Manter TODOS os fragmentos MultiPolygon
            if (clipped.geometry.type === 'MultiPolygon') {
                const fragmentCount = clipped.geometry.coordinates.length;
                console.log(`✅ MultiPolygon detectado - MANTENDO TODOS os ${fragmentCount} fragmentos (tipo: preenchimento)`);
                
                // Calcular área total
                let totalArea = 0;
                for (const coords of clipped.geometry.coordinates) {
                    const part = turf.polygon(coords);
                    totalArea += turf.area(part);
                }
                
                console.log(`✅ Sub-território recortado: ${fragmentCount} fragmentos, ${(totalArea / 10000).toFixed(2)} ha total`);
                return clipped; // MANTER MultiPolygon completo
            }
            
            const clippedArea = turf.area(clipped) / 10000;
            console.log(`✅ Sub-território recortado (${clippedArea.toFixed(2)} ha)`);
            
            return clipped;
            
        } catch (error) {
            console.error('❌ Erro ao recortar sub-território:', error);
            throw error;
        }
    }

    /**
     * Recorta um sub-território contra outros sub-territórios existentes
     * Similar ao trimPolygonAgainstExisting, mas específico para sub-territórios
     * @param {GeoJSON} newSubTerritory - Novo sub-território
     * @param {Array} existingSubTerritories - Array de sub-territórios existentes
     * @param {Object} options - Opções de configuração
     * @returns {GeoJSON} Sub-território recortado
     */
    trimAgainstSiblings(newSubTerritory, existingSubTerritories, options = {}) {
        try {
            console.log('✂️ Aplicando trim contra sub-territórios existentes...');
            
            // Reutilizar a lógica de trim do PolygonTools
            const trimmed = this.polygonTools.trimPolygonAgainstExisting(
                newSubTerritory,
                existingSubTerritories,
                options
            );
            
            console.log('✅ Trim contra sub-territórios concluído');
            return trimmed;
            
        } catch (error) {
            console.error('❌ Erro ao aplicar trim contra sub-territórios:', error);
            throw error;
        }
    }

    /**
     * Processa um novo sub-território aplicando todas as regras:
     * 1. Recorta para manter dentro do pai
     * 2. Recorta para evitar sobreposição com outros sub-territórios
     * @param {GeoJSON} newSubTerritory - Novo sub-território
     * @param {GeoJSON} parentTerritory - Território pai
     * @param {Array} existingSubTerritories - Sub-territórios existentes
     * @param {Object} options - Opções de configuração
     * @returns {Object} { success: boolean, processed: GeoJSON, steps: Array }
     */
    processNewSubTerritory(newSubTerritory, parentTerritory, existingSubTerritories = [], options = {}) {
        try {
            console.log('🔄 Processando novo sub-território...');
            
            const steps = [];
            let processed = this.polygonTools._toGeoJSON(newSubTerritory);
            
            // PASSO 1: Recortar para manter dentro do pai
            console.log('📍 PASSO 1: Recortando para manter dentro do território pai...');
            
            const validation = this.validateWithinParent(processed, parentTerritory);
            steps.push({
                step: 1,
                name: 'Validação com território pai',
                isValid: validation.isValid,
                message: validation.message,
                coverage: validation.coverage
            });
            
            if (!validation.isValid) {
                processed = this.clipToParent(processed, parentTerritory);
                steps.push({
                    step: 1.1,
                    name: 'Recorte ao território pai',
                    action: 'clipped',
                    area: turf.area(processed) / 10000
                });
            }
            
            // PASSO 2: Recortar para evitar sobreposição com outros sub-territórios
            if (existingSubTerritories && existingSubTerritories.length > 0) {
                console.log(`📍 PASSO 2: Verificando sobreposição com ${existingSubTerritories.length} sub-territórios...`);
                
                const originalArea = turf.area(processed) / 10000;
                processed = this.trimAgainstSiblings(processed, existingSubTerritories, options);
                const finalArea = turf.area(processed) / 10000;
                
                const areaDiff = originalArea - finalArea;
                
                steps.push({
                    step: 2,
                    name: 'Trim contra sub-territórios',
                    action: areaDiff > 0.01 ? 'trimmed' : 'no-overlap',
                    originalArea: originalArea,
                    finalArea: finalArea,
                    areaDiff: areaDiff
                });
            } else {
                console.log('ℹ️ PASSO 2: Nenhum sub-território existente, pulando trim');
                steps.push({
                    step: 2,
                    name: 'Trim contra sub-territórios',
                    action: 'skipped',
                    message: 'Nenhum sub-território existente'
                });
            }
            
            // Validação final
            const finalValidation = this.validateWithinParent(processed, parentTerritory);
            steps.push({
                step: 3,
                name: 'Validação final',
                isValid: finalValidation.isValid,
                message: finalValidation.message,
                finalArea: turf.area(processed) / 10000
            });
            
            console.log('✅ Processamento do sub-território concluído');
            
            return {
                success: finalValidation.isValid,
                processed: processed,
                steps: steps,
                finalArea: turf.area(processed) / 10000
            };
            
        } catch (error) {
            console.error('❌ Erro ao processar sub-território:', error);
            return {
                success: false,
                processed: null,
                steps: [],
                error: error.message
            };
        }
    }

    /**
     * Verifica se há sobreposição entre sub-territórios
     * @param {GeoJSON} subTerritory1 - Primeiro sub-território
     * @param {GeoJSON} subTerritory2 - Segundo sub-território
     * @returns {Object} { hasOverlap: boolean, overlapArea: number, overlapPercentage: number }
     */
    checkOverlap(subTerritory1, subTerritory2) {
        try {
            const geo1 = this.polygonTools._toGeoJSON(subTerritory1);
            const geo2 = this.polygonTools._toGeoJSON(subTerritory2);
            
            const intersects = turf.booleanIntersects(geo1, geo2);
            
            if (!intersects) {
                return {
                    hasOverlap: false,
                    overlapArea: 0,
                    overlapPercentage: 0
                };
            }
            
            const intersection = turf.intersect(geo1, geo2);
            const overlapArea = intersection ? turf.area(intersection) / 10000 : 0;
            const area1 = turf.area(geo1) / 10000;
            const overlapPercentage = (overlapArea / area1) * 100;
            
            return {
                hasOverlap: true,
                overlapArea: overlapArea,
                overlapPercentage: overlapPercentage
            };
            
        } catch (error) {
            console.error('❌ Erro ao verificar sobreposição:', error);
            return {
                hasOverlap: false,
                overlapArea: 0,
                overlapPercentage: 0,
                error: error.message
            };
        }
    }

    /**
     * Gera ID para sub-território baseado no território pai
     * @param {String} parentTerritoryId - ID do território pai (ex: C089)
     * @param {Number} subTerritoryIndex - Índice do sub-território (1, 2, 3...)
     * @returns {String} ID do sub-território (ex: C089.01, C089.02)
     */
    generateSubTerritoryId(parentTerritoryId, subTerritoryIndex) {
        const index = String(subTerritoryIndex).padStart(2, '0');
        return `${parentTerritoryId}.${index}`;
    }
}
