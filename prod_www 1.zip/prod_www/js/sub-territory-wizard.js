/**
 * SubTerritoryWizard - Assistente para criação/edição de sub-territórios (carteiras)
 * Reaproveita fluxos do TerritoryWizard, mas força regras de "manter dentro do pai" e "não sobrepor irmãos"
 */

class SubTerritoryWizard {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 3;
        this.data = {
            parentTerritory: null,
            originalLayer: null,
            originalGeoJSON: null,
            processedGeoJSON: null,
            existingSiblings: []
        };
        console.log('✅ SubTerritoryWizard inicializado');
    }

    async open(parentTerritory, layer) {
        try {
            this.reset();
            this.data.parentTerritory = parentTerritory;
            this.data.originalLayer = layer;
            this.data.originalGeoJSON = layer.toGeoJSON();

            // Carregar irmãos do servidor
            const dm = window.app.dataManager;
            this.data.existingSiblings = await dm.listSubTerritories(parentTerritory.id);

            // Abrir modal (criar modal no index.html será próximo passo)
            const modal = new bootstrap.Modal(document.getElementById('modalSubTerritoryWizard'));
            modal.show();

            this.goToStep(1);
            await this.runStep1();

        } catch (error) {
            console.error('❌ Erro ao abrir SubTerritoryWizard:', error);
        }
    }

    reset() {
        this.currentStep = 1;
        this.data = {
            parentTerritory: null,
            originalLayer: null,
            originalGeoJSON: null,
            processedGeoJSON: null,
            existingSiblings: []
        };
    }

    goToStep(step) {
        this.currentStep = step;
        console.log(`📍 Indo para Step ${step}/${this.totalSteps}`);
        
        // Atualizar UI do modal - mostrar/ocultar conteúdo dos steps
        for (let i = 1; i <= this.totalSteps; i++) {
            const el = document.getElementById(`subStep${i}`);
            if (el) {
                el.style.display = i === step ? 'block' : 'none';
            }
        }
        
        // Atualizar indicadores visuais dos steps
        for (let i = 1; i <= this.totalSteps; i++) {
            const indicator = document.getElementById(`subStepIndicator${i}`);
            if (indicator) {
                const circle = indicator.querySelector('.step-circle');
                if (circle) {
                    if (i < step) {
                        // Step já completado
                        circle.classList.add('completed');
                        circle.classList.remove('active');
                    } else if (i === step) {
                        // Step atual
                        circle.classList.add('active');
                        circle.classList.remove('completed');
                    } else {
                        // Step futuro
                        circle.classList.remove('active', 'completed');
                    }
                }
            }
        }
    }

    async runStep1() {
        // PASSO 1: Ajuste ao CAR (usando MESMO FLUXO do Territory Wizard)
        try {
            console.log('🔄 Ajuste ao CAR...');
            document.getElementById('subStep1Status').textContent = 'Carregando CAR...';

            // REUTILIZAR LÓGICA DO TERRITORY WIZARD
            // Detectar estado
            const state = window.app.carIntegration.detectStateFromPolygon(this.data.originalLayer);
            
            // Callback para atualizar progresso na interface
            const progressCallback = (message) => {
                document.getElementById('subStep1Status').textContent = message;
            };
            
            // Carregar CAR features (MESMO MÉTODO)
            const carFeatures = await window.app.carIntegration.loadCARForPolygon(
                this.data.originalLayer, 
                state,
                progressCallback
            );

            if (!carFeatures || carFeatures.length === 0) {
                console.log('ℹ️ Nenhum CAR encontrado, mantendo polígono original');
                this.data.processedGeoJSON = this.data.originalGeoJSON;
                document.getElementById('subStep1Status').textContent = 'Sem CAR disponível - mantendo original';
            } else {
                console.log(`📍 ${carFeatures.length} imóveis CAR encontrados`);
                document.getElementById('subStep1Status').textContent = `Processando ajuste com ${carFeatures.length} CARs...`;
                
                // APLICAR AJUSTE - CONTEXTO SUB-TERRITÓRIO (INTERSEÇÃO)
                let adjusted = await window.app.carIntegration.adjustSubTerritoryToCAR(
                    this.data.originalLayer, 
                    carFeatures
                );
                
                if (adjusted) {
                    // REMOVER BURACOS DO POLÍGONO
                    console.log('🕳️ Verificando e removendo buracos do polígono...');
                    const holesBefore = window.app.polygonTools.countHoles(adjusted);
                    
                    if (holesBefore > 0) {
                        console.log(`⚠️ Encontrados ${holesBefore} buraco(s) no polígono. Removendo...`);
                        adjusted = window.app.polygonTools.removeHoles(adjusted);
                        console.log('✅ Buracos removidos com sucesso');
                    }
                    
                    // SIMPLIFICAR POLÍGONO - Reduzir vértices desnecessários
                    console.log('✂️ Simplificando polígono com turf.simplify...');
                    const verticesBefore = adjusted.geometry.coordinates[0].length - 1;
                    console.log(`   📊 Vértices antes: ${verticesBefore}`);
                    
                    try {
                        adjusted = turf.simplify(adjusted, {
                            tolerance: 0.00005,    // ~5 metros de tolerância
                            highQuality: true,      // Usa algoritmo Ramer-Douglas-Peucker
                            mutate: false
                        });
                        
                        const verticesAfter = adjusted.geometry.coordinates[0].length - 1;
                        const reduction = ((verticesBefore - verticesAfter) / verticesBefore * 100).toFixed(1);
                        console.log(`   📊 Vértices depois: ${verticesAfter} (redução de ${reduction}%)`);
                        console.log('   ✅ Simplificação concluída');
                    } catch (error) {
                        console.warn('⚠️ Erro ao simplificar polígono:', error);
                        console.warn('   Continuando com polígono original...');
                    }
                    
                    this.data.processedGeoJSON = adjusted;
                    document.getElementById('subStep1Status').textContent = `✅ CAR ajustado - Seguindo contornos (${carFeatures.length} imóveis)`;
                    console.log('✅ Sub-território ajustado aos contornos do CAR');
                } else {
                    console.log('⚠️ Ajuste ao CAR falhou, mantendo polígono original');
                    this.data.processedGeoJSON = this.data.originalGeoJSON;
                    document.getElementById('subStep1Status').textContent = 'CAR disponível mas ajuste falhou - usando original';
                }
            }

            // Aguardar 1 segundo para o usuário ver o status, depois ir para Step 2
            setTimeout(async () => {
                this.goToStep(2);
                await this.runStep2();
            }, 1000);

        } catch (error) {
            console.error('❌ Erro no Step 1 SubTerritoryWizard:', error);
            document.getElementById('subStep1Status').textContent = 'Erro no ajuste ao CAR';
            // Mesmo com erro, continuar para o Step 2
            setTimeout(async () => {
                this.data.processedGeoJSON = this.data.originalGeoJSON;
                this.goToStep(2);
                await this.runStep2();
            }, 1000);
        }
    }

    async runStep2() {
        // PASSO 2: Aplicar regras - manter dentro do pai e não sobrepor irmãos
        try {
            console.log('🔄 Aplicando regras de manutenção...');
            document.getElementById('subStep2Status').textContent = 'Aplicando regras de manutenção...';

            const stTools = new SubTerritoryTools(window.app.polygonTools);

            // SEMPRE aplicar INTERSECT com território pai (obrigatório)
            console.log('🔍 Aplicando INTERSECT com território pai (obrigatório)...');
            const parentGeo = typeof this.data.parentTerritory.geometry === 'string' 
                ? JSON.parse(this.data.parentTerritory.geometry) 
                : this.data.parentTerritory.geometry;
            
            const subGeo = typeof this.data.processedGeoJSON === 'string'
                ? JSON.parse(this.data.processedGeoJSON)
                : (this.data.processedGeoJSON.geometry || this.data.processedGeoJSON);

            // Extrair geometries puras
            const subGeometry = subGeo.type === 'Feature' ? subGeo.geometry : subGeo;
            const parentGeometry = parentGeo.type === 'Feature' ? parentGeo.geometry : parentGeo;

            // SEMPRE aplicar clipToParent para garantir que está dentro dos limites
            let processedGeo = stTools.clipToParent(this.data.processedGeoJSON, this.data.parentTerritory.geometry);
            console.log('✅ INTERSECT aplicado - Sub-território ajustado aos limites do território pai');
            
            // Depois, trim contra irmãos se existirem
            let finalGeo = processedGeo;
            if (this.data.existingSiblings && this.data.existingSiblings.length > 0) {
                console.log(`✂️ Aplicando trim contra ${this.data.existingSiblings.length} sub-territórios existentes...`);
                
                // Verificar se há sobreposição antes do trim
                let hasOverlap = false;
                const currentGeo = typeof processedGeo === 'string'
                    ? JSON.parse(processedGeo)
                    : (processedGeo.geometry || processedGeo);
                
                for (const sibling of this.data.existingSiblings) {
                    const siblingGeo = typeof sibling.geometry === 'string' ? JSON.parse(sibling.geometry) : sibling.geometry;
                    
                    // Extrair geometries puras
                    const currentGeometry = currentGeo.type === 'Feature' ? currentGeo.geometry : currentGeo;
                    const siblingGeometry = siblingGeo.type === 'Feature' ? siblingGeo.geometry : siblingGeo;
                    
                    if (turf.booleanIntersects(turf.feature(currentGeometry), turf.feature(siblingGeometry))) {
                        hasOverlap = true;
                        break;
                    }
                }
                
                if (hasOverlap) {
                    console.warn('⚠️ ATENÇÃO: Sobreposição detectada! Trim pode alterar contornos CAR nas bordas.');
                    const siblingGeos = this.data.existingSiblings.map(s => typeof s.geometry === 'string' ? JSON.parse(s.geometry) : s.geometry);
                    finalGeo = stTools.trimAgainstSiblings(processedGeo, siblingGeos, { margin: 0.02 });
                } else {
                    console.log('✅ Sem sobreposição com irmãos, contornos CAR 100% preservados!');
                    finalGeo = processedGeo;
                }
            } else {
                console.log('ℹ️ Nenhum sub-território existente, sem necessidade de trim');
            }

            this.data.processedGeoJSON = finalGeo;

            // Mostrar resumo
            const areaHa = window.app.polygonTools.calculateArea(finalGeo);
            document.getElementById('subStep2Status').textContent = `✅ Processamento concluído - Área: ${areaHa.toFixed(2)} ha`;
            
            console.log('✅ Step 2 concluído, indo para Step 3...');

            // Aguardar 1 segundo para o usuário ver o status, depois ir para Step 3
            setTimeout(async () => {
                this.goToStep(3);
                await this.runStep3();
            }, 1000);

        } catch (error) {
            console.error('❌ Erro no Step 2 SubTerritoryWizard:', error);
            document.getElementById('subStep2Status').textContent = 'Erro ao aplicar regras: ' + error.message;
            // Mesmo com erro, continuar para o Step 3 com o polígono atual
            setTimeout(async () => {
                this.goToStep(3);
                await this.runStep3();
            }, 1500);
        }
    }

    async runStep3() {
        // PASSO 3: Confirmação e salvamento
        try {
            document.getElementById('subStep3Status').textContent = 'Aguardando informações...';

            // Gerar código sequencial automático
            const nextIndex = this.data.existingSiblings.length + 1;
            const carteiraId = new SubTerritoryTools().generateSubTerritoryId(
                this.data.parentTerritory.territory_id, 
                nextIndex
            );

            // Calcular área
            const areaHa = window.app.polygonTools.calculateArea(this.data.processedGeoJSON);

            // Preencher informações automáticas no preview
            const infoContainer = document.getElementById('subStep3Info');
            infoContainer.innerHTML = `
                <div class="mb-3">
                    <label class="form-label fw-bold">Território Pai:</label>
                    <div class="text-muted">${this.data.parentTerritory.territory_id} - ${this.data.parentTerritory.name || ''}</div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Código do Sub-Território:</label>
                    <div class="badge bg-primary fs-6">${carteiraId}</div>
                    <small class="text-muted d-block mt-1">Gerado automaticamente</small>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Área:</label>
                    <div class="text-muted">${areaHa.toFixed(2)} hectares</div>
                </div>
                <div class="mb-3">
                    <label for="subTerritoryDescription" class="form-label fw-bold">
                        Descrição: <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control" 
                           id="subTerritoryDescription" 
                           placeholder="Ex: Área Norte, Setor A, Plantio 2025, etc."
                           required>
                    <small class="text-muted">Digite uma descrição para identificar este sub-território</small>
                </div>
            `;

            // Preencher preview no mapa
            this.showPreview(this.data.processedGeoJSON);

            // Mostrar botão salvar
            const btnSave = document.getElementById('btnSubSave');
            btnSave.style.display = 'inline-block';

            // Configurar botão salvar
            const newBtn = btnSave.cloneNode(true);
            btnSave.parentNode.replaceChild(newBtn, btnSave);

            newBtn.addEventListener('click', async () => {
                const description = document.getElementById('subTerritoryDescription').value.trim();
                
                if (!description) {
                    alert('⚠️ Por favor, insira uma descrição para o sub-território');
                    document.getElementById('subTerritoryDescription').focus();
                    return;
                }
                
                await this.saveSubTerritory(carteiraId, description, areaHa);
            });

            document.getElementById('subStep3Status').textContent = 'Preencha a descrição e clique em Salvar';

        } catch (error) {
            console.error('❌ Erro no Step 3 SubTerritoryWizard:', error);
            document.getElementById('subStep3Status').textContent = 'Erro na etapa final';
        }
    }

    showPreview(geojson) {
        try {
            // Remover preview antigo
            if (this.previewLayer) {
                window.app.map.map.removeLayer(this.previewLayer);
            }

            const colors = window.app.map.territoryColors;
            this.previewLayer = L.geoJSON(geojson, { 
                style: { 
                    color: colors.subTerritory, 
                    fillColor: colors.subTerritoryFill,
                    weight: 3, 
                    fillOpacity: 0.5
                } 
            }).addTo(window.app.map.map);
            
            window.app.map.map.fitBounds(this.previewLayer.getBounds(), { padding: [50,50] });

        } catch (error) {
            console.error('❌ Erro ao mostrar preview do sub-território:', error);
        }
    }

    async saveSubTerritory(carteiraId, description, areaHa) {
        try {
            const dm = window.app.dataManager;
            
            console.log('💾 Salvando sub-território:', {
                carteiraId,
                description,
                parentId: this.data.parentTerritory.id,
                area: areaHa
            });

            const insert = {
                carteiraId: carteiraId,
                name: description, // Usar a descrição fornecida pelo usuário
                geometry: this.data.processedGeoJSON,
                coordinates: null,
                area_hectares: areaHa,
                areaKey: 1, // Herdar do pai ou usar padrão
                subAreaKey: this.data.existingSiblings.length + 1
            };

            const created = await dm.createSubTerritory(
                this.data.parentTerritory.id, 
                this.data.parentTerritory.property_id, 
                insert
            );

            if (created) {
                document.getElementById('subStep3Status').textContent = 'Sub-território salvo com sucesso! ✅';
                
                // Limpar preview e território de fundo IMEDIATAMENTE
                console.log('🧹 Limpando layers temporários...');
                if (this.previewLayer) {
                    window.app.map.map.removeLayer(this.previewLayer);
                    this.previewLayer = null;
                }
                
                // Limpar território de fundo (referência azul)
                window.app.map.clearLayer('polygons');
                window.app.map.clearLayer('drawings');
                
                // Limpar currentParentTerritory para sair do modo sub-território
                if (window.app.uiController) {
                    window.app.uiController.currentParentTerritory = null;
                }
                
                // Aguardar 1 segundo antes de fechar e atualizar
                setTimeout(async () => {
                    // Fechar modal
                    const modalEl = document.getElementById('modalSubTerritoryWizard');
                    const modal = bootstrap.Modal.getInstance(modalEl);
                    if (modal) {
                        modal.hide();
                    }

                    // Atualizar árvore e visualização (mostrará território + sub-território final)
                    if (window.app.uiController && window.app.uiController.refreshTerritory) {
                        await window.app.uiController.refreshTerritory(this.data.parentTerritory.id);
                    }
                    
                    // Mostrar notificação de sucesso
                    if (window.app.uiController && window.app.uiController.showNotification) {
                        window.app.uiController.showNotification(
                            `✅ Sub-território ${carteiraId} criado com sucesso!`, 
                            'success'
                        );
                    }
                }, 1000);
            }

        } catch (error) {
            console.error('❌ Erro ao salvar sub-território:', error);
            document.getElementById('subStep3Status').textContent = 'Erro ao salvar: ' + error.message;
            alert('❌ Erro ao salvar sub-território:\n\n' + error.message);
        }
    }
}

// Expor globalmente
window.SubTerritoryWizard = SubTerritoryWizard;
window.SubTerritoryWizard = SubTerritoryWizard;
