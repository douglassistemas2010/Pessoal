/**
 * UI Controller - Controle da Interface do Usuário
 * MapCarteiras v2.0
 */

class UIController {
    constructor() {
        this.map = null;
        this.polygonTools = null;
        this.carIntegration = null;
        this.dataManager = null;
        this.selectedPolygon = null;
        this.currentRegion = null; // Armazenar região atual para detecção de estado
        this.currentTerritory = null; // Território carregado atualmente
        this.currentCenterKey = null; // Centro chave do território atual
        this.viewMode = 'consultor'; // Modo de visualização: 'consultor' ou 'unidade'
        
        // Flags para prevenir event listeners duplicados
        this._deleteTerritoriesListenerAdded = false;
        this._deleteCarteirasListenerAdded = false;
        
        this.init();
    }

    /**
     * Inicializa o controller
     */
    init() {
        // Aguardar que os outros módulos sejam inicializados
        setTimeout(() => {
            this.map = window.app.map;
            this.polygonTools = window.app.polygonTools;
            this.carIntegration = window.app.carIntegration;
            this.dataManager = window.app.dataManager;
            
            this.setupEventListeners();
            this.setupMapClickListeners();
            this.loadRegionsTree();
            
            console.log('✅ UIController inicializado');
        }, 100);
    }

    /**
     * Configura listeners de clique no mapa
     */
    setupMapClickListeners() {
        // Listener para seleção de polígono por clique
        if (this.map && this.map.map) {
            this.map.map.on('click', (e) => {
                // NÃO SELECIONAR polígonos se estiver em modo de desenho
                if (this.map.map._drawingMode) {
                    console.log('🎨 Modo de desenho ativo - seleção desabilitada');
                    return;
                }
                
                // Verificar se clicou em um polígono
                const clickedLayers = [];
                
                // Verificar na camada de polígonos
                this.map.layers.polygons.eachLayer((layer) => {
                    if (layer instanceof L.Polygon || layer instanceof L.GeoJSON) {
                        layer.eachLayer((subLayer) => {
                            if (subLayer instanceof L.Polygon && 
                                subLayer.getBounds && 
                                subLayer.getBounds().contains(e.latlng)) {
                                clickedLayers.push(subLayer);
                            }
                        });
                    } else if (layer instanceof L.Polygon && 
                               layer.getBounds && 
                               layer.getBounds().contains(e.latlng)) {
                        clickedLayers.push(layer);
                    }
                });
                
                // Verificar na camada de desenhos
                this.map.layers.drawings.eachLayer((layer) => {
                    if (layer instanceof L.Polygon && 
                        layer.getBounds && 
                        layer.getBounds().contains(e.latlng)) {
                        clickedLayers.push(layer);
                    }
                });
                
                if (clickedLayers.length > 0) {
                    // Selecionar o polígono mais recente (último da lista)
                    const polygon = clickedLayers[clickedLayers.length - 1];
                    this.selectPolygon(polygon);
                } else {
                    // Clicou fora de qualquer polígono - desselecionar
                    this.deselectPolygon();
                }
            });

            // Listeners para edição de polígonos (atualização de área em tempo real)
            this.map.map.on('draw:edited', async (e) => {
                console.log('🖊️ Polígono editado');
                const layers = e.layers;
                
                layers.eachLayer((layer) => {
                    if (layer instanceof L.Polygon && layer === this.selectedPolygon) {
                        // Calcular nova área
                        const areaHectares = L.GeometryUtil.geodesicArea(layer.getLatLngs()[0]) / 10000;
                        
                        // Atualizar área no center-item
                        if (layer.centerKey) {
                            this.updateCenterItemArea(layer.centerKey, areaHectares);
                            console.log(`✅ Área atualizada após edição: ${areaHectares.toFixed(2)} ha`);
                        }
                    }
                });
                
                // Atualizar polígonos de fundo após edição
                console.log('🔄 Atualizando polígonos de fundo após edição...');
                await this.map.loadBackgroundTerritories();
            });

            // Listener para quando vértices são arrastados
            this.map.map.on('draw:editvertex', (e) => {
                if (this.selectedPolygon) {
                    // Calcular nova área em tempo real
                    const areaHectares = L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000;
                    
                    // Atualizar área no center-item
                    if (this.selectedPolygon.centerKey) {
                        this.updateCenterItemArea(this.selectedPolygon.centerKey, areaHectares);
                    }
                }
            });
            
            // Listener para quando polígonos são deletados
            this.map.map.on('draw:deleted', async (e) => {
                console.log('🗑️ Polígonos deletados via ferramenta de desenho');
                
                // Atualizar polígonos de fundo
                console.log('🔄 Atualizando polígonos de fundo após deletar...');
                await this.map.loadBackgroundTerritories();
                
                this.showNotification('✅ Polígonos removidos do mapa', 'success');
            });
        }
    }

    /**
     * Desseleciona o polígono atual
     */
    deselectPolygon() {
        if (this.selectedPolygon) {
            // Desativar modo de edição
            this.disableEditMode();
            
            // Remover destaque visual
            this.selectedPolygon.setStyle({ 
                weight: 3, 
                opacity: 0.8,
                color: this.map.territoryColors.territory
            });
            
            // Limpar referências
            this.selectedPolygon = null;
            this.map.currentPolygon = null;
            
            console.log('📍 Polígono desmarcado');
        }
    }

    /**
     * Seleciona um polígono (SEM ativar edição automaticamente)
     */
    selectPolygon(polygon) {
        // 🔧 BLOQUEIO: Não processar se o pincel estiver ativo
        if (this.map.eraserState && this.map.eraserState.active) {
            console.log('🎨 Pincel ativo - ignorando seleção de polígono');
            return;
        }
        
        console.log('📍 Polígono selecionado:', polygon);
        
        // Armazenar como polígono selecionado
        this.selectedPolygon = polygon;
        this.map.currentPolygon = polygon;
        
        // Destacar visualmente o polígono selecionado
        this.highlightSelectedPolygon(polygon);
        
        // NÃO ativar modo de edição automaticamente
        // Edição apenas ao clicar nas ferramentas (Editar/Apagar Vértices)
        console.log('ℹ️ Polígono selecionado em modo VISUALIZAÇÃO (use ferramentas para editar)');
        
        // Notificar usuário
        this.showNotification('📍 Polígono selecionado', 'info');
    }

    /**
     * Ativa modo de edição para o polígono selecionado
     */
    enableEditMode(polygon) {
        try {
            // Verificar se o polígono já é editável
            if (polygon.editing && polygon.editing.enabled()) {
                console.log('Polígono já está em modo de edição');
                return;
            }
            
            // Usar o método do MapManager para ativar edição
            const success = this.map.enablePolygonEdit(polygon);
            
            if (success) {
                console.log('✅ Modo de edição ativado');
                
                // Atualizar botão de edição para mostrar estado ativo
                const editBtn = document.getElementById('btnEditPolygon');
                if (editBtn) {
                    editBtn.classList.add('active');
                    editBtn.innerHTML = '<i class="bi bi-pencil-square" aria-hidden="true"></i><span>Editando</span>';
                }
            } else {
                console.warn('⚠️ Não foi possível ativar modo de edição');
            }
            
        } catch (error) {
            console.error('Erro ao ativar modo de edição:', error);
        }
    }

    /**
     * Desativa modo de edição
     */
    disableEditMode() {
        try {
            if (this.selectedPolygon) {
                this.map.disablePolygonEdit(this.selectedPolygon);
            }
            
            // Atualizar botão de edição
            const editBtn = document.getElementById('btnEditPolygon');
            if (editBtn) {
                editBtn.classList.remove('active');
                editBtn.innerHTML = '<i class="bi bi-pencil-square" aria-hidden="true"></i><span>Editar</span>';
            }
            
            console.log('✅ Modo de edição desativado');
        } catch (error) {
            console.error('Erro ao desativar modo de edição:', error);
        }
    }

    /**
     * Destaca o polígono selecionado
     */
    highlightSelectedPolygon(polygon) {
        // Remover destaque de outros polígonos
        this.map.layers.polygons.eachLayer((layer) => {
            if (layer instanceof L.GeoJSON) {
                layer.eachLayer((subLayer) => {
                    if (subLayer instanceof L.Polygon && subLayer !== polygon) {
                        subLayer.setStyle({ 
                            weight: 3, 
                            opacity: 0.8,
                            color: this.map.territoryColors.territory
                        });
                    }
                });
            } else if (layer instanceof L.Polygon && layer !== polygon) {
                layer.setStyle({ 
                    weight: 3, 
                    opacity: 0.8,
                    color: this.map.territoryColors.territory
                });
            }
        });
        
        // Destacar o polígono selecionado
        polygon.setStyle({ 
            weight: 4, 
            opacity: 1, 
            color: '#ff0000',
            fillOpacity: 0.3
        });
    }

    /**
     * Configura todos os event listeners
     */
    setupEventListeners() {
        // NOTA: Botões da vertical toolbar foram removidos
        // Adicionar listeners apenas para botões que existem
        
        // Barra de ferramentas de edição (rodapé)
        const btnLassoDeleteFooter = document.getElementById('btnLassoDeleteFooter');
        const btnSaveEdit = document.getElementById('btnSaveEdit');
        const btnCancelEdit = document.getElementById('btnCancelEdit');
        const btnLoadCAR = document.getElementById('btnLoadCAR');
        const btnAdjustToCAR = document.getElementById('btnAdjustToCAR');
        
        if (btnLassoDeleteFooter) btnLassoDeleteFooter.addEventListener('click', () => this.handleLassoDelete());
        if (btnSaveEdit) btnSaveEdit.addEventListener('click', () => this.handleSaveEdit());
        if (btnCancelEdit) btnCancelEdit.addEventListener('click', () => this.handleCancelEdit());
        if (btnLoadCAR) btnLoadCAR.addEventListener('click', () => this.handleLoadCAR());
        if (btnAdjustToCAR) btnAdjustToCAR.addEventListener('click', () => this.handleAdjustToCAR());
        
        // Toggle all regions (existe)
        const btnToggleAll = document.getElementById('btnToggleAll');
        if (btnToggleAll) btnToggleAll.addEventListener('click', () => this.toggleAllRegions());

        // Toggle sidebar (recolher/expandir)
        const btnToggleSidebar = document.getElementById('btnToggleSidebar');
        if (btnToggleSidebar) {
            btnToggleSidebar.addEventListener('click', () => this.toggleSidebar());
        }

        // Botão fechar legenda de consultores
        const btnCloseLegend = document.getElementById('btnCloseLegend');
        if (btnCloseLegend) {
            btnCloseLegend.addEventListener('click', () => {
                const legendElement = document.getElementById('consultorLegend');
                if (legendElement) {
                    legendElement.style.display = 'none';
                }
            });
        }
        
        // Botão alternar modo de visualização (Consultor/Unidade) - na legenda
        const btnToggleViewMode = document.getElementById('btnToggleViewMode');
        if (btnToggleViewMode) {
            btnToggleViewMode.addEventListener('click', async () => {
                await this.toggleViewMode();
            });
        }

        // Checkbox "Áreas por Unidade" no header
        const chkAreasUnidade = document.getElementById('chkAreasUnidade');
        if (chkAreasUnidade) {
            chkAreasUnidade.addEventListener('change', async (e) => {
                await this.toggleAreasUnidade(e.target.checked);
            });
        }

        // New territory modal
        const btnConfirmNewTerritory = document.getElementById('btnConfirmNewTerritory');
        if (btnConfirmNewTerritory) btnConfirmNewTerritory.addEventListener('click', () => this.handleConfirmNewTerritory());
        
        // Polygon details modal
        const btnSavePolygonDetails = document.getElementById('btnSavePolygonDetails');
        if (btnSavePolygonDetails) btnSavePolygonDetails.addEventListener('click', () => this.handleSavePolygonDetails());
        
        // CAR Confirmation modal
        const btnSaveCARToSupabase = document.getElementById('btnSaveCARToSupabase');
        if (btnSaveCARToSupabase) btnSaveCARToSupabase.addEventListener('click', () => this.handleSaveCARToSupabase());
        
        // Smooth Confirmation modal
        const btnSaveSmoothToSupabase = document.getElementById('btnSaveSmoothToSupabase');
        const btnCancelSmooth = document.getElementById('btnCancelSmooth');
        if (btnSaveSmoothToSupabase) btnSaveSmoothToSupabase.addEventListener('click', () => this.handleSaveSmoothToSupabase());
        if (btnCancelSmooth) btnCancelSmooth.addEventListener('click', () => this.handleCancelSmooth());
        
        // Search functionality
        this.setupSearchListeners();
    }
    
    /**
     * Configura listeners de busca de centros
     */
    setupSearchListeners() {
        const searchInput = document.getElementById('centerSearch');
        const searchResults = document.getElementById('searchResults');
        const btnClearSearch = document.getElementById('btnClearSearch');
        
        if (!searchInput || !searchResults) {
            return;
        }
        
        // Input de busca - filtrar em tempo real
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim().toLowerCase();
            
            if (query.length === 0) {
                searchResults.style.display = 'none';
                btnClearSearch.style.display = 'none';
                return;
            }
            
            btnClearSearch.style.display = 'inline-block';
            this.performSearch(query);
        });
        
        // Limpar busca
        if (btnClearSearch) {
            btnClearSearch.addEventListener('click', () => {
                searchInput.value = '';
                searchResults.style.display = 'none';
                btnClearSearch.style.display = 'none';
                searchInput.focus();
            });
        }
        
        // Fechar resultados ao clicar fora
        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target) && 
                !searchResults.contains(e.target) &&
                !btnClearSearch.contains(e.target)) {
                searchResults.style.display = 'none';
            }
        });
        
        // Focar no input ao clicar no ícone
        const searchIcon = document.querySelector('.search-container .input-group-text');
        if (searchIcon) {
            searchIcon.addEventListener('click', () => {
                searchInput.focus();
            });
        }
    }
    
    /**
     * Realiza a busca de centros
     */
    performSearch(query) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;
        
        const results = [];
        
        // Buscar em todas as regiões
        for (const [regionName, regionData] of Object.entries(REGION_CENTER_DATA)) {
            // regionData é um array de centros
            if (!Array.isArray(regionData)) continue;
            
            // Buscar em cada centro da região
            for (const centro of regionData) {
                const centerName = centro.centro.toLowerCase();
                const centerCode = centro.centroChave.toLowerCase();
                
                // Verificar se a query corresponde ao nome ou código
                if (centerName.includes(query) || centerCode.includes(query)) {
                    results.push({
                        regionName,
                        centro,
                        matchType: centerCode.includes(query) ? 'code' : 'name'
                    });
                }
            }
        }
        
        // Exibir resultados
        this.displaySearchResults(results, query);
    }
    
    /**
     * Exibe os resultados da busca
     */
    displaySearchResults(results, query) {
        const searchResults = document.getElementById('searchResults');
        if (!searchResults) return;
        
        if (results.length === 0) {
            searchResults.innerHTML = `
                <div class="search-no-results">
                    <i class="bi bi-search" aria-hidden="true"></i>
                    Nenhum centro encontrado
                </div>
            `;
            searchResults.style.display = 'block';
            return;
        }
        
        // Limitar a 50 resultados
        const limitedResults = results.slice(0, 50);
        
        searchResults.innerHTML = limitedResults.map(result => {
            const centerName = this.highlightMatch(result.centro.centro, query);
            const centerCode = this.highlightMatch(result.centro.centroChave, query);
            
            return `
                <div class="search-result-item" data-region="${result.regionName}" data-center="${result.centro.centroChave}">
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"></i>
                    <div class="search-result-content">
                        <div class="search-result-name">${centerName}</div>
                        <div class="search-result-details">${centerCode} • ${result.regionName}</div>
                    </div>
                </div>
            `;
        }).join('');
        
        searchResults.style.display = 'block';
        
        // Adicionar listeners aos resultados
        searchResults.querySelectorAll('.search-result-item').forEach(item => {
            item.addEventListener('click', () => {
                const regionName = item.getAttribute('data-region');
                const centerCode = item.getAttribute('data-center');
                this.handleSearchResultClick(regionName, centerCode);
            });
        });
    }
    
    /**
     * Destaca o texto correspondente na busca
     */
    highlightMatch(text, query) {
        if (!query) return text;
        
        const regex = new RegExp(`(${query})`, 'gi');
        return text.replace(regex, '<span class="search-highlight">$1</span>');
    }
    
    /**
     * Trata o clique em um resultado de busca
     */
    async handleSearchResultClick(regionName, centerCode) {
        const searchResults = document.getElementById('searchResults');
        const searchInput = document.getElementById('centerSearch');
        const btnClearSearch = document.getElementById('btnClearSearch');
        
        // Fechar resultados
        if (searchResults) {
            searchResults.style.display = 'none';
        }
        
        // Limpar campo de busca
        if (searchInput) {
            searchInput.value = '';
        }
        
        if (btnClearSearch) {
            btnClearSearch.style.display = 'none';
        }
        
        // Encontrar e expandir a região
        const regionData = REGION_CENTER_DATA[regionName];
        if (!regionData) {
            this.showNotification('⚠️ Região não encontrada', 'warning');
            return;
        }
        
        // Expandir a região se estiver colapsada
        const regionElement = document.querySelector(`[data-region-id="${regionName}"]`);
        if (regionElement) {
            regionElement.classList.remove('collapsed');
        }
        
        // Encontrar o centro (agora o centro pode ter ou não território)
        const centerElement = document.querySelector(`[data-center-key="${centerCode}"]`);
        if (centerElement) {
            // Scroll até o elemento
            centerElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Destacar temporariamente
            centerElement.style.backgroundColor = '#fef3c7';
            setTimeout(() => {
                centerElement.style.backgroundColor = '';
            }, 2000);
            
            // Simular clique no centro (que vai carregar território se existir, ou criar novo)
            setTimeout(() => {
                centerElement.click();
            }, 300);
            
            // Mensagem apropriada
            const hasTerritory = centerElement.classList.contains('has-territory');
            if (hasTerritory) {
                this.showNotification(`📍 Carregando território de ${centerCode}`, 'info');
            } else {
                this.showNotification(`📍 Selecionado ${centerCode}`, 'info');
            }
        } else {
            this.showNotification(`⚠️ Centro ${centerCode} não encontrado na árvore`, 'warning');
        }
    }

    // ==================== TOOLBAR ACTIONS ====================

    /**
     * Desenhar polígono
     */
    handleDrawPolygon() {
        // Verificar se há um território pendente (novo) ou se está editando um existente
        if (this.pendingTerritory) {
            console.log(`📐 Desenhando território: ${this.pendingTerritory.id}`);
            this.map.startDrawing();
            this.showNotification(`✏️ Desenhando território ${this.pendingTerritory.id}`, 'info');
        } else if (this.currentTerritory) {
            // Aviso: já existe um território carregado
            const confirm = window.confirm(`⚠️ Já existe um território carregado (${this.currentTerritory.territory_id}).\n\nDeseja criar uma sub-área dentro deste território?`);
            if (confirm) {
                // TODO: Implementar lógica de sub-área
                this.showNotification('ℹ️ Funcionalidade de sub-área em desenvolvimento', 'info');
            }
        } else {
            this.showNotification('⚠️ Selecione um centro na árvore para criar território', 'warning');
        }
    }

    /**
     * Editar polígono
     */
    handleEditPolygon() {
        if (!this.currentTerritory && !this.selectedPolygon) {
            this.showNotification('⚠️ Selecione um território na árvore para editar', 'warning');
            return;
        }
        
        this.map.startEditing();
        
        // Mostrar barra de ferramentas de edição no rodapé
        const editToolbar = document.getElementById('editToolbar');
        if (editToolbar) {
            editToolbar.style.display = 'block';
        }

        // Atualizar label da barra
        const label = document.getElementById('editToolbarLabel');
        if (label) {
            label.textContent = `Editando: ${this.currentTerritory?.territory_id || 'Polígono'}`;
        }
        
        this.showNotification(`🔧 Editando território ${this.currentTerritory?.territory_id || ''}`, 'info');
    }

    /**
     * Ativar ferramenta de laço para deletar múltiplos pontos
     */
    handleLassoDelete() {
        if (!this.currentPolygon) {
            this.showNotification('⚠️ Nenhum polígono em edição', 'warning');
            return;
        }

        const success = this.map.enableLassoSelection(this.currentPolygon);
        
        if (success) {
            this.showNotification('🎯 Desenhe um laço ao redor dos pontos a deletar', 'info');
            
            // Atualizar label da barra
            const label = document.getElementById('editToolbarLabel');
            if (label) {
                label.textContent = 'Modo Laço - Desenhe ao redor dos pontos';
            }
        } else {
            this.showNotification('❌ Erro ao ativar ferramenta de laço', 'error');
        }
    }

    /**
     * Salvar edição do polígono (TERRITÓRIO)
     */
    async handleSaveEdit() {
        if (!this.currentPolygon) {
            this.showNotification('⚠️ Nenhum polígono em edição', 'warning');
            return;
        }

        // Verificar se é território ou carteira
        if (this.currentPolygon.subTerritoryData) {
            console.warn('⚠️ Este é um sub-território, use handleSaveSubTerritoryEdit()');
            return await this.handleSaveSubTerritoryEdit();
        }

        if (!this.currentTerritory) {
            this.showNotification('⚠️ Nenhum território carregado', 'warning');
            return;
        }

        try {
            console.log('💾 Salvando território no banco de dados...');
            
            // Obter geometria atualizada
            const updatedGeometry = this.currentPolygon.toGeoJSON();
            
            // Calcular área atualizada
            const areaHectares = L.GeometryUtil.geodesicArea(this.currentPolygon.getLatLngs()[0]) / 10000;
            
            // Atualizar no banco de dados
            await this.dataManager.updateTerritory(this.currentTerritory.id, {
                geometry: updatedGeometry,
                area_hectares: areaHectares
            });
            
            console.log('✅ Território salvo com sucesso:', {
                id: this.currentTerritory.id,
                territory_id: this.currentTerritory.territory_id,
                area_hectares: areaHectares.toFixed(2)
            });

            // Desabilitar edição
            this.map.disablePolygonEdit(this.currentPolygon);

            // Esconder barra de ferramentas
            const editToolbar = document.getElementById('editToolbar');
            if (editToolbar) {
                editToolbar.style.display = 'none';
            }

            // Recarregar árvore
            await this.loadRegionsTree();
            
            // ATUALIZAR POLÍGONOS NA TELA
            console.log('🔄 Atualizando polígonos de fundo na tela...');
            await this.map.loadBackgroundTerritories();

            this.showNotification(`✅ Território ${this.currentTerritory.territory_id} atualizado (${areaHectares.toFixed(2)} ha)`, 'success');
            
        } catch (error) {
            console.error('❌ Erro ao salvar território:', error);
            this.showNotification('❌ Erro ao salvar território', 'error');
        }
    }

    /**
     * Salvar edição da carteira
     */
    async handleSaveSubTerritoryEdit() {
        if (!this.currentPolygon || !this.currentSubTerritory) {
            this.showNotification('⚠️ Nenhuma carteira em edição', 'warning');
            return;
        }

        try {
            // Obter geometria atualizada
            let updatedGeometry = this.currentPolygon.toGeoJSON();

            // Calcular área
            const areaHectares = L.GeometryUtil.geodesicArea(this.currentPolygon.getLatLngs()[0]) / 10000;

            // ========================================
            // PASSO 1: VERIFICAR SOBREPOSIÇÃO COM OUTRAS CARTEIRAS
            // (Fazer ANTES de verificar boundary, pois sobreposição pode causar falso positivo)
            // ========================================
            console.log('🔍 PASSO 1: Verificando sobreposição com outras carteiras...');
            const overlapCheck = await this.dataManager.checkSubTerritoryOverlap(
                updatedGeometry,
                this.currentSubTerritory.territory_id,
                this.currentSubTerritory.id // excluir a própria carteira
            );

            if (overlapCheck.hasOverlap) {
                console.warn('⚠️ Sobreposição detectada!', overlapCheck);
                
                // Exibir modal de tratamento de sobreposição
                await this._handleSubTerritoryOverlapFlow(
                    updatedGeometry,
                    overlapCheck.overlappingSubTerritories,
                    areaHectares
                );
                return; // Interromper fluxo normal de salvamento
            }

            // ========================================
            // PASSO 2: GARANTIR QUE ESTÁ DENTRO DO TERRITÓRIO PAI (INTERSECT OBRIGATÓRIO)
            // (Fazer DEPOIS de resolver sobreposições)
            // ========================================
            console.log('🔍 PASSO 2: Aplicando INTERSECT com território pai (obrigatório)...');
            
            // Buscar geometria do território pai
            const territories = await this.dataManager.listTerritories();
            const parentTerritory = territories.find(t => t.id === this.currentSubTerritory.territory_id);
            
            if (!parentTerritory) {
                this.showNotification('❌ Erro: Território pai não encontrado', 'error');
                return;
            }

            const parentGeo = typeof parentTerritory.geometry === 'string' 
                ? JSON.parse(parentTerritory.geometry) 
                : parentTerritory.geometry;
            
            const subGeo = typeof updatedGeometry === 'string'
                ? JSON.parse(updatedGeometry)
                : (updatedGeometry.geometry || updatedGeometry);

            // Extrair SOMENTE geometry (não Feature)
            const subGeometry = subGeo.type === 'Feature' ? subGeo.geometry : subGeo;
            const parentGeometry = parentGeo.type === 'Feature' ? parentGeo.geometry : parentGeo;

            // SEMPRE aplicar INTERSECT para garantir que está dentro do território pai
            const intersectResult = turf.intersect(
                turf.feature(subGeometry),
                turf.feature(parentGeometry)
            );

            if (!intersectResult) {
                console.error('❌ INTERSECT resultou em null - sub-território completamente fora do pai');
                this.showNotification('❌ Erro: A carteira está completamente fora do território pai', 'error');
                await this.selectSubTerritory(this.currentSubTerritory);
                return;
            }

            // Atualizar geometria com resultado do INTERSECT
            updatedGeometry = intersectResult.geometry;
            console.log('✅ INTERSECT aplicado - Carteira ajustada aos limites do território pai');

            // ========================================
            // PASSO 3: SALVAR (geometria já ajustada aos limites)
            // ========================================
            console.log('✅ Validações OK, salvando...');
            await this.dataManager.updateSubTerritory(this.currentSubTerritory.id, {
                geometry: updatedGeometry,
                area_hectares: areaHectares
            });

            // Desabilitar edição
            this.map.disablePolygonEdit(this.currentPolygon);

            // Restaurar rodapé normal
            this.updateSubTerritoryFooter(this.currentSubTerritory.id, false);

            // Recarregar árvore
            await this.loadRegionsTree();
            
            // ATUALIZAR POLÍGONOS NA TELA
            console.log('🔄 Atualizando polígonos de fundo na tela...');
            await this.map.loadBackgroundTerritories();

            // REEXIBIR o polígono atualizado no mapa
            console.log('📍 Reexibindo carteira atualizada no mapa...');
            await this.selectSubTerritory(this.currentSubTerritory);

            this.showNotification(`✅ Carteira ${this.currentSubTerritory.carteira_id} atualizada`, 'success');

        } catch (error) {
            console.error('Erro ao salvar carteira:', error);
            this.showNotification('❌ Erro ao salvar carteira', 'error');
        }
    }

    /**
     * Fluxo de tratamento de sobreposição em carteiras
     * 
     * ORDEM DE EXECUÇÃO:
     * 1. Verificar sobreposição (PRIMEIRO)
     * 2. Se houver, exibir modal com opções
     * 3. Após resolver sobreposição, verificar boundary
     * 4. Salvar apenas se passou em todas as validações
     */
    async _handleSubTerritoryOverlapFlow(geometry, overlappingSubTerritories, areaHectares) {
        console.log('✂️ Iniciando fluxo de tratamento de sobreposição...');

        return new Promise((resolve) => {
            // Criar modal
            const modal = document.createElement('div');
            modal.id = 'overlap-treatment-modal';
            modal.innerHTML = `
                <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; 
                            background: rgba(0, 0, 0, 0.7); z-index: 10002; 
                            display: flex; align-items: center; justify-content: center;
                            animation: fadeIn 0.2s ease-out;">
                    <div style="background: white; border-radius: 12px; padding: 28px; 
                                max-width: 620px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                                animation: slideUp 0.3s ease-out;">
                        
                        <!-- Header -->
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                            <i class="bi bi-exclamation-triangle-fill" style="font-size: 2.5rem; color: #f97316;"></i>
                            <h3 style="margin: 0; color: #1e293b; font-size: 1.4rem;">Sobreposição Detectada</h3>
                        </div>

                        <!-- Alert -->
                        <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px;">
                            <p style="margin: 0; color: #92400e; font-size: 0.95rem;">
                                <strong>A carteira ${this.currentSubTerritory.carteira_id} sobrepõe ${overlappingSubTerritories.length} carteira(s) existente(s)</strong>
                            </p>
                        </div>

                        <!-- Escolha de ação -->
                        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                            <h6 style="color: #1e293b; margin: 0 0 16px 0; font-size: 1rem; font-weight: 600;">
                                <i class="bi bi-question-circle"></i> Qual carteira deve ser mantida?
                            </h6>
                            
                            <!-- Opção 1: Manter a atual (recortar as outras) -->
                            <div style="background: white; padding: 16px; border-radius: 8px; margin-bottom: 12px; 
                                        border: 2px solid #e2e8f0; cursor: pointer; transition: all 0.2s;"
                                 class="overlap-option" data-action="keep-current">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <input type="radio" name="overlap-choice" value="keep-current" style="width: 18px; height: 18px;">
                                    <div style="flex: 1;">
                                        <strong style="color: #1e293b; font-size: 1rem;">Manter a atual (${this.currentSubTerritory.carteira_id})</strong>
                                        <p style="margin: 4px 0 0 0; color: #64748b; font-size: 0.85rem;">
                                            As outras ${overlappingSubTerritories.length} carteira(s) serão recortadas
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <!-- Opção 2: Manter as outras (recortar a atual) -->
                            <div style="background: white; padding: 16px; border-radius: 8px; 
                                        border: 2px solid #e2e8f0; cursor: pointer; transition: all 0.2s;"
                                 class="overlap-option" data-action="trim-current">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <input type="radio" name="overlap-choice" value="trim-current" style="width: 18px; height: 18px;">
                                    <div style="flex: 1;">
                                        <strong style="color: #1e293b; font-size: 1rem;">Recortar a atual (${this.currentSubTerritory.carteira_id})</strong>
                                        <p style="margin: 4px 0 0 0; color: #64748b; font-size: 0.85rem;">
                                            Manter as outras ${overlappingSubTerritories.length} carteira(s) intactas
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Lista de carteiras sobrepostas -->
                        <div style="background: #f1f5f9; padding: 16px; border-radius: 8px; margin-bottom: 20px; max-height: 180px; overflow-y: auto;">
                            <h6 style="color: #64748b; margin: 0 0 12px 0; font-size: 0.85rem;">
                                <i class="bi bi-layers"></i> Carteiras Sobrepostas:
                            </h6>
                            ${overlappingSubTerritories.map(sub => `
                                <div style="background: white; padding: 8px 12px; border-radius: 6px; margin-bottom: 8px; border-left: 3px solid #ef4444;">
                                    <strong style="color: #1e293b;">${sub.carteira_id}</strong>
                                    ${sub.name ? `<br><small style="color: #64748b;">${sub.name}</small>` : ''}
                                    <br><small style="color: #64748b;">${sub.area_hectares ? sub.area_hectares.toFixed(2) + ' ha' : 'Área não disponível'}</small>
                                </div>
                            `).join('')}
                        </div>

                        <!-- Botões -->
                        <div style="display: flex; gap: 12px; justify-content: flex-end;">
                            <button id="btn-overlap-cancel" 
                                    style="padding: 12px 24px; border: 2px solid #64748b; 
                                           background: white; color: #64748b; border-radius: 8px; 
                                           font-weight: 600; cursor: pointer; transition: all 0.2s;
                                           font-size: 0.95rem;">
                                <i class="bi bi-x-circle"></i> Cancelar Edição
                            </button>
                            <button id="btn-overlap-apply" disabled
                                    style="padding: 12px 24px; border: none; 
                                           background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); 
                                           color: white; border-radius: 8px; 
                                           font-weight: 600; cursor: pointer; transition: all 0.2s;
                                           box-shadow: 0 2px 8px rgba(249, 115, 22, 0.3);
                                           font-size: 0.95rem; opacity: 0.5;">
                                <i class="bi bi-scissors"></i> Aplicar Recorte
                            </button>
                        </div>
                    </div>
                </div>
            `;

            const style = document.createElement('style');
            style.textContent = `
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideUp {
                    from { transform: translateY(20px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                #btn-overlap-cancel:hover { background: #64748b; color: white; }
                #btn-overlap-apply:not(:disabled):hover { 
                    transform: translateY(-2px); 
                    box-shadow: 0 4px 12px rgba(249, 115, 22, 0.4); 
                }
                #btn-overlap-apply:disabled {
                    cursor: not-allowed;
                }
                .overlap-option:hover {
                    border-color: #f97316 !important;
                    background: #fff7ed !important;
                }
                .overlap-option.selected {
                    border-color: #f97316 !important;
                    background: #fff7ed !important;
                }
            `;
            document.head.appendChild(style);
            document.body.appendChild(modal);

            // Buscar elementos
            const btnCancel = modal.querySelector('#btn-overlap-cancel');
            const btnApply = modal.querySelector('#btn-overlap-apply');
            const options = modal.querySelectorAll('.overlap-option');
            const radios = modal.querySelectorAll('input[name="overlap-choice"]');
            
            let selectedAction = null;

            // Gerenciar seleção de opções
            options.forEach(option => {
                option.addEventListener('click', () => {
                    // Remover seleção anterior
                    options.forEach(opt => opt.classList.remove('selected'));
                    
                    // Selecionar nova opção
                    option.classList.add('selected');
                    const radio = option.querySelector('input[type="radio"]');
                    radio.checked = true;
                    selectedAction = radio.value;
                    
                    // Habilitar botão aplicar
                    btnApply.disabled = false;
                    btnApply.style.opacity = '1';
                    btnApply.style.cursor = 'pointer';
                    
                    console.log('✅ Opção selecionada:', selectedAction);
                });
            });

            // Cancelar edição
            if (btnCancel) {
                btnCancel.addEventListener('click', () => {
                    console.log('❌ Usuário cancelou edição');
                    modal.remove();
                    this.showNotification('↩️ Edição cancelada', 'info');
                    
                    // Recarregar carteira original
                    this.selectSubTerritory(this.currentSubTerritory);
                    resolve('cancelled');
                });
            }

            // Aplicar recorte
            if (btnApply) {
                btnApply.addEventListener('click', async () => {
                    if (!selectedAction) {
                        this.showNotification('⚠️ Selecione uma opção primeiro', 'warning');
                        return;
                    }

                    console.log('✂️ Aplicando recorte com ação:', selectedAction);
                    modal.remove();

                    try {
                        if (selectedAction === 'trim-current') {
                            // Recortar a carteira atual
                            await this._trimCurrentSubTerritory(geometry, overlappingSubTerritories);
                        } else if (selectedAction === 'keep-current') {
                            // Recortar as outras carteiras
                            await this._trimOtherSubTerritories(geometry, overlappingSubTerritories);
                        }

                        resolve('trimmed');

                    } catch (error) {
                        console.error('❌ Erro ao aplicar recorte:', error);
                        this.showNotification('❌ Erro ao aplicar recorte', 'error');
                        resolve('error');
                    }
                });
            }
        });
    }

    /**
     * Recorta a carteira atual removendo as sobreposições
     */
    async _trimCurrentSubTerritory(geometry, overlappingSubTerritories) {
        console.log('✂️ Recortando carteira atual:', this.currentSubTerritory.carteira_id);

        // Buscar geometria do território pai para validar fragmentos
        const territories = await this.dataManager.listTerritories();
        const parentTerritory = territories.find(t => t.id === this.currentSubTerritory.territory_id);
        
        if (!parentTerritory) {
            this.showNotification('❌ Erro: Território pai não encontrado', 'error');
            return;
        }

        const parentGeo = typeof parentTerritory.geometry === 'string' 
            ? JSON.parse(parentTerritory.geometry) 
            : parentTerritory.geometry;

        // Aplicar trim usando turf.js COM validação de fragmentos
        const trimmedGeometry = await this._applySubTerritoryTrim(
            geometry,
            overlappingSubTerritories,
            parentGeo // Passar geometria do território pai
        );

        if (!trimmedGeometry) {
            this.showNotification('❌ Erro ao aplicar recorte', 'error');
            return;
        }

        // Calcular nova área
        const layer = L.geoJSON(trimmedGeometry);
        const newArea = L.GeometryUtil.geodesicArea(layer.getLayers()[0].getLatLngs()[0]) / 10000;

        // Atualizar no banco com geometria recortada
        await this.dataManager.updateSubTerritory(this.currentSubTerritory.id, {
            geometry: trimmedGeometry,
            area_hectares: newArea
        });

        // Desabilitar edição
        this.map.disablePolygonEdit(this.currentPolygon);

        // Restaurar rodapé normal
        this.updateSubTerritoryFooter(this.currentSubTerritory.id, false);

        // Recarregar árvore
        await this.loadRegionsTree();
        
        // ATUALIZAR POLÍGONOS NA TELA
        console.log('🔄 Atualizando polígonos de fundo na tela...');
        await this.map.loadBackgroundTerritories();

        // Recarregar carteira para ver resultado
        await this.selectSubTerritory(this.currentSubTerritory);

        this.showNotification(`✅ Carteira ${this.currentSubTerritory.carteira_id} recortada e atualizada`, 'success');
    }

    /**
     * Recorta as outras carteiras mantendo a atual intacta
     */
    async _trimOtherSubTerritories(geometry, overlappingSubTerritories) {
        console.log('✂️ Recortando outras carteiras, mantendo:', this.currentSubTerritory.carteira_id);

        // Buscar geometria do território pai para validar fragmentos
        const territories = await this.dataManager.listTerritories();
        const parentTerritory = territories.find(t => t.id === this.currentSubTerritory.territory_id);
        
        if (!parentTerritory) {
            this.showNotification('❌ Erro: Território pai não encontrado', 'error');
            return;
        }

        const parentGeo = typeof parentTerritory.geometry === 'string' 
            ? JSON.parse(parentTerritory.geometry) 
            : parentTerritory.geometry;

        let successCount = 0;
        let errorCount = 0;

        // Para cada carteira sobreposta, recortá-la
        for (const overlapping of overlappingSubTerritories) {
            try {
                console.log(`✂️ Processando: ${overlapping.carteira_id}`);
                
                console.log('🔍 DEBUG _trimOtherSubTerritories:');
                console.log('  - overlapping.geometry (raw):', overlapping.geometry);

                // Obter geometria da carteira sobreposta
                let overlappingGeo = typeof overlapping.geometry === 'string'
                    ? JSON.parse(overlapping.geometry)
                    : overlapping.geometry;

                console.log('  - overlappingGeo (processado):', overlappingGeo);
                console.log('  - geometry (parâmetro):', geometry);

                // Normalizar geometria atual para passar como "sobreposta"
                let currentGeo = typeof geometry === 'string' 
                    ? JSON.parse(geometry) 
                    : (geometry.geometry || geometry);

                console.log('  - currentGeo (normalizado):', currentGeo);
                console.log('  - Criando objeto para passar:', { 
                    geometry: currentGeo,
                    carteira_id: this.currentSubTerritory?.carteira_id || 'atual'
                });

                // Aplicar difference: remover a geometria atual da sobreposta COM validação de fragmentos
                const trimmedGeometry = await this._applySubTerritoryTrim(
                    overlappingGeo,
                    [{ 
                        geometry: currentGeo,
                        carteira_id: this.currentSubTerritory?.carteira_id || 'atual'
                    }],
                    parentGeo // Passar geometria do território pai
                );

                if (!trimmedGeometry) {
                    console.warn(`⚠️ Não foi possível recortar ${overlapping.carteira_id}`);
                    errorCount++;
                    continue;
                }

                // Calcular nova área
                const layer = L.geoJSON(trimmedGeometry);
                const newArea = L.GeometryUtil.geodesicArea(layer.getLayers()[0].getLatLngs()[0]) / 10000;

                // Atualizar no banco
                await this.dataManager.updateSubTerritory(overlapping.id, {
                    geometry: trimmedGeometry,
                    area_hectares: newArea
                });

                console.log(`✅ ${overlapping.carteira_id} recortada com sucesso`);
                successCount++;

            } catch (error) {
                console.error(`❌ Erro ao recortar ${overlapping.carteira_id}:`, error);
                errorCount++;
            }
        }

        // Salvar a carteira atual (sem recorte)
        const layer = L.geoJSON(geometry);
        const newArea = L.GeometryUtil.geodesicArea(layer.getLayers()[0].getLatLngs()[0]) / 10000;

        await this.dataManager.updateSubTerritory(this.currentSubTerritory.id, {
            geometry: geometry,
            area_hectares: newArea
        });

        // Desabilitar edição
        this.map.disablePolygonEdit(this.currentPolygon);

        // Restaurar rodapé normal
        this.updateSubTerritoryFooter(this.currentSubTerritory.id, false);

        // Recarregar árvore
        await this.loadRegionsTree();
        
        // ATUALIZAR POLÍGONOS NA TELA
        console.log('🔄 Atualizando polígonos de fundo na tela...');
        await this.map.loadBackgroundTerritories();

        // Recarregar carteira para ver resultado
        await this.selectSubTerritory(this.currentSubTerritory);

        // Notificação final
        if (errorCount === 0) {
            this.showNotification(`✅ Carteira ${this.currentSubTerritory.carteira_id} mantida, ${successCount} carteira(s) recortada(s)`, 'success');
        } else {
            this.showNotification(`⚠️ ${successCount} carteira(s) recortada(s), ${errorCount} erro(s)`, 'warning');
        }
    }

    /**
     * Aplica trim usando turf.difference
     */
    async _applySubTerritoryTrim(geometry, overlappingSubTerritories, parentTerritoryGeometry = null) {
        try {
            console.log('✂️ Aplicando trim em carteira...');
            
            // Garantir que geometry é GeoJSON puro
            let trimmedGeo = typeof geometry === 'string' 
                ? JSON.parse(geometry) 
                : (geometry.geometry || geometry); // Se for objeto Leaflet, pegar .geometry
            
            console.log('🔍 Geometria inicial:', trimmedGeo);

            // Normalizar entrada de overlappingSubTerritories: garantir cada item tem { geometry: GeoJSON, carteira_id }
            const normalizedOverlaps = (overlappingSubTerritories || []).map(item => {
                if (!item) return null;

                // Se já veio como { geometry: ... }
                if (item.geometry) {
                    const geom = typeof item.geometry === 'string' ? JSON.parse(item.geometry) : item.geometry;
                    return { geometry: (geom.geometry || geom), carteira_id: item.carteira_id || item.id };
                }

                // Se veio direto como GeoJSON
                if (item.type === 'Polygon' || item.type === 'MultiPolygon' || item.type === 'Feature') {
                    // Se for Feature, pegar .geometry
                    if (item.type === 'Feature' && item.geometry) {
                        return { geometry: item.geometry, carteira_id: item.carteira_id || item.id };
                    }
                    return { geometry: item, carteira_id: item.carteira_id || item.id };
                }

                // Fallback: não sabemos o formato
                console.warn('⚠️ overlapping item com formato inesperado, será ignorado:', item);
                return null;
            }).filter(Boolean);

            // Para cada carteira sobreposta normalizada, aplicar difference
            for (const overlapping of normalizedOverlaps) {
                const carteiraId = overlapping.carteira_id || 'desconhecida';
                const overlappingGeo = overlapping.geometry;

                if (!overlappingGeo) {
                    console.warn('⚠️ Geometria sobreposta inexistente para:', carteiraId);
                    continue;
                }

                console.log('✂️ Aplicando difference com:', carteiraId);
                console.log('🔍 Geometria sobreposta:', overlappingGeo);

                // Extrair geometries puras (não Features)
                const trimmedGeometry = trimmedGeo.type === 'Feature' ? trimmedGeo.geometry : trimmedGeo;
                const overlappingGeometry = overlappingGeo.type === 'Feature' ? overlappingGeo.geometry : overlappingGeo;

                // Usar turf.difference para remover sobreposição
                const result = turf.difference(
                    turf.feature(trimmedGeometry),
                    turf.feature(overlappingGeometry)
                );

                if (!result) {
                    console.warn('⚠️ Difference resultou em null para:', carteiraId);
                    console.warn('   Isso pode significar que não há interseção real');
                    continue;
                }

                trimmedGeo = result.geometry;
                console.log(`✅ Trim aplicado para ${carteiraId}`);
            }

            // ========================================
            // FILTRAR FRAGMENTOS FORA DO TERRITÓRIO PAI
            // ========================================
            if (parentTerritoryGeometry && trimmedGeo.type === 'MultiPolygon') {
                console.log('🔍 MultiPolygon detectado, filtrando fragmentos dentro do território pai...');
                
                const parentGeo = typeof parentTerritoryGeometry === 'string' 
                    ? JSON.parse(parentTerritoryGeometry) 
                    : (parentTerritoryGeometry.geometry || parentTerritoryGeometry);

                // Extrair geometry pura do parent
                const parentGeometry = parentGeo.type === 'Feature' ? parentGeo.geometry : parentGeo;

                const validPolygons = [];
                
                // Iterar cada polígono do MultiPolygon
                for (const polygonCoords of trimmedGeo.coordinates) {
                    const singlePolygon = {
                        type: 'Polygon',
                        coordinates: polygonCoords
                    };

                    // Verificar se está DENTRO do território pai
                    try {
                        const isWithin = turf.booleanWithin(
                            turf.feature(singlePolygon),
                            turf.feature(parentGeometry)
                        );

                        if (isWithin) {
                            console.log('✅ Fragmento válido (dentro do território pai)');
                            validPolygons.push(polygonCoords);
                        } else {
                            console.warn('❌ Fragmento DESCARTADO (fora do território pai)');
                        }
                    } catch (validationError) {
                        console.warn('⚠️ Erro ao validar fragmento:', validationError.message);
                    }
                }

                // Se não sobrou nenhum fragmento válido, retornar null
                if (validPolygons.length === 0) {
                    console.error('❌ Nenhum fragmento válido após filtrar MultiPolygon!');
                    return null;
                }

                // Se sobrou apenas 1 fragmento, converter para Polygon simples
                if (validPolygons.length === 1) {
                    console.log('✅ Apenas 1 fragmento válido, convertendo para Polygon');
                    trimmedGeo = {
                        type: 'Polygon',
                        coordinates: validPolygons[0]
                    };
                } else {
                    console.log(`✅ ${validPolygons.length} fragmentos válidos mantidos no MultiPolygon`);
                    trimmedGeo = {
                        type: 'MultiPolygon',
                        coordinates: validPolygons
                    };
                }
            }

            // Retornar como GeoJSON completo
            return {
                type: 'Feature',
                geometry: trimmedGeo,
                properties: {}
            };

        } catch (error) {
            console.error('❌ Erro ao aplicar trim:', error);
            console.error('Stack:', error.stack);
            return null;
        }
    }

    /**
     * Cancelar edição da carteira
     */
    async handleCancelSubTerritoryEdit() {
        if (!this.currentSubTerritory) {
            this.showNotification('⚠️ Nenhuma carteira em edição', 'warning');
            return;
        }

        if (confirm('Cancelar edição? As alterações não salvas serão perdidas.')) {
            // Desabilitar edição
            if (this.currentPolygon) {
                this.map.disablePolygonEdit(this.currentPolygon);
            }

            // Recarregar carteira original
            await this.selectSubTerritory(this.currentSubTerritory);

            // Restaurar rodapé normal
            this.updateSubTerritoryFooter(this.currentSubTerritory.id, false);

            this.showNotification('↩️ Edição cancelada', 'info');
        }
    }

    /**
     * Cancelar edição do polígono
     */
    handleCancelEdit() {
        if (!this.currentPolygon) {
            this.showNotification('⚠️ Nenhum polígono em edição', 'warning');
            return;
        }

        if (confirm('Cancelar edição? As alterações não salvas serão perdidas.')) {
            // Desabilitar edição
            this.map.disablePolygonEdit(this.currentPolygon);

            // Esconder barra de ferramentas
            const editToolbar = document.getElementById('editToolbar');
            if (editToolbar) {
                editToolbar.style.display = 'none';
            }

            // Recarregar polígono original
            if (this.currentTerritory) {
                this.loadTerritoryOnMap(this.currentTerritory.id);
            } else if (this.currentSubTerritory) {
                this.selectSubTerritory(this.currentSubTerritory);
            }

            this.showNotification('↩️ Edição cancelada', 'info');
        }
    }

    /**
     * Deletar polígono
     */
    async handleDeletePolygon() {
        if (!this.currentTerritory) {
            this.showNotification('⚠️ Selecione um território na árvore para deletar', 'warning');
            return;
        }
        
        const territoryName = this.currentTerritory.territory_id || 'este território';
        
        if (confirm(`❌ Tem certeza que deseja deletar ${territoryName}?\n\n⚠️ Esta ação não pode ser desfeita!`)) {
            try {
                await this.dataManager.deleteTerritory(this.currentTerritory.id);
                
                // Limpar mapa
                this.map.clearLayer('polygons');
                this.map.clearLayer('drawings');
                
                // Limpar contexto
                this.currentTerritory = null;
                this.currentCenterKey = null;
                this.selectedPolygon = null;
                
                // Recarregar árvore
                await this.loadRegionsTree();
                
                // Atualizar polígonos de fundo
                console.log('🔄 Atualizando polígonos de fundo após deletar...');
                await this.map.loadBackgroundTerritories();
                
                this.showNotification(`✅ Território ${territoryName} deletado com sucesso`, 'success');
            } catch (error) {
                console.error('Erro ao deletar território:', error);
                this.showNotification('❌ Erro ao deletar território', 'error');
            }
        }
    }

    /**
     * Suavizar polígono
     */
    async handleSmoothPolygon() {
        try {
            console.log('🎨 Iniciando suavização...');
            
            // Usar selectedPolygon (mais recente) ou currentPolygon (fallback)
            const polygon = this.selectedPolygon || this.map.currentPolygon;
            
            console.log('Polígono selecionado:', polygon);
            
            if (!polygon) {
                console.warn('⚠️ Nenhum polígono selecionado');
                this.showNotification('⚠️ Selecione um polígono primeiro', 'warning');
                return;
            }

            const btn = document.getElementById('btnSmoothPolygon');
            if (!btn) {
                console.error('❌ Botão de suavização não encontrado');
                return;
            }
            
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="bi bi-hourglass-split"></i><span>Suavizando...</span>';
            
            this.showNotification('⏳ Suavizando polígono...', 'info');

            // Armazenar dados originais
            const originalArea = L.GeometryUtil.geodesicArea(polygon.getLatLngs()[0]) / 10000;
            const originalVertices = polygon.getLatLngs()[0].length;
            const originalCoords = polygon.getLatLngs()[0].map(latlng => [latlng.lat, latlng.lng]);

            const geojson = polygon.toGeoJSON();
            
            // Usar técnica de Morphological Closing (buffer +/-)
            console.log('🎨 Aplicando morphological closing...');
            const bufferDistance = 0.00005; // ~5 metros
            
            // Buffer positivo (expande e preenche pequenas entradas)
            let smoothed = turf.buffer(geojson, bufferDistance, { units: 'degrees' });
            
            if (smoothed) {
                // Buffer negativo (retrai para tamanho original)
                smoothed = turf.buffer(smoothed, -bufferDistance, { units: 'degrees' });
                
                if (smoothed) {
                    // Simplificar para reduzir vértices
                    smoothed = turf.simplify(smoothed, { 
                        tolerance: 0.00001, // ~1 metro
                        highQuality: true 
                    });
                }
            }

            if (!smoothed) {
                throw new Error('Falha na suavização');
            }

            // Atualizar coordenadas do polígono existente (preserva propriedades)
            const newCoords = smoothed.geometry.coordinates[0].map(coord => [coord[1], coord[0]]);
            polygon.setLatLngs(newCoords);
            polygon.redraw();
            
            // Calcular estatísticas do resultado
            const smoothedArea = L.GeometryUtil.geodesicArea(polygon.getLatLngs()[0]) / 10000;
            const smoothedVertices = polygon.getLatLngs()[0].length;
            const areaChange = smoothedArea - originalArea;
            const areaPercent = ((areaChange / originalArea) * 100).toFixed(2);
            const verticesReduction = originalVertices - smoothedVertices;

            // Armazenar dados para possível cancelamento
            this.smoothOriginalCoords = originalCoords;
            
            // Preencher modal com estatísticas
            console.log('📊 Preenchendo estatísticas do modal...');
            document.getElementById('smoothBeforeArea').textContent = originalArea.toFixed(2);
            document.getElementById('smoothBeforeVertices').textContent = originalVertices;
            document.getElementById('smoothAfterArea').textContent = smoothedArea.toFixed(2);
            document.getElementById('smoothAfterVertices').textContent = smoothedVertices;
            document.getElementById('smoothAreaChange').textContent = areaChange.toFixed(2);
            document.getElementById('smoothAreaPercent').textContent = areaPercent;
            document.getElementById('smoothVerticesReduction').textContent = verticesReduction;

            // Mostrar modal de confirmação
            console.log('🎯 Abrindo modal de confirmação...');
            const modalElement = document.getElementById('modalSmoothConfirmation');
            console.log('Modal element:', modalElement);
            
            if (!modalElement) {
                console.error('❌ Modal não encontrado!');
                throw new Error('Modal de suavização não encontrado no DOM');
            }
            
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
            console.log('✅ Modal exibido');

            // Resetar botão
            btn.disabled = false;
            btn.innerHTML = originalHTML;

            console.log('✅ Suavização concluída - aguardando confirmação');

        } catch (error) {
            console.error('❌ Erro ao suavizar polígono:', error);
            console.error('Stack trace:', error.stack);
            this.showNotification('❌ Erro ao suavizar polígono: ' + error.message, 'error');
            
            const btn = document.getElementById('btnSmoothPolygon');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-bezier2"></i><span>Suavizar</span>';
            }
        }
    }

    /**
     * Unir polígonos
     */
    async handleMergePolygons() {
        try {
            const layers = this.map.layers.drawings.getLayers();
            
            if (layers.length < 2) {
                this.showNotification('⚠️ Selecione ao menos 2 polígonos', 'warning');
                return;
            }

            this.showNotification('⏳ Unindo polígonos...', 'info');

            const polygons = layers.map(layer => layer.toGeoJSON());
            const merged = this.polygonTools.mergePolygons(polygons);

            // Limpar camada e adicionar resultado
            this.map.clearLayer('drawings');
            const newLayer = this.polygonTools.toLeafletLayer(merged);
            newLayer.addTo(this.map.layers.drawings);

            this.showNotification('✅ Polígonos unidos com sucesso!', 'success');

        } catch (error) {
            console.error(error);
            this.showNotification('❌ Erro ao unir polígonos', 'error');
        }
    }

    /**
     * Dividir polígono
     */
    handleSplitPolygon() {
        this.showNotification('⚠️ Funcionalidade em desenvolvimento', 'warning');
        // TODO: Implementar UI para desenhar linha de divisão
    }

    /**
     * Buffer (expandir/contrair)
     */
    async handleBufferPolygon() {
        try {
            if (!this.map.currentPolygon) {
                this.showNotification('⚠️ Selecione um polígono primeiro', 'warning');
                return;
            }

            const distance = prompt('Digite a distância do buffer em metros (negativo para contrair):', '10');
            if (!distance) return;

            this.showNotification('⏳ Aplicando buffer...', 'info');

            const geojson = this.map.currentPolygon.toGeoJSON();
            const buffered = this.polygonTools.bufferPolygon(geojson, parseFloat(distance));

            // Remover polígono antigo e adicionar com buffer
            this.map.layers.drawings.removeLayer(this.map.currentPolygon);
            const newLayer = this.polygonTools.toLeafletLayer(buffered);
            newLayer.addTo(this.map.layers.drawings);
            this.map.currentPolygon = newLayer.getLayers()[0];

            this.showNotification('✅ Buffer aplicado com sucesso!', 'success');

        } catch (error) {
            console.error(error);
            this.showNotification('❌ Erro ao aplicar buffer', 'error');
        }
    }

    /**
     * Carregar CAR para o polígono selecionado (com detecção automática de estado)
     */
    async handleLoadCAR() {
        try {
            const btn = document.getElementById('btnLoadCAR');
            
            // Verificar se há um polígono selecionado
            if (!this.selectedPolygon) {
                this.showNotification('⚠️ Selecione um polígono primeiro', 'warning');
                return;
            }
            
            // Se CAR já está ativo, desativar
            if (this.carIntegration.isActive) {
                this.carIntegration.clearCAR();
                btn.classList.remove('active');
                btn.innerHTML = '<i class="bi bi-cloud-download" aria-hidden="true"></i><span>Carregar CAR</span>';
                this.showNotification('CAR desativado', 'info');
                return;
            }

            // Mostrar loading
            btn.disabled = true;
            btn.innerHTML = '<i class="bi bi-hourglass-split" aria-hidden="true"></i><span>Carregando...</span>';
            this.showNotification('⏳ Detectando estado e carregando polígonos CAR...', 'info');

            // Carregar CAR para o polígono selecionado (estado será detectado automaticamente)
            const features = await this.carIntegration.loadCARForSelectedPolygon(
                this.selectedPolygon,
                null, // null = detecção automática
                this.map.map
            );
            
            if (features && features.length > 0) {
                btn.classList.add('active');
                btn.innerHTML = '<i class="bi bi-check-circle" aria-hidden="true"></i><span>CAR Ativo</span>';
            } else {
                btn.innerHTML = '<i class="bi bi-cloud-download" aria-hidden="true"></i><span>Carregar CAR</span>';
            }

            btn.disabled = false;

        } catch (error) {
            console.error('Erro ao carregar CAR:', error);
            this.showNotification('❌ Erro ao carregar CAR', 'error');
            
            // Resetar botão
            const btn = document.getElementById('btnLoadCAR');
            btn.disabled = false;
            btn.classList.remove('active');
            btn.innerHTML = '<i class="bi bi-cloud-download" aria-hidden="true"></i><span>Carregar CAR</span>';
        }
    }

    /**
     * Ajusta o polígono às divisas dos CARs
     */
    async handleAdjustToCAR() {
        try {
            const btn = document.getElementById('btnAdjustToCAR');
            
            // Verificar se há um polígono selecionado
            if (!this.selectedPolygon) {
                this.showNotification('⚠️ Selecione um polígono primeiro', 'warning');
                return;
            }

            // Verificar se CAR está carregado
            if (!this.carIntegration.isActive || !this.carIntegration.carFeatures || 
                this.carIntegration.carFeatures.length === 0) {
                this.showNotification('⚠️ Carregue os polígonos CAR primeiro', 'warning');
                return;
            }

            // Mostrar loading
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="bi bi-hourglass-split" aria-hidden="true"></i><span>Ajustando...</span>';
            this.showNotification('⏳ Ajustando polígono às divisas do CAR...', 'info');

            // Chamar função de ajuste
            const adjustedPolygon = await this.carIntegration.adjustPolygonToCAR(
                this.selectedPolygon,
                this.carIntegration.carFeatures
            );

            if (adjustedPolygon) {
                // Armazenar dados originais para o modal
                const originalArea = (L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000);
                const originalVertices = this.selectedPolygon.getLatLngs()[0].length;
                
                // Obter novas coordenadas do polígono ajustado
                const newCoordinates = adjustedPolygon.geometry.coordinates;
                
                // Atualizar coordenadas do polígono existente (mantém propriedades)
                this.selectedPolygon.setLatLngs(
                    newCoordinates[0].map(coord => [coord[1], coord[0]]) // Inverter lng,lat para lat,lng
                );
                
                // Redesenhar o polígono
                this.selectedPolygon.redraw();
                
                // Centralizar no polígono atualizado
                this.map.map.fitBounds(this.selectedPolygon.getBounds(), {
                    padding: [50, 50]
                });

                // Calcular estatísticas
                const adjustedArea = (L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000);
                const adjustedVertices = this.selectedPolygon.getLatLngs()[0].length;
                const areaIncrease = adjustedArea - originalArea;
                const areaPercent = ((areaIncrease / originalArea) * 100);
                const verticesIncrease = adjustedVertices - originalVertices;
                
                // Obter estatísticas dos CARs (do console.log)
                const carsProcessed = this.carIntegration.lastAdjustStats?.processed || 0;
                const carsTotal = this.carIntegration.lastAdjustStats?.total || 0;
                const successRate = carsTotal > 0 ? ((carsProcessed / carsTotal) * 100) : 0;

                // Atualizar área exibida no card
                const territoryCard = document.querySelector('.territory-selected .area-display');
                if (territoryCard) {
                    territoryCard.textContent = `${adjustedArea.toFixed(2)} ha`;
                }

                // Atualizar área no center-item (visual instantâneo)
                if (this.selectedPolygon.centerKey) {
                    this.updateCenterItemArea(this.selectedPolygon.centerKey, adjustedArea);
                }

                // Preencher modal de confirmação
                document.getElementById('carBeforeArea').textContent = `${originalArea.toFixed(2)} ha`;
                document.getElementById('carBeforeVertices').textContent = originalVertices;
                document.getElementById('carAfterArea').textContent = `${adjustedArea.toFixed(2)} ha`;
                document.getElementById('carAfterVertices').textContent = adjustedVertices;
                document.getElementById('carAreaIncrease').textContent = `+${areaIncrease.toFixed(2)}`;
                document.getElementById('carAreaPercent').textContent = `+${areaPercent.toFixed(2)}`;
                document.getElementById('carVerticesIncrease').textContent = `+${verticesIncrease}`;
                document.getElementById('carProcessedCount').textContent = carsProcessed;
                document.getElementById('carTotalCount').textContent = carsTotal;
                document.getElementById('carSuccessRate').textContent = successRate.toFixed(1);

                // Mostrar modal de confirmação
                const modal = new bootstrap.Modal(document.getElementById('modalCARConfirmation'));
                modal.show();

                this.showNotification('✅ Polígono expandido até as divisas do CAR', 'success');
            } else {
                this.showNotification('⚠️ Não foi possível ajustar o polígono', 'warning');
            }

            // Resetar botão
            btn.disabled = false;
            btn.innerHTML = originalHTML;

        } catch (error) {
            console.error('Erro ao ajustar polígono ao CAR:', error);
            this.showNotification('❌ Erro ao ajustar polígono', 'error');
            
            // Resetar botão
            const btn = document.getElementById('btnAdjustToCAR');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-border-outer" aria-hidden="true"></i><span>Ajustar ao CAR</span>';
        }
    }

    /**
     * Salva o polígono ajustado ao CAR no Supabase
     */
    async handleSaveCARToSupabase() {
        try {
            const btn = document.getElementById('btnSaveCARToSupabase');
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Salvando...';

            if (!this.selectedPolygon) {
                this.showNotification('⚠️ Nenhum polígono selecionado', 'warning');
                return;
            }

            // Obter GeoJSON do polígono
            const geojson = this.selectedPolygon.toGeoJSON();
            
            // Obter center_key do polígono (múltiplas fontes)
            let centerKey = null;
            
            // Tentar obter de várias formas
            if (this.selectedPolygon.centerKey) {
                centerKey = this.selectedPolygon.centerKey;
                console.log('✓ center_key obtido do polígono:', centerKey);
            } else if (this.selectedPolygon.territoryData?.center_key) {
                centerKey = this.selectedPolygon.territoryData.center_key;
                console.log('✓ center_key obtido do territoryData:', centerKey);
            } else if (this.selectedCenter?.key) {
                centerKey = this.selectedCenter.key;
                console.log('✓ center_key obtido do selectedCenter:', centerKey);
            } else {
                // Tentar obter do card do território selecionado
                const selectedCard = document.querySelector('.center-item.selected');
                if (selectedCard && selectedCard.dataset.centerKey) {
                    centerKey = selectedCard.dataset.centerKey;
                    console.log('✓ center_key obtido do card selecionado:', centerKey);
                }
            }
            
            if (!centerKey) {
                console.error('❌ Não foi possível identificar o centro do território');
                console.log('Debug info:', {
                    selectedPolygon: this.selectedPolygon,
                    centerKey: this.selectedPolygon?.centerKey,
                    territoryData: this.selectedPolygon?.territoryData,
                    selectedCenter: this.selectedCenter
                });
                this.showNotification('⚠️ Centro não identificado. Por favor, selecione o centro novamente.', 'warning');
                btn.disabled = false;
                btn.innerHTML = originalHTML;
                return;
            }

            console.log('💾 Salvando território ajustado no Supabase...');

            // Verificar se já existe um território para este centro
            const { data: existingTerritories, error: selectError } = await this.dataManager.supabase
                .from(CONFIG.database.tables.territories)
                .select('*')
                .eq('center_key', centerKey)
                .limit(1);

            if (selectError) {
                throw new Error(`Erro ao verificar território existente: ${selectError.message}`);
            }

            let result;

            if (existingTerritories && existingTerritories.length > 0) {
                // ATUALIZAR território existente
                const territoryId = existingTerritories[0].id;
                console.log(`📝 Atualizando território existente (ID: ${territoryId})...`);

                const { data, error } = await this.dataManager.supabase
                    .from(CONFIG.database.tables.territories)
                    .update({
                        geometry: geojson.geometry,
                        updated_at: new Date().toISOString()
                    })
                    .eq('id', territoryId)
                    .select();

                if (error) throw error;
                result = data;
                
                console.log('✅ Território atualizado com sucesso');
                this.showNotification('✅ Território atualizado no Supabase', 'success');

            } else {
                // CRIAR novo território
                console.log(`➕ Criando novo território para centro ${centerKey}...`);

                const { data, error } = await this.dataManager.supabase
                    .from(CONFIG.database.tables.territories)
                    .insert({
                        center_key: centerKey,
                        geometry: geojson.geometry,
                        created_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    })
                    .select();

                if (error) throw error;
                result = data;
                
                console.log('✅ Território criado com sucesso');
                this.showNotification('✅ Território salvo no Supabase', 'success');
            }

            // Calcular e atualizar área no center-item
            const areaHectares = L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000;
            this.updateCenterItemArea(centerKey, areaHectares);

            // Fechar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('modalCARConfirmation'));
            if (modal) {
                modal.hide();
            }

            // Resetar botão
            btn.disabled = false;
            btn.innerHTML = originalHTML;

            // Recarregar território do banco para garantir sincronização
            console.log('🔄 Recarregando território do banco...');
            await this.reloadTerritoryFromDatabase(centerKey);

        } catch (error) {
            console.error('❌ Erro ao salvar no Supabase:', error);
            this.showNotification('❌ Erro ao salvar no Supabase: ' + error.message, 'error');
            
            // Resetar botão
            const btn = document.getElementById('btnSaveCARToSupabase');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-save me-1"></i>Salvar';
            }
        }
    }

    /**
     * Salva polígono suavizado no Supabase
     */
    async handleSaveSmoothToSupabase() {
        try {
            const btn = document.getElementById('btnSaveSmoothToSupabase');
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Salvando...';

            if (!this.selectedPolygon) {
                this.showNotification('⚠️ Nenhum polígono selecionado', 'warning');
                return;
            }

            // Obter GeoJSON do polígono suavizado
            const geojson = this.selectedPolygon.toGeoJSON();
            
            // Obter center_key
            let centerKey = null;
            
            if (this.selectedPolygon.centerKey) {
                centerKey = this.selectedPolygon.centerKey;
            } else if (this.selectedPolygon.territoryData?.center_key) {
                centerKey = this.selectedPolygon.territoryData.center_key;
            } else if (this.selectedCenter?.key) {
                centerKey = this.selectedCenter.key;
            } else {
                const selectedCard = document.querySelector('.center-item.selected');
                if (selectedCard?.dataset.centerKey) {
                    centerKey = selectedCard.dataset.centerKey;
                }
            }
            
            if (!centerKey) {
                this.showNotification('⚠️ Centro não identificado.', 'warning');
                btn.disabled = false;
                btn.innerHTML = originalHTML;
                return;
            }

            console.log('💾 Salvando território suavizado no Supabase...');

            // Verificar se já existe um território para este centro
            const { data: existingTerritories, error: selectError } = await this.dataManager.supabase
                .from(CONFIG.database.tables.territories)
                .select('*')
                .eq('center_key', centerKey)
                .limit(1);

            if (selectError) {
                throw new Error(`Erro ao verificar território existente: ${selectError.message}`);
            }

            if (existingTerritories && existingTerritories.length > 0) {
                // ATUALIZAR território existente
                const territoryId = existingTerritories[0].id;
                console.log(`📝 Atualizando território com suavização (ID: ${territoryId})...`);

                const { data, error } = await this.dataManager.supabase
                    .from(CONFIG.database.tables.territories)
                    .update({
                        geometry: geojson.geometry,
                        updated_at: new Date().toISOString()
                    })
                    .eq('id', territoryId)
                    .select();

                if (error) throw error;
                
                console.log('✅ Território suavizado atualizado com sucesso');
                this.showNotification('✅ Território suavizado salvo no Supabase', 'success');
            } else {
                // CRIAR novo território
                console.log(`➕ Criando novo território suavizado para centro ${centerKey}...`);

                const { data, error } = await this.dataManager.supabase
                    .from(CONFIG.database.tables.territories)
                    .insert({
                        center_key: centerKey,
                        geometry: geojson.geometry,
                        created_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    })
                    .select();

                if (error) throw error;
                
                console.log('✅ Território suavizado criado com sucesso');
                this.showNotification('✅ Território suavizado salvo no Supabase', 'success');
            }

            // Atualizar área no center-item
            const areaHectares = L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000;
            this.updateCenterItemArea(centerKey, areaHectares);

            // Limpar dados de cancelamento
            this.smoothOriginalCoords = null;

            // Fechar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('modalSmoothConfirmation'));
            if (modal) {
                modal.hide();
            }

            // Resetar botão
            btn.disabled = false;
            btn.innerHTML = originalHTML;

            // Recarregar território do banco para garantir que está atualizado
            console.log('🔄 Recarregando território do banco...');
            await this.reloadTerritoryFromDatabase(centerKey);

        } catch (error) {
            console.error('❌ Erro ao salvar suavização no Supabase:', error);
            this.showNotification('❌ Erro ao salvar: ' + error.message, 'error');
            
            const btn = document.getElementById('btnSaveSmoothToSupabase');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-save me-1"></i>Salvar';
            }
        }
    }

    /**
     * Cancela a suavização e restaura o polígono original
     */
    handleCancelSmooth() {
        try {
            if (this.smoothOriginalCoords && this.selectedPolygon) {
                // Restaurar coordenadas originais
                this.selectedPolygon.setLatLngs(this.smoothOriginalCoords);
                this.selectedPolygon.redraw();
                
                // Atualizar área
                if (this.selectedPolygon.centerKey) {
                    const areaHectares = L.GeometryUtil.geodesicArea(this.selectedPolygon.getLatLngs()[0]) / 10000;
                    this.updateCenterItemArea(this.selectedPolygon.centerKey, areaHectares);
                }
                
                // Limpar dados
                this.smoothOriginalCoords = null;
                
                console.log('↩️ Suavização cancelada - polígono restaurado');
                this.showNotification('↩️ Suavização cancelada', 'info');
            }
            
            // Fechar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('modalSmoothConfirmation'));
            if (modal) {
                modal.hide();
            }
            
        } catch (error) {
            console.error('❌ Erro ao cancelar suavização:', error);
            this.showNotification('❌ Erro ao cancelar', 'error');
        }
    }

    // ==================== PROPERTY MANAGEMENT ====================

    /**
     * Mostra modal de nova propriedade
     */
    showNewPropertyModal() {
        const modal = new bootstrap.Modal(document.getElementById('modalNewProperty'));
        modal.show();
    }

    /**
     * Salva nova propriedade
     */
    async handleSaveProperty() {
        try {
            const name = document.getElementById('propertyName').value;
            const ownerName = document.getElementById('ownerName').value;
            const ownerBPID = document.getElementById('ownerBPID').value;
            const region = document.getElementById('propertyRegion').value;

            if (!name || !ownerName || !ownerBPID) {
                this.showNotification('⚠️ Preencha todos os campos obrigatórios', 'warning');
                return;
            }

            this.showNotification('⏳ Criando propriedade...', 'info');

            const property = await this.dataManager.createProperty({
                name: name,
                owner_name: ownerName,
                owner_bpid: ownerBPID,
                region: region
            });

            // Fechar modal
            bootstrap.Modal.getInstance(document.getElementById('modalNewProperty')).hide();

            // Limpar formulário
            document.getElementById('formProperty').reset();

            // Atualizar árvore
            this.loadRegionsTree();

            this.showNotification('✅ Propriedade criada com sucesso!', 'success');

        } catch (error) {
            console.error(error);
            this.showNotification('❌ Erro ao criar propriedade: ' + error.message, 'error');
        }
    }

    /**
     * Carrega árvore de propriedades
     */
    // ==================== REGIONS TREE ====================

    /**
     * Carrega a árvore de regiões e centros
     */
    async loadRegionsTree() {
        try {
            const regions = window.RegionCenterUtils.getAllRegions();
            const treeContainer = document.getElementById('regionTree');

            if (regions.length === 0) {
                treeContainer.innerHTML = `
                    <div class="empty-state">
                        <i class="bi bi-inbox fs-1 text-muted mb-3" aria-hidden="true"></i>
                        <p class="text-muted mb-0">Nenhuma região encontrada</p>
                    </div>
                `;
                return;
            }

            // Buscar territórios existentes
            const territories = await this.dataManager.listTerritories();

            // Carregar territórios em segundo plano no mapa (visualização esmaecida)
            await this.map.loadBackgroundTerritories();

            // Construir HTML da árvore
            let html = '';
            
            for (const region of regions) {
                const centers = window.RegionCenterUtils.getCentersByRegion(region);
                
                html += `
                    <div class="region-item collapsed" data-region-id="${region}">
                        <div class="region-header" role="button" tabindex="0">
                            <i class="bi bi-chevron-right region-toggle" aria-hidden="true"></i>
                            <i class="bi bi-geo-alt-fill me-2 text-primary" aria-hidden="true"></i>
                            <span class="region-name">${region}</span>
                            <span class="badge bg-secondary ms-2">${centers.length}</span>
                        </div>
                        <div class="region-content">
                            <div class="center-list">
                `;
                
                for (const center of centers) {
                    // Buscar território deste centro (só pode existir um)
                    const territory = territories.find(t => t.center_key === center.centroChave);
                    
                    const hasTerritory = !!territory;
                    const iconClass = hasTerritory ? 'bi-pin-map-fill' : 'bi-building';
                    const title = hasTerritory ? 'Clique para carregar território' : 'Clique para criar território';
                    
                    html += `
                        <div class="center-item ${hasTerritory ? 'has-territory' : ''}" 
                             data-center="${center.centro}" 
                             data-center-key="${center.centroChave}"
                             data-region="${region}"
                             data-territory-id="${territory ? territory.id : ''}"
                             role="button" 
                             tabindex="0"
                             title="${title}">
                            <div class="center-item-content">
                                <div class="center-item-header">
                                    <i class="bi ${iconClass} tree-item-icon"></i>
                                    <span class="center-item-title">${center.centro}</span>
                                    ${hasTerritory ? '<i class="bi bi-check-circle-fill ms-auto" style="opacity: 1; color: #3b82f6;"></i>' : ''}
                                </div>
                                <div class="center-item-details">
                                    <span class="center-item-code">${center.centroChave}</span>`;
                    
                    // Se houver território, mostrar área
                    if (territory && territory.area_hectares) {
                        html += `<span class="center-item-area"><i class="bi bi-bounding-box"></i> ${territory.area_hectares.toFixed(2)} ha</span>`;
                    }
                    
                    html += `
                                </div>
                            </div>`;
                    
                    // Se houver território, adicionar botões de ação
                    if (hasTerritory && territory) {
                        html += `
                            <div class="territory-actions">
                                <button class="btn-edit-territory"
                                        data-territory-id="${territory.id}"
                                        data-territory-key="${center.centroChave}"
                                        title="Editar Território">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn-eraser-territory"
                                        data-territory-id="${territory.id}"
                                        data-territory-key="${center.centroChave}"
                                        title="Apagar Vértices do Território">
                                    <i class="bi bi-eraser"></i>
                                </button>
                                <button class="btn-history-territory"
                                        data-territory-id="${territory.id}"
                                        data-territory-key="${center.centroChave}"
                                        data-territory-name="${territory.name || center.centroChave}"
                                        title="Histórico de Versões">
                                    <i class="bi bi-clock-history"></i>
                                </button>
                                <button class="btn-delete-territory"
                                        data-territory-id="${territory.id}"
                                        data-territory-key="${center.centroChave}"
                                        title="Excluir Território">
                                    <i class="bi bi-trash"></i>
                                </button>
                                <button class="btn-add-sub-territory"
                                        data-territory-id="${territory.id}"
                                        data-territory-key="${center.centroChave}"
                                        title="Adicionar Carteira">
                                    <i class="bi bi-plus-circle"></i>
                                </button>
                            </div>`;
                        
                        // NOVO: Renderizar carteiras existentes
                        const subTerritories = await this.dataManager.listSubTerritories(territory.id);
                        
                        if (subTerritories && subTerritories.length > 0) {
                            html += `<div class="sub-territories-container">`;
                            
                            for (const subT of subTerritories) {
                                html += `
                                    <div class="sub-territory-item" 
                                         data-sub-territory-id="${subT.id}"
                                         data-territory-id="${territory.id}"
                                         data-carteira-id="${subT.carteira_id}">
                                        <div class="sub-territory-item-body">
                                            <div class="sub-territory-item-header">
                                                <i class="bi bi-diagram-3 tree-item-icon text-warning"></i>
                                                <span class="sub-territory-item-title">${subT.name || subT.carteira_id}</span>
                                            </div>
                                            <div class="sub-territory-item-details">
                                                <small class="sub-territory-item-code">${subT.carteira_id}</small>
                                                ${subT.area_hectares ? `<small class="sub-territory-item-area">${subT.area_hectares.toFixed(2)} ha</small>` : ''}
                                            </div>
                                        </div>
                                        <div class="sub-territory-item-footer">
                                            <button class="btn-footer-action btn-edit"
                                                    data-sub-territory-id="${subT.id}"
                                                    data-territory-id="${territory.id}"
                                                    data-carteira-id="${subT.carteira_id}"
                                                    title="Editar Carteira">
                                                <i class="bi bi-pencil"></i>
                                                <span>Editar</span>
                                            </button>
                                            <button class="btn-footer-action btn-eraser"
                                                    data-sub-territory-id="${subT.id}"
                                                    data-territory-id="${territory.id}"
                                                    data-carteira-id="${subT.carteira_id}"
                                                    title="Apagar Vértices">
                                                <i class="bi bi-eraser"></i>
                                                <span>Apagar</span>
                                            </button>
                                            <button class="btn-footer-action btn-history"
                                                    data-sub-territory-id="${subT.id}"
                                                    data-territory-id="${territory.id}"
                                                    data-carteira-id="${subT.carteira_id}"
                                                    data-carteira-name="${subT.name || subT.carteira_id}"
                                                    title="Histórico de Versões">
                                                <i class="bi bi-clock-history"></i>
                                                <span>Histórico</span>
                                            </button>
                                            <button class="btn-footer-action btn-delete"
                                                    data-sub-territory-id="${subT.id}"
                                                    data-territory-id="${territory.id}"
                                                    data-carteira-id="${subT.carteira_id}"
                                                    title="Excluir Carteira">
                                                <i class="bi bi-trash"></i>
                                                <span>Excluir</span>
                                            </button>
                                        </div>
                                    </div>`;
                            }
                            
                            html += `</div>`;
                        }
                    }
                    
                    html += `</div>`;
                }
                
                html += `
                            </div>
                        </div>
                    </div>
                `;
            }

            treeContainer.innerHTML = html;

            // Adicionar event listeners
            this.setupRegionEventListeners();
            
            // NOVO: Expandir automaticamente região e centro ativos
            this.expandActiveContext();

        } catch (error) {
            console.error('Erro ao carregar árvore de regiões:', error);
            document.getElementById('regionTree').innerHTML = `
                <div class="alert alert-danger m-2">
                    <small>❌ Erro ao carregar regiões</small>
                </div>
            `;
        }
    }

    /**
     * Configura event listeners para regiões e centros
     */
    setupRegionEventListeners() {
        // Toggles de região
        document.querySelectorAll('.region-header').forEach(header => {
            header.addEventListener('click', (e) => {
                const regionItem = e.currentTarget.closest('.region-item');
                regionItem.classList.toggle('collapsed');
            });
        });

        // Cliques em centros
        document.querySelectorAll('.center-item').forEach(item => {
            item.addEventListener('click', async (e) => {
                // BLOQUEAR se clicou em QUALQUER botão de ação
                if (e.target.closest('.btn-add-sub-territory') ||
                    e.target.closest('.btn-footer-action') ||
                    e.target.closest('.btn-edit-territory') ||
                    e.target.closest('.btn-delete-territory') ||
                    e.target.closest('.btn-eraser-territory') ||
                    e.target.closest('.btn-history-territory')) {
                    return; // Deixar handlers específicos dos botões lidarem
                }
                
                const centerName = e.currentTarget.dataset.center;
                const centerKey = e.currentTarget.dataset.centerKey;
                const regionName = e.currentTarget.dataset.region;
                const territoryId = e.currentTarget.dataset.territoryId;
                
                // Armazenar região atual para detecção de estado CAR
                if (regionName) {
                    this.currentRegion = regionName;
                    console.log(`📍 Região selecionada: ${regionName}`);
                }
                
                // Armazenar centro atual
                this.currentCenterKey = centerKey;
                console.log(`📍 Centro selecionado: ${centerKey}`);
                
                // Destacar item selecionado
                this.setActiveItem(e.currentTarget);
                
                // CARREGAR ÁREAS ao clicar no centro
                if (centerKey) {
                    try {
                        // Se NÃO tem território, carregar em modo UNIDADE (criação de território)
                        // Se JÁ tem território, será carregado depois em loadTerritoryOnMap
                        if (!territoryId) {
                            console.log('🏢 Carregando áreas por UNIDADE (sem território ainda)...');
                            await this.setViewMode('unidade', centerKey);
                        }
                    } catch (error) {
                        console.error('❌ Erro ao carregar áreas:', error);
                    }
                }
                
                // Se já tem território, carregar no mapa
                if (territoryId) {
                    await this.loadTerritoryOnMap(territoryId);
                } else {
                    // Se não tem, abrir modal para criar
                    await this.showNewTerritoryModal(centerName, centerKey, regionName);
                }
            });
        });

        // Botões de adicionar carteira (delegação de eventos)
        document.addEventListener('click', async (e) => {
            const btn = e.target.closest('.btn-add-sub-territory');
            if (!btn) return;
            
            // 🔒 PREVENIR EXECUÇÃO DUPLICADA
            if (btn.dataset.processing === 'true') {
                console.log('⏭️ Já processando clique, ignorando duplicata');
                return;
            }
            btn.dataset.processing = 'true';
            
            e.stopPropagation(); // Impedir propagação para o center-item
            e.preventDefault();
            
            console.log('🟠 Botão + Carteira clicado');
            
            const territoryId = btn.dataset.territoryId;
            const territoryKey = btn.dataset.territoryKey;
            
            console.log(`   - Territory ID: ${territoryId}`);
            console.log(`   - Territory Key: ${territoryKey}`);
            
            try {
                // Buscar território completo
                const territory = await this.dataManager.getTerritoryWithSubTerritories(territoryId);
                
                if (!territory) {
                    this.showNotification('Território não encontrado', 'error');
                    return;
                }
                
                console.log('✅ Território encontrado:', territory);
                
                // Iniciar desenho de carteira
                await this.drawSubTerritory(territory);
                
            } catch (error) {
                console.error('❌ Erro ao iniciar criação de carteira:', error);
                this.showNotification('Erro ao criar carteira', 'error');
            } finally {
                // 🔓 LIBERAR BOTÃO APÓS PROCESSAMENTO
                setTimeout(() => {
                    btn.dataset.processing = 'false';
                }, 500);
            }
        });
        
        // NOVO: Cliques em carteiras (delegação de eventos para elementos dinâmicos)
        document.addEventListener('click', async (e) => {
            // Verificar se clicou em botão de ação no rodapé
            if (e.target.closest('.btn-footer-action') || e.target.closest('.btn-edit-territory')) {
                return; // Deixar handlers específicos tratarem
            }
            
            const subItem = e.target.closest('.sub-territory-item');
            if (!subItem) return;
            
            e.stopPropagation(); // Impedir propagação para o center-item
            
            const subTerritoryId = subItem.dataset.subTerritoryId;
            const territoryId = subItem.dataset.territoryId;
            const carteiraId = subItem.dataset.carteiraId;
            
            console.log('🟠 Carteira clicada na árvore:', carteiraId);
            
            try {
                // Buscar dados da carteira pelo ID do território pai
                const subTerritories = await this.dataManager.listSubTerritories(territoryId);
                const subTerritory = subTerritories.find(st => st.id === subTerritoryId);
                
                if (subTerritory) {
                    // Destacar item selecionado
                    this.setActiveItem(subItem);
                    
                    // Exibir no mapa (SEM modo de edição)
                    await this.selectSubTerritory(subTerritory);
                } else {
                    console.error('❌ Carteira não encontrada:', subTerritoryId);
                    this.showNotification('Carteira não encontrada', 'error');
                }
            } catch (error) {
                console.error('❌ Erro ao selecionar carteira:', error);
                this.showNotification('Erro ao carregar carteira', 'error');
            }
        });
        
        // NOVO: Botão Editar Território
        document.addEventListener('click', async (e) => {
            const btn = e.target.closest('.btn-edit-territory');
            if (!btn) return;
            
            e.stopPropagation();
            e.preventDefault();
            
            const territoryId = btn.dataset.territoryId;
            console.log('✏️ Editar território clicado:', territoryId);
            
            try {
                // Carregar território no mapa
                await this.loadTerritoryOnMap(territoryId);
                
                // Aguardar um momento para garantir que o polígono foi renderizado
                setTimeout(() => {
                    if (this.currentPolygon) {
                        console.log('🔧 FORÇANDO ativação de edição do território...');
                        
                        // Garantir que está no pane correto (primeiro plano)
                        this.currentPolygon.options.pane = 'drawingsPane';
                        
                        // Mover polígono para camada editável se necessário
                        if (this.map.layers.polygons.hasLayer(this.currentPolygon)) {
                            this.map.layers.polygons.removeLayer(this.currentPolygon);
                            this.map.layers.drawings.addLayer(this.currentPolygon);
                        }
                        
                        // FORÇAR ativação do modo de edição
                        const editEnabled = this.map.enablePolygonEdit(this.currentPolygon);
                        
                        if (editEnabled) {
                            console.log('✅ Modo de edição ativado para território');
                            this.showNotification('✏️ Modo de edição ativado', 'success');
                        } else {
                            this.showNotification('⚠️ Não foi possível ativar edição', 'warning');
                        }
                    } else {
                        console.error('❌ Polígono atual não encontrado');
                        this.showNotification('Erro: Polígono não encontrado', 'error');
                    }
                }, 300);
                
            } catch (error) {
                console.error('❌ Erro ao editar território:', error);
                this.showNotification('Erro ao carregar território para edição', 'error');
            }
        });
        
        // NOVO: Botão Editar Carteira (rodapé do item)
        document.addEventListener('click', async (e) => {
            const btn = e.target.closest('.btn-footer-action.btn-edit');
            if (!btn) return;
            
            e.stopPropagation();
            e.preventDefault();
            
            const subTerritoryId = btn.dataset.subTerritoryId;
            const territoryId = btn.dataset.territoryId;
            const carteiraId = btn.dataset.carteiraId;
            
            console.log('✏️ Editar carteira clicado:', carteiraId);
            
            try {
                // Buscar carteira
                const subTerritories = await this.dataManager.listSubTerritories(territoryId);
                const subTerritory = subTerritories.find(st => st.id === subTerritoryId);
                
                if (!subTerritory) {
                    this.showNotification('Carteira não encontrada', 'error');
                    return;
                }
                
                // Carregar carteira no mapa
                await this.selectSubTerritory(subTerritory);
                
                // Aguardar renderização
                setTimeout(() => {
                    if (this.currentPolygon) {
                        // FORÇAR modo de edição (garantir pane + edição habilitada)
                        console.log('🔧 FORÇANDO ativação de edição da carteira...');
                        
                        // Garantir que está no pane correto (primeiro plano)
                        this.currentPolygon.options.pane = 'drawingsPane';
                        
                        // Ativar modo de edição
                        const editEnabled = this.map.enablePolygonEdit(this.currentPolygon);
                        
                        if (editEnabled) {
                            console.log('✅ Modo de edição ativado para carteira:', carteiraId);
                            this.showNotification(`✏️ Editando ${carteiraId}`, 'success');
                            
                            // Atualizar rodapé para mostrar ferramentas de edição
                            this.updateSubTerritoryFooter(subTerritoryId, true);
                        } else {
                            this.showNotification('⚠️ Não foi possível ativar edição', 'warning');
                        }
                    } else {
                        console.error('❌ Polígono atual não encontrado');
                        this.showNotification('Erro: Polígono não encontrado', 'error');
                    }
                }, 300);
                
            } catch (error) {
                console.error('❌ Erro ao editar carteira:', error);
                this.showNotification('Erro ao carregar carteira para edição', 'error');
            }
        });

        // NOVO: Botão Pincel de Apagar Vértices (usar delegação única)
        // Prevenir múltiplos listeners com flag
        if (!this._eraserCarteirasListenerAdded) {
            this._eraserCarteirasListenerAdded = true;
            
            document.addEventListener('click', async (e) => {
                const btn = e.target.closest('.btn-footer-action.btn-eraser');
                if (!btn) return;
                
                e.stopPropagation();
                e.preventDefault();
                
                const subTerritoryId = btn.dataset.subTerritoryId;
                const territoryId = btn.dataset.territoryId;
                const carteiraId = btn.dataset.carteiraId;
                
                console.log('🎨 Pincel carteira clicado:', carteiraId);
                
                // Se já está ativo, apenas fazer toggle
                if (this.map.eraserState && this.map.eraserState.active) {
                    console.log('🔄 Borracha já ativa, fazendo toggle...');
                    this.map.disableVertexEraser();
                    this.showNotification('🎨 Modo Apagar Vértices desativado', 'info');
                    return;
                }
                
                try {
                    // Buscar carteira
                    const subTerritories = await this.dataManager.listSubTerritories(territoryId);
                    const subTerritory = subTerritories.find(st => st.id === subTerritoryId);
                    
                    if (!subTerritory) {
                        this.showNotification('Carteira não encontrada', 'error');
                        return;
                    }
                    
                    console.log('📦 Carteira encontrada:', subTerritory.carteira_id);
                    console.log('🎯 Contexto: SUB-TERRITÓRIO (Carteira)');
                    
                    // LIMPAR CONTEXTO DO TERRITÓRIO ANTERIOR ANTES DE CARREGAR CARTEIRA
                    this.currentTerritory = null;
                    this.currentPolygon = null;
                    
                    // Carregar APENAS a carteira no mapa (não o território pai)
                    await this.selectSubTerritory(subTerritory);
                    
                    // Aguardar renderização com timeout maior para garantir
                    setTimeout(() => {
                        if (this.currentPolygon) {
                            console.log('🔍 Polígono carregado:', this.currentPolygon);
                            console.log('🔍 Tipo:', this.currentPolygon.subTerritoryData ? 'CARTEIRA ✅' : 'TERRITÓRIO ❌');
                            console.log('🔍 Possui editing.enable?', typeof this.currentPolygon.editing?.enable === 'function');
                            console.log('🔍 Possui enableEdit?', typeof this.currentPolygon.enableEdit === 'function');
                            
                            // Verificar se é realmente a carteira
                            if (this.currentPolygon.subTerritoryData) {
                                console.log('✅ Contexto correto: Carteira', this.currentPolygon.subTerritoryData.carteira_id);
                            } else if (this.currentPolygon.territoryData) {
                                console.error('❌ ERRO: Polígono carregado é do TERRITÓRIO, não da carteira!');
                                this.showNotification('❌ Erro: Contexto incorreto (território ao invés de carteira)', 'error');
                                return;
                            }
                            
                            // FORÇAR ativação da edição SEMPRE (necessário para pincel funcionar)
                            console.log('⚙️ FORÇANDO ativação de edição do polígono da carteira...');
                            
                            try {
                                // Método 1: Leaflet.Draw
                                if (this.currentPolygon.editing) {
                                    if (!this.currentPolygon.editing.enabled()) {
                                        console.log('� Ativando via Leaflet.Draw...');
                                        this.currentPolygon.editing.enable();
                                    }
                                }
                                
                                // Método 2: Leaflet.Editable
                                if (this.currentPolygon.enableEdit && typeof this.currentPolygon.enableEdit === 'function') {
                                    console.log('🔧 Ativando via Leaflet.Editable...');
                                    this.currentPolygon.enableEdit(this.map.map);
                                }
                                
                                // Método 3: Via MapManager (garante pane correto)
                                console.log('🔧 Ativando via MapManager.enablePolygonEdit()...');
                                this.map.enablePolygonEdit(this.currentPolygon);
                                
                                console.log('✅ Edição FORÇADA com sucesso');
                            } catch (editError) {
                                console.error('❌ ERRO ao ativar edição:', editError);
                                console.error('   Stack:', editError.stack);
                                this.showNotification('❌ Erro ao ativar edição da carteira', 'error');
                                return;
                            }
                            
                            // Aguardar um pouco mais para garantir que a edição está ativa
                            setTimeout(() => {
                                console.log('🟡 Prestes a chamar _enableVertexEraserDirect()...');
                                // Ativar pincel de apagar (SEM toggle interno, já verificamos acima)
                                const eraserEnabled = this.map._enableVertexEraserDirect(this.currentPolygon);
                                
                                console.log('🟡 Resultado de _enableVertexEraserDirect():', eraserEnabled);
                                
                                if (eraserEnabled) {
                                    console.log('✅ Pincel ativado para carteira:', carteiraId);
                                    
                                    // AGUARDAR um pouco e verificar se ainda está ativo
                                    setTimeout(() => {
                                        const aindaAtivo = this.map.eraserState && this.map.eraserState.active;
                                        console.log('🔍 Verificação após 500ms - Pincel ainda ativo?', aindaAtivo);
                                        if (!aindaAtivo) {
                                            console.error('⚠️ PINCEL FOI DESATIVADO AUTOMATICAMENTE!');
                                        }
                                    }, 500);
                                    
                                    this.showNotification(`🎨 Modo Apagar Vértices ativado para ${carteiraId}`, 'info');
                                } else {
                                    this.showNotification('❌ Erro ao ativar pincel', 'error');
                                }
                            }, 100);
                        } else {
                            console.error('❌ Polígono atual não encontrado após selectSubTerritory');
                            this.showNotification('Erro: Polígono não encontrado', 'error');
                        }
                    }, 400);
                    
                } catch (error) {
                    console.error('❌ Erro ao ativar pincel:', error);
                    this.showNotification('Erro ao ativar pincel de apagar', 'error');
                }
            });
        }

        // NOVO: Botão Pincel de Apagar Vértices do Território (usar delegação única)
        if (!this._eraserTerritoriesListenerAdded) {
            this._eraserTerritoriesListenerAdded = true;
            
            document.addEventListener('click', async (e) => {
                const btn = e.target.closest('.btn-eraser-territory');
                if (!btn) return;
                
                e.stopPropagation();
                e.preventDefault();
                
                const territoryId = btn.dataset.territoryId;
                const territoryKey = btn.dataset.territoryKey;
                
                console.log('🎨 Pincel território clicado:', territoryKey);
                
                // Se já está ativo, apenas fazer toggle
                if (this.map.eraserState && this.map.eraserState.active) {
                    console.log('🔄 Borracha já ativa, fazendo toggle...');
                    this.map.disableVertexEraser();
                    this.showNotification('🎨 Modo Apagar Vértices desativado', 'info');
                    return;
                }
                
                try {
                    // Carregar território no mapa (usa a função existente)
                    await this.loadTerritoryOnMap(territoryId);
                    
                    // Aguardar renderização completa do polígono
                    setTimeout(() => {
                        if (this.currentPolygon) {
                            console.log('🔍 Polígono do território encontrado:', this.currentPolygon);
                            
                            // FORÇAR ativação da edição antes do pincel
                            if (!this.currentPolygon.editing.enabled()) {
                                console.log('⚙️ Ativando edição do polígono do território...');
                                this.currentPolygon.editing.enable();
                            }
                            
                            // Aguardar um pouco mais para garantir que os vértices são renderizados
                            setTimeout(() => {
                                // Ativar pincel de apagar vértices (SEM toggle interno)
                                const eraserEnabled = this.map._enableVertexEraserDirect(this.currentPolygon);
                                
                                if (eraserEnabled) {
                                    console.log('✅ Pincel ativado para território:', territoryKey);
                                    this.showNotification(`🎨 Modo Apagar Vértices ativado`, 'info');
                                } else {
                                    console.error('❌ Falha ao ativar pincel');
                                    this.showNotification('❌ Erro ao ativar pincel', 'error');
                                }
                            }, 100); // Aguardar renderização dos vértices
                        } else {
                            console.error('❌ Polígono atual não encontrado após carregar território');
                            this.showNotification('Erro: Polígono não encontrado', 'error');
                        }
                    }, 400); // Aguardar carregamento do território
                    
                } catch (error) {
                    console.error('❌ Erro ao ativar pincel do território:', error);
                    this.showNotification('Erro ao ativar pincel de apagar', 'error');
                }
            });
        }

        // NOVO: Botão Excluir Território (COM PREVENÇÃO DE DUPLICATAS)
        if (!this._deleteTerritoriesListenerAdded) {
            this._deleteTerritoriesListenerAdded = true;
            
            document.addEventListener('click', async (e) => {
                const btn = e.target.closest('.btn-delete-territory');
                if (!btn) return;
                
                e.stopPropagation();
                e.preventDefault();
                
                const territoryId = btn.dataset.territoryId;
                const territoryKey = btn.dataset.territoryKey;
                
                console.log('🗑️ Excluir território clicado:', territoryKey);
            
            try {
                // Buscar carteiras associadas
                const subTerritories = await this.dataManager.listSubTerritories(territoryId);
                
                // Confirmar exclusão
                const message = subTerritories.length > 0
                    ? `Tem certeza que deseja excluir o território ${territoryKey}?\n\nEsta ação irá remover também ${subTerritories.length} carteira(s) associada(s):\n${subTerritories.map(st => `• ${st.carteira_id}`).join('\n')}\n\n⚠️ Esta ação não pode ser desfeita!`
                    : `Tem certeza que deseja excluir o território ${territoryKey}?\n\n⚠️ Esta ação não pode ser desfeita!`;
                
                if (!confirm(message)) {
                    console.log('❌ Exclusão cancelada pelo usuário');
                    return;
                }
                
                // Excluir todas as carteiras primeiro
                if (subTerritories.length > 0) {
                    console.log(`🗑️ Excluindo ${subTerritories.length} carteira(s)...`);
                    for (const subT of subTerritories) {
                        await this.dataManager.deleteSubTerritory(subT.id);
                        console.log(`✅ Carteira ${subT.carteira_id} excluída`);
                    }
                }
                
                // Excluir território
                await this.dataManager.deleteTerritory(territoryId);
                console.log(`✅ Território ${territoryKey} excluído`);
                
                // Limpar estado se era o território atual
                if (this.currentTerritory && this.currentTerritory.id === territoryId) {
                    this.currentTerritory = null;
                    this.currentPolygon = null;
                    this.map.clearLayer('polygons');
                    this.map.clearLayer('drawings');
                }
                
                // Recarregar árvore e polígonos de fundo
                await this.loadRegionsTree();
                await this.map.loadBackgroundTerritories();
                
                this.showNotification(`✅ Território ${territoryKey} excluído com sucesso`, 'success');
                
            } catch (error) {
                console.error('❌ Erro ao excluir território:', error);
                this.showNotification('Erro ao excluir território', 'error');
            }
            });
        }

        // NOVO: Botão Excluir Carteira (rodapé do item) (COM PREVENÇÃO DE DUPLICATAS)
        if (!this._deleteCarteirasListenerAdded) {
            this._deleteCarteirasListenerAdded = true;
            
            document.addEventListener('click', async (e) => {
            const btn = e.target.closest('.btn-footer-action.btn-delete');
            if (!btn) return;
            
            e.stopPropagation();
            e.preventDefault();
            
            const subTerritoryId = btn.dataset.subTerritoryId;
            const territoryId = btn.dataset.territoryId;
            const carteiraId = btn.dataset.carteiraId;
            
            console.log('🗑️ Excluir carteira clicado:', carteiraId);
            
            try {
                // Confirmar exclusão
                if (!confirm(`Tem certeza que deseja excluir a carteira ${carteiraId}?\n\n⚠️ Esta ação não pode ser desfeita!`)) {
                    console.log('❌ Exclusão cancelada pelo usuário');
                    return;
                }
                
                // Excluir carteira
                await this.dataManager.deleteSubTerritory(subTerritoryId);
                console.log(`✅ Carteira ${carteiraId} excluída`);
                
                // Limpar estado se era a carteira atual
                if (this.currentSubTerritory && this.currentSubTerritory.id === subTerritoryId) {
                    this.currentSubTerritory = null;
                    this.currentPolygon = null;
                    
                    // Recarregar território pai
                    if (territoryId) {
                        await this.loadTerritoryOnMap(territoryId);
                    }
                }
                
                // Recarregar árvore e polígonos de fundo
                await this.loadRegionsTree();
                await this.map.loadBackgroundTerritories();
                
                this.showNotification(`✅ Carteira ${carteiraId} excluída com sucesso`, 'success');
                
            } catch (error) {
                console.error('❌ Erro ao excluir carteira:', error);
                this.showNotification('Erro ao excluir carteira', 'error');
            }
            });
        }

        // NOVO: Botão Histórico de Território
        if (!this._historyTerritoriesListenerAdded) {
            this._historyTerritoriesListenerAdded = true;

            document.addEventListener('click', async (e) => {
                const btn = e.target.closest('.btn-history-territory');
                if (!btn) return;

                e.stopPropagation();
                e.preventDefault();

                const territoryId = btn.dataset.territoryId;
                const territoryKey = btn.dataset.territoryKey;
                const territoryName = btn.dataset.territoryName;

                console.log('📜 Histórico território clicado:', territoryKey);

                try {
                    await this.showHistoryModal('territory', territoryId, territoryName || territoryKey);
                } catch (error) {
                    console.error('❌ Erro ao exibir histórico:', error);
                    this.showNotification('Erro ao carregar histórico', 'error');
                }
            });
        }

        // NOVO: Botão Histórico de Carteira (sub-território)
        if (!this._historyCarteirasListenerAdded) {
            this._historyCarteirasListenerAdded = true;

            document.addEventListener('click', async (e) => {
                const btn = e.target.closest('.btn-footer-action.btn-history');
                if (!btn) return;

                e.stopPropagation();
                e.preventDefault();

                const subTerritoryId = btn.dataset.subTerritoryId;
                const carteiraId = btn.dataset.carteiraId;
                const carteiraName = btn.dataset.carteiraName;

                console.log('📜 Histórico carteira clicado:', carteiraId);

                try {
                    await this.showHistoryModal('subTerritory', subTerritoryId, carteiraName || carteiraId);
                } catch (error) {
                    console.error('❌ Erro ao exibir histórico:', error);
                    this.showNotification('Erro ao carregar histórico', 'error');
                }
            });
        }
    }

    /**
     * Exibe modal de histórico de versões
     * @param {string} type - 'territory' ou 'subTerritory'
     * @param {string} id - UUID do item
     * @param {string} name - Nome do item para exibição
     */
    async showHistoryModal(type, id, name) {
        console.log(`📜 Abrindo modal de histórico: ${type} - ${id}`);

        // Referências dos elementos do modal
        const modal = document.getElementById('modalHistory');
        const itemName = document.getElementById('historyItemName');
        const itemId = document.getElementById('historyItemId');
        const loadingState = document.getElementById('historyLoadingState');
        const contentState = document.getElementById('historyContentState');
        const emptyState = document.getElementById('historyEmptyState');
        const versionsList = document.getElementById('historyVersionsList');

        // Configurar info do item
        itemName.textContent = name;
        itemId.textContent = `ID: ${id}`;

        // Mostrar loading
        loadingState.style.display = 'block';
        contentState.style.display = 'none';
        emptyState.style.display = 'none';

        // Abrir modal
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();

        try {
            // Buscar histórico
            let history;
            if (type === 'territory') {
                history = await this.dataManager.getTerritoryHistory(id);
            } else {
                history = await this.dataManager.getSubTerritoryHistory(id);
            }

            // Esconder loading
            loadingState.style.display = 'none';

            if (!history || history.length === 0) {
                emptyState.style.display = 'block';
                return;
            }

            // Renderizar lista de versões
            versionsList.innerHTML = history.map((version, index) => {
                const date = new Date(version.operation_timestamp);
                const formattedDate = date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR');
                const isCurrent = version.is_current_version;
                const operation = this._formatOperation(version.operation);
                const changedFields = version.changed_fields?.filter(f => f !== '*').join(', ') || 'Todos os campos';
                const areaHa = version.area_hectares ? `${parseFloat(version.area_hectares).toFixed(2)} ha` : '-';

                return `
                    <div class="list-group-item ${isCurrent ? 'list-group-item-success' : ''}">
                        <div class="d-flex w-100 justify-content-between align-items-start">
                            <div>
                                <h6 class="mb-1">
                                    <span class="badge ${this._getOperationBadgeClass(version.operation)} me-2">${operation}</span>
                                    Versão ${version.version_number}
                                    ${isCurrent ? '<span class="badge bg-success ms-2">Atual</span>' : ''}
                                </h6>
                                <p class="mb-1 small text-muted">
                                    <i class="bi bi-clock me-1"></i>${formattedDate}
                                    <span class="ms-2"><i class="bi bi-person me-1"></i>${version.operation_user || 'system'}</span>
                                </p>
                                <p class="mb-1 small">
                                    <i class="bi bi-rulers me-1"></i>Área: ${areaHa}
                                    ${version.changed_fields && version.changed_fields.length > 0 && version.changed_fields[0] !== '*'
                                        ? `<span class="ms-2 text-info"><i class="bi bi-pencil me-1"></i>Campos: ${changedFields}</span>`
                                        : ''}
                                </p>
                            </div>
                            ${!isCurrent && version.operation !== 'DELETE' ? `
                                <button class="btn btn-sm btn-outline-primary btn-restore-version"
                                        data-history-id="${version.history_id}"
                                        data-type="${type}"
                                        data-version="${version.version_number}"
                                        title="Restaurar esta versão">
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                    Restaurar
                                </button>
                            ` : ''}
                        </div>
                    </div>
                `;
            }).join('');

            contentState.style.display = 'block';

            // Handler para botões de restaurar
            versionsList.querySelectorAll('.btn-restore-version').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.preventDefault();
                    const historyId = btn.dataset.historyId;
                    const restoreType = btn.dataset.type;
                    const versionNum = btn.dataset.version;

                    if (!confirm(`Deseja restaurar para a versão ${versionNum}?\n\nIsso irá sobrescrever os dados atuais.`)) {
                        return;
                    }

                    try {
                        btn.disabled = true;
                        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

                        if (restoreType === 'territory') {
                            await this.dataManager.restoreTerritoryVersion(historyId);
                        } else {
                            await this.dataManager.restoreSubTerritoryVersion(historyId);
                        }

                        this.showNotification(`✅ Versão ${versionNum} restaurada com sucesso!`, 'success');

                        // Fechar modal
                        bsModal.hide();

                        // Recarregar árvore e mapa
                        await this.loadRegionsTree();
                        await this.map.loadBackgroundTerritories();

                    } catch (error) {
                        console.error('❌ Erro ao restaurar versão:', error);
                        this.showNotification('Erro ao restaurar versão', 'error');
                        btn.disabled = false;
                        btn.innerHTML = '<i class="bi bi-arrow-counterclockwise"></i> Restaurar';
                    }
                });
            });

        } catch (error) {
            console.error('❌ Erro ao carregar histórico:', error);
            loadingState.style.display = 'none';
            emptyState.style.display = 'block';
            emptyState.querySelector('.alert').innerHTML = `
                <i class="bi bi-exclamation-triangle me-2"></i>
                Erro ao carregar histórico: ${error.message}
            `;
        }
    }

    /**
     * Formata o tipo de operação para exibição
     */
    _formatOperation(operation) {
        const ops = {
            'INSERT': 'Criação',
            'UPDATE': 'Atualização',
            'DELETE': 'Exclusão'
        };
        return ops[operation] || operation;
    }

    /**
     * Retorna classe CSS do badge baseado na operação
     */
    _getOperationBadgeClass(operation) {
        const classes = {
            'INSERT': 'bg-success',
            'UPDATE': 'bg-primary',
            'DELETE': 'bg-danger'
        };
        return classes[operation] || 'bg-secondary';
    }

    /**
     * Carrega e exibe um território no mapa
     */
    async loadTerritoryOnMap(territoryId) {
        try {
            console.log('🔍 loadTerritoryOnMap CHAMADO! Stack trace:');
            console.trace();
            
            // BLOQUEAR se estivermos carregando uma carteira
            if (this._loadingSubTerritory) {
                console.warn('⚠️ BLOQUEADO: Carregando carteira, não pode carregar território!');
                return;
            }
            
            // Buscar território no banco
            const territories = await this.dataManager.listTerritories();
            const territory = territories.find(t => t.id === territoryId);
            
            if (!territory) {
                this.showNotification('❌ Território não encontrado', 'error');
                return;
            }

            // Armazenar território atual E região
            this.currentTerritory = territory;
            this.currentCenterKey = territory.center_key;
            this.currentRegion = territory.region_name; // Armazenar região para manter contexto
            console.log(`📍 Território atual: ${territory.territory_id} (Centro: ${this.currentCenterKey}, Região: ${this.currentRegion})`);

            // Limpar apenas camadas de desenho, MANTER polígonos de fundo
            this.map.clearLayer('drawings');
            this.map.clearLayer('car');
            
            // Recarregar polígonos de fundo para contexto
            console.log('🔄 Recarregando contexto de fundo...');
            await this.map.loadBackgroundTerritories();
            
            // Carregar áreas por UNIDADE (modo território)
            // Será controlado pelo Layer Control do Leaflet
            if (this.currentCenterKey) {
                console.log('� Carregando áreas por UNIDADE (modo território)...');
                await this.setViewMode('unidade', this.currentCenterKey);
            }

            // Adicionar polígono do território atual por cima (destaque)
            const layer = this.map.addGeoJSONPolygon(territory.geometry, {
                color: this.map.territoryColors.territory,
                fillColor: this.map.territoryColors.territoryFill,
                weight: 3,
                fillOpacity: 0.5,
                popup: `<b>${territory.name || territory.territory_id}</b><br>Área: ${territory.area_hectares ? territory.area_hectares.toFixed(2) + ' ha' : 'N/A'}`
            });

            // Centralizar mapa no polígono
            if (layer && layer.getBounds) {
                this.map.getMap().fitBounds(layer.getBounds(), {
                    padding: [50, 50],
                    maxZoom: 15
                });
            }

            // Armazenar referência do polígono para permitir edição posterior
            if (layer && layer.getLayers) {
                const polygonLayer = layer.getLayers()[0];
                if (polygonLayer) {
                    polygonLayer.centerKey = territory.center_key;
                    polygonLayer.territoryData = territory;
                    this.currentPolygon = polygonLayer;
                }
            } else if (layer) {
                layer.centerKey = territory.center_key;
                layer.territoryData = territory;
                this.currentPolygon = layer;
            }

            this.showNotification(`✅ Território ${territory.name || territory.territory_id} carregado`, 'success');
            
            // NÃO chamar expandActiveContext() aqui pois pode disparar eventos
            // indevidos de clique na árvore
            // this.expandActiveContext();

        } catch (error) {
            console.error('Erro ao carregar território:', error);
            this.showNotification('❌ Erro ao carregar território', 'error');
        }
    }

    /**
     * Mostra detalhes do território no painel direito
     * NOTA: Painel direito removido - função desabilitada
     */
    showTerritoryDetails(territory) {
        // Painel removido do layout - informações disponíveis nos popups do mapa
        return;
    }

    /**
     * Define um item como ativo (destacado)
     */
    setActiveItem(element) {
        // Remover classe active de todos os itens
        document.querySelectorAll('.region-item, .center-item, .territory-item, .sub-territory-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Adicionar classe active ao item clicado
        element.classList.add('active');
    }

    /**
     * Toggle todas as regiões
     */
    toggleAllRegions() {
        const regions = document.querySelectorAll('.region-item');
        const allCollapsed = Array.from(regions).every(r => r.classList.contains('collapsed'));
        
        regions.forEach(region => {
            if (allCollapsed) {
                region.classList.remove('collapsed');
            } else {
                region.classList.add('collapsed');
            }
        });

        // Atualizar ícone do botão
        const btn = document.getElementById('btnToggleAll');
        const icon = btn.querySelector('i');
        if (allCollapsed) {
            icon.className = 'bi bi-arrows-collapse';
        } else {
            icon.className = 'bi bi-arrows-expand';
        }
    }

    /**
     * Toggle sidebar - recolher/expandir painel lateral
     */
    toggleSidebar() {
        const workspace = document.querySelector('.workspace');
        const btn = document.getElementById('btnToggleSidebar');
        const icon = btn?.querySelector('i');

        if (!workspace) return;

        const isCollapsed = workspace.classList.toggle('sidebar-collapsed');

        // Atualizar ícone e estado do botão
        if (btn) {
            btn.classList.toggle('collapsed', isCollapsed);
            btn.title = isCollapsed ? 'Mostrar painel de regiões' : 'Ocultar painel de regiões';
        }
        if (icon) {
            icon.className = isCollapsed ? 'bi bi-layout-sidebar' : 'bi bi-layout-sidebar-inset';
        }

        // Invalidar tamanho do mapa após transição
        setTimeout(() => {
            if (window.app?.map?.map) {
                window.app.map.map.invalidateSize();
            }
        }, 250);
    }

    /**
     * Recolhe sidebar automaticamente (usado durante edição)
     */
    collapseSidebar() {
        const workspace = document.querySelector('.workspace');
        if (workspace && !workspace.classList.contains('sidebar-collapsed')) {
            this.toggleSidebar();
        }
    }

    /**
     * Expande sidebar (restaura)
     */
    expandSidebar() {
        const workspace = document.querySelector('.workspace');
        if (workspace && workspace.classList.contains('sidebar-collapsed')) {
            this.toggleSidebar();
        }
    }

    /**
     * Expande automaticamente a região e centro do contexto atual
     */
    expandActiveContext() {
        try {
            // Determinar contexto atual
            let regionToExpand = null;
            let centerKeyToHighlight = null;

            // 1. Se há território atual carregado
            if (this.currentTerritory && this.currentTerritory.region_name) {
                regionToExpand = this.currentTerritory.region_name;
                centerKeyToHighlight = this.currentTerritory.center_key;
            }
            // 2. Se há carteira atual carregada
            else if (this.currentSubTerritory && this.currentParentTerritory) {
                regionToExpand = this.currentParentTerritory.region_name;
                centerKeyToHighlight = this.currentParentTerritory.center_key;
            }
            // 3. Se há região selecionada manualmente
            else if (this.currentRegion) {
                regionToExpand = this.currentRegion;
            }
            // 4. Se há centro selecionado
            else if (this.currentCenterKey) {
                centerKeyToHighlight = this.currentCenterKey;
                // Encontrar região do centro
                const centerItem = document.querySelector(`[data-center-key="${this.currentCenterKey}"]`);
                if (centerItem) {
                    regionToExpand = centerItem.dataset.region;
                }
            }

            // Expandir região
            if (regionToExpand) {
                const regionItem = document.querySelector(`[data-region-id="${regionToExpand}"]`);
                if (regionItem) {
                    regionItem.classList.remove('collapsed');
                    console.log(`📂 Região expandida: ${regionToExpand}`);
                }
            }

            // Destacar centro
            if (centerKeyToHighlight) {
                const centerItem = document.querySelector(`[data-center-key="${centerKeyToHighlight}"]`);
                if (centerItem) {
                    // IMPORTANTE: Apenas adicionar classe active, NÃO disparar clique
                    // Remove active de outros itens
                    document.querySelectorAll('.tree-center').forEach(item => {
                        item.classList.remove('active');
                    });
                    
                    centerItem.classList.add('active');
                    
                    // Scroll para o item ativo SEM disparar eventos
                    setTimeout(() => {
                        centerItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }, 100);
                    console.log(`🎯 Centro destacado: ${centerKeyToHighlight}`);
                }
            }

        } catch (error) {
            console.error('❌ Erro ao expandir contexto ativo:', error);
        }
    }

    /**
     * Recarrega território do banco de dados
     */
    async reloadTerritoryFromDatabase(centerKey) {
        try {
            console.log(`🔄 Recarregando território para centro: ${centerKey}`);
            
            // Buscar território atualizado no banco
            const territories = await this.dataManager.listTerritories();
            const territory = territories.find(t => t.center_key === centerKey);
            
            if (!territory) {
                console.warn('⚠️ Território não encontrado no banco');
                return;
            }

            // Limpar polígono atual do mapa
            if (this.selectedPolygon) {
                this.map.layers.polygons.removeLayer(this.selectedPolygon);
                this.map.layers.drawings.removeLayer(this.selectedPolygon);
            }

            // Adicionar polígono atualizado ao mapa
            const layer = this.map.addGeoJSONPolygon(territory.geometry, {
                color: this.map.territoryColors.territory,
                fillColor: this.map.territoryColors.territoryFill,
                popup: `<b>${territory.center_key}</b><br>Área: ${territory.area_hectares ? territory.area_hectares.toFixed(2) + ' ha' : 'N/A'}`
            });

            if (layer) {
                // Armazenar dados do território no layer
                layer.centerKey = territory.center_key;
                layer.territoryData = territory;
                
                // Selecionar o novo polígono
                this.selectPolygon(layer);
                
                // Centralizar no polígono
                this.map.map.fitBounds(layer.getBounds(), {
                    padding: [50, 50]
                });
                
                console.log('✅ Território recarregado do banco com sucesso');
                this.showNotification('✅ Território atualizado e recarregado', 'success');
            }

        } catch (error) {
            console.error('❌ Erro ao recarregar território:', error);
            this.showNotification('⚠️ Erro ao recarregar território', 'warning');
        }
    }

    /**
     * Mostra modal para novo território
     */
    async showNewTerritoryModal(centerName, centerKey, regionName) {
        try {
            // IMPORTANTE: Recarregar territórios de fundo antes de abrir modal
            await this.map.loadBackgroundTerritories();
            console.log('✅ Territórios de fundo recarregados antes de criar novo');
            
            // Verificar se já existe um território para este centro
            const territories = await this.dataManager.listTerritories();
            const existingTerritory = territories.find(t => t.center_key === centerKey);
            
            if (existingTerritory) {
                // Se já existe território, carregar no mapa ao invés de criar novo
                this.showNotification(`ℹ️ Centro ${centerKey} já possui território. Carregando...`, 'info');
                await this.loadTerritoryOnMap(existingTerritory.id);
                return;
            }
            
            // O território usa apenas o Centro Chave (ex: C089)
            const territoryId = centerKey;

            // Preencher modal
            document.getElementById('territoryCenter').textContent = centerName;
            document.getElementById('territoryRegion').textContent = regionName;
            document.getElementById('territoryId').value = territoryId;

            // Guardar dados no modal para uso posterior
            const modal = document.getElementById('modalNewTerritory');
            modal.dataset.centerName = centerName;
            modal.dataset.centerKey = centerKey;
            modal.dataset.regionName = regionName;
            modal.dataset.territoryId = territoryId;

            // Mostrar modal
            const bsModal = new bootstrap.Modal(modal);
            bsModal.show();

        } catch (error) {
            console.error('Erro ao abrir modal de território:', error);
            this.showNotification('❌ Erro ao preparar novo território', 'error');
        }
    }

    /**
     * Gera o próximo ID sequencial para o território
     */
    async generateNextTerritoryId(centerKey) {
        try {
            // Buscar territórios existentes para este centro
            const territories = await this.dataManager.listTerritories();
            const centerTerritories = territories.filter(t => 
                t.territory_id && t.territory_id.startsWith(centerKey + '.')
            );

            if (centerTerritories.length === 0) {
                return `${centerKey}.01`;
            }

            // Encontrar o maior número
            let maxNum = 0;
            for (const territory of centerTerritories) {
                const match = territory.territory_id.match(/\.(\d{2})$/);
                if (match) {
                    const num = parseInt(match[1], 10);
                    if (num > maxNum) maxNum = num;
                }
            }

            // Próximo número
            const nextNum = maxNum + 1;
            return `${centerKey}.${nextNum.toString().padStart(2, '0')}`;

        } catch (error) {
            console.error('Erro ao gerar ID do território:', error);
            return `${centerKey}.01`;
        }
    }

    /**
     * Confirma criação do território e inicia desenho
     */
    handleConfirmNewTerritory() {
        const modal = document.getElementById('modalNewTerritory');
        const territoryId = modal.dataset.territoryId; // Centro Chave (ex: C089)
        const centerName = modal.dataset.centerName;
        const centerKey = modal.dataset.centerKey;
        const regionName = modal.dataset.regionName;

        // Guardar dados do território pendente
        this.pendingTerritory = {
            id: territoryId,                    // Centro Chave (ex: C089)
            name: centerName,                   // Nome do centro como nome do território
            centerName: centerName,
            centerKey: centerKey,
            regionName: regionName
        };

        // Fechar modal
        bootstrap.Modal.getInstance(modal).hide();

        // IMPORTANTE: Carregar territórios de fundo antes de iniciar desenho
        setTimeout(async () => {
            console.log('🔄 Carregando territórios de fundo antes de desenhar...');
            await this.map.loadBackgroundTerritories();
            console.log('✅ Territórios de fundo carregados');
            
            this.handleDrawPolygon();
            this.showNotification('✏️ Desenhe o território no mapa. Clique para adicionar pontos, clique duplo para finalizar.', 'info');
        }, 300);
    }

    /**
     * Salva detalhes do polígono
     */
    async handleSavePolygonDetails() {
        try {
            const name = document.getElementById('polygonName').value;
            const type = document.getElementById('polygonType').value;

            if (!name) {
                this.showNotification('⚠️ Digite um nome para o polígono', 'warning');
                return;
            }

            // TODO: Salvar no banco de dados
            console.log('Salvando polígono:', { name, type });

            bootstrap.Modal.getInstance(document.getElementById('modalPolygonDetails')).hide();
            this.showNotification('✅ Polígono salvo com sucesso!', 'success');

        } catch (error) {
            console.error(error);
            this.showNotification('❌ Erro ao salvar polígono', 'error');
        }
    }

    /**
     * Salva tudo
     */
    async handleSave() {
        this.showNotification('💾 Salvando...', 'info');
        // TODO: Implementar salvamento completo
    }

    /**
     * Carrega tudo
     */
    async handleLoad() {
        this.showNotification('📂 Carregando...', 'info');
        this.loadRegionsTree();
    }

    // ==================== HELPERS ====================

    /**
     * Atualiza a área exibida no center-item
     */
    updateCenterItemArea(centerKey, areaHectares) {
        try {
            // Encontrar o center-item pelo data-center-key
            const centerItem = document.querySelector(`.center-item[data-center-key="${centerKey}"]`);
            
            if (!centerItem) {
                console.warn(`⚠️ Center item não encontrado para: ${centerKey}`);
                return;
            }

            // Verificar se já existe o elemento de área
            let areaElement = centerItem.querySelector('.center-item-area');
            
            if (areaElement) {
                // Atualizar área existente (inline)
                areaElement.innerHTML = `<i class="bi bi-bounding-box"></i> ${areaHectares.toFixed(2)} ha`;
                console.log(`✅ Área atualizada no center-item: ${areaHectares.toFixed(2)} ha`);
            } else {
                // Criar novo elemento de área (inline)
                const detailsContainer = centerItem.querySelector('.center-item-details');
                
                if (detailsContainer) {
                    areaElement = document.createElement('span');
                    areaElement.className = 'center-item-area';
                    areaElement.innerHTML = `<i class="bi bi-bounding-box"></i> ${areaHectares.toFixed(2)} ha`;
                    detailsContainer.appendChild(areaElement);
                    console.log(`✅ Área adicionada ao center-item: ${areaHectares.toFixed(2)} ha`);
                }
            }

            // Adicionar classe has-territory se não tiver
            if (!centerItem.classList.contains('has-territory')) {
                centerItem.classList.add('has-territory');
                
                // Atualizar ícone
                const icon = centerItem.querySelector('.tree-item-icon');
                if (icon) {
                    icon.className = 'bi bi-pin-map-fill tree-item-icon';
                }
                
                // Adicionar ícone de verificação no header se não existir
                const header = centerItem.querySelector('.center-item-header');
                if (header && !header.querySelector('.bi-check-circle-fill')) {
                    const checkIcon = document.createElement('i');
                    checkIcon.className = 'bi bi-check-circle-fill ms-auto';
                    checkIcon.style.opacity = '1';
                    checkIcon.style.color = '#3b82f6';
                    header.appendChild(checkIcon);
                }
            }

        } catch (error) {
            console.error('❌ Erro ao atualizar área no center-item:', error);
        }
    }

    // ==================== SUB-TERRITORY METHODS ====================

    /**
     * Abre o wizard de criação de sub-território
     * @param {Object} parentTerritory - Território pai
     * @param {L.Polygon} layer - Layer do polígono desenhado
     */
    async openSubTerritoryWizard(parentTerritory, layer) {
        try {
            // 🔒 PREVENIR ABERTURA DUPLICADA DE WIZARD
            if (this._wizardOpening) {
                console.log('⏭️ Wizard já está abrindo, ignorando chamada duplicada');
                return;
            }
            this._wizardOpening = true;
            
            console.log('🧙 Abrindo Territory Wizard (Contexto: SUB-TERRITÓRIO) para:', parentTerritory.territory_id);
            
            if (!window.TerritoryWizard) {
                console.error('❌ TerritoryWizard não encontrado');
                this.showNotification('Erro: TerritoryWizard não carregado', 'error');
                return;
            }

            // USAR TERRITORY WIZARD COM CONTEXTO DE SUB-TERRITÓRIO
            const wizard = new TerritoryWizard('sub-territory', parentTerritory);
            
            // ✅ SUBSTITUIR window.app.wizard TEMPORARIAMENTE
            // Os botões do modal chamam window.app.wizard.next(), window.app.wizard.cancel(), etc
            const originalWizard = window.app.wizard;
            window.app.wizard = wizard;
            
            console.log('🔄 window.app.wizard SUBSTITUÍDO para contexto SUB-TERRITÓRIO');
            
            // Restaurar wizard original quando fechar o modal
            const modalElement = document.getElementById('modalTerritoryWizard');
            const restoreOriginalWizard = () => {
                window.app.wizard = originalWizard;
                console.log('🔄 window.app.wizard RESTAURADO para contexto GLOBAL');
                modalElement.removeEventListener('hidden.bs.modal', restoreOriginalWizard);
            };
            modalElement.addEventListener('hidden.bs.modal', restoreOriginalWizard);
            
            // Passar o layer e abrir wizard
            await wizard.open(layer, null);
            
            // 🔓 LIBERAR FLAG APÓS ABERTURA
            setTimeout(() => {
                this._wizardOpening = false;
            }, 1000);

        } catch (error) {
            console.error('❌ Erro ao abrir TerritoryWizard (sub-território):', error);
            this.showNotification('Erro ao abrir assistente de sub-território', 'error');
        }
    }

    /**
     * Abre o wizard de criação/ajuste de TERRITÓRIO
     * @param {L.Polygon} layer - Layer do polígono desenhado
     * @param {Object|null} overlapResult - Resultado da verificação de sobreposição (pode conter territories)
     */
    async openTerritoryWizard(layer, overlapResult = null) {
        try {
            // 🔒 PREVENIR ABERTURA DUPLICADA DE WIZARD
            if (this._wizardOpening) {
                console.log('⏭️ Wizard já está abrindo, ignorando chamada duplicada');
                return;
            }
            this._wizardOpening = true;

            console.log('🧙 Abrindo Territory Wizard (Contexto: TERRITORY)');

            if (!window.TerritoryWizard) {
                console.error('❌ TerritoryWizard não encontrado');
                this.showNotification('Erro: TerritoryWizard não carregado', 'error');
                return;
            }

            // USAR TERRITORY WIZARD COM CONTEXTO DE TERRITORY
            const wizard = new TerritoryWizard('territory', null);

            // Substituir window.app.wizard temporariamente (os botões do modal chamam window.app.wizard.next())
            const originalWizard = window.app.wizard;
            window.app.wizard = wizard;
            console.log('🔄 window.app.wizard SUBSTITUÍDO para contexto TERRITORY');

            // Restaurar wizard original quando fechar o modal
            const modalElement = document.getElementById('modalTerritoryWizard');
            const restoreOriginalWizard = () => {
                window.app.wizard = originalWizard;
                console.log('🔄 window.app.wizard RESTAURADO para contexto GLOBAL');
                modalElement.removeEventListener('hidden.bs.modal', restoreOriginalWizard);
            };
            modalElement.addEventListener('hidden.bs.modal', restoreOriginalWizard);

            // Passar o layer e abrir wizard, fornecendo overlapResult
            await wizard.open(layer, overlapResult);

            // Liberar flag após abertura
            setTimeout(() => {
                this._wizardOpening = false;
            }, 1000);

        } catch (error) {
            console.error('❌ Erro ao abrir TerritoryWizard (território):', error);
            this.showNotification('Erro ao abrir assistente de território', 'error');
        }
    }

    /**
     * Desenha um novo sub-território para um território pai
     * @param {Object} territory - Território pai
     */
    async drawSubTerritory(territory) {
        try {
            console.log('✏️ Iniciando desenho de carteira para:', territory.territory_id);
            
            // Armazenar território pai atual
            this.currentParentTerritory = territory;
            
            // PASSO 1: Centralizar e exibir o território pai no mapa como referência
            console.log('📍 Centralizando território pai no mapa...');
            
            // Limpar apenas desenhos e CAR, MANTER contexto de fundo
            this.map.clearLayer('drawings');
            this.map.clearLayer('car');
            
            // Recarregar polígonos de fundo para contexto completo
            console.log('🔄 Carregando todos os territórios e carteiras de fundo...');
            await this.map.loadBackgroundTerritories();
            
            // Renderizar território pai no mapa POR CIMA (como referência principal - NÃO EDITÁVEL)
            const parentGeometry = typeof territory.geometry === 'string' 
                ? JSON.parse(territory.geometry) 
                : territory.geometry;
            
            const parentLayer = L.geoJSON(parentGeometry, {
                style: {
                    color: this.map.territoryColors.territory,
                    fillColor: this.map.territoryColors.territoryFill,
                    weight: 3,
                    fillOpacity: 0.25,
                    opacity: 0.8,
                    dashArray: '5, 10'
                },
                interactive: false // IMPORTANTE: Tornar o polígono de fundo não interativo
            }).addTo(this.map.layers.polygons);
            
            // Centralizar mapa no território pai
            this.map.map.fitBounds(parentLayer.getBounds(), { 
                padding: [80, 80],
                maxZoom: 15,
                animate: true,
                duration: 0.8
            });
            
            console.log('✅ Território pai exibido como referência (bloqueado para edição)');
            
            // PASSO 2: Ativar modo de desenho após breve delay (para que o usuário veja o território)
            setTimeout(() => {
                console.log('🎨 Ativando modo de desenho de carteira...');
                
                // 🔒 REMOVER TODOS OS LISTENERS ANTERIORES (prevenir duplicação)
                this.map.map.off('draw:created');
                
                // Ativar desenho diretamente no mapa
                if (this.map && this.map.startDrawing) {
                    this.map.startDrawing(true); // true = modo sub-território
                    this.showNotification(`📐 Desenhe a carteira dentro de: ${territory.territory_id || territory.name}`, 'info');
                } else {
                    console.error('❌ Método startDrawing não disponível');
                    this.showNotification('❌ Erro ao ativar modo de desenho', 'error');
                    return;
                }
                
                // Adicionar listener ÚNICO para quando o polígono for desenhado
                const onDrawCreated = async (e) => {
                    const layer = e.layer;
                    
                    // Remover listener IMEDIATAMENTE para evitar duplicação
                    this.map.map.off('draw:created', onDrawCreated);
                    
                    console.log('✅ Polígono desenhado, abrindo wizard...');
                    
                    // Abrir wizard de carteira
                    await this.openSubTerritoryWizard(this.currentParentTerritory, layer);
                };
                
                // Registrar listener APÓS limpar todos os anteriores
                this.map.map.on('draw:created', onDrawCreated);
                
            }, 800); // Aumentar delay para dar tempo de visualizar o território

        } catch (error) {
            console.error('❌ Erro ao iniciar desenho de carteira:', error);
            this.showNotification('Erro ao iniciar desenho de carteira', 'error');
        }
    }

    /**
     * Lista sub-territórios de um território na árvore
     * @param {String} territoryId - ID do território
     * @param {HTMLElement} parentElement - Elemento HTML pai onde renderizar
     */
    async renderSubTerritoriesInTree(territoryId, parentElement) {
        try {
            const subTerritories = await this.dataManager.listSubTerritories(territoryId);
            
            if (!subTerritories || subTerritories.length === 0) {
                return;
            }

            // Criar container para sub-territórios
            const subContainer = document.createElement('div');
            subContainer.className = 'sub-territories-container';
            subContainer.style.marginLeft = '20px';
            
            subTerritories.forEach(subTerritory => {
                const subItem = document.createElement('div');
                subItem.className = 'sub-territory-item';
                subItem.dataset.subTerritoryId = subTerritory.id;
                subItem.dataset.carteiraId = subTerritory.carteira_id;
                
                subItem.innerHTML = `
                    <div class="sub-territory-item-content">
                        <div class="sub-territory-item-header">
                            <i class="bi bi-diagram-3 tree-item-icon text-warning"></i>
                            <span class="sub-territory-item-title">${subTerritory.name || subTerritory.carteira_id}</span>
                        </div>
                        <div class="sub-territory-item-details">
                            <small class="sub-territory-item-code">${subTerritory.carteira_id}</small>
                            <small class="sub-territory-item-area">${subTerritory.area_hectares ? subTerritory.area_hectares.toFixed(2) + ' ha' : ''}</small>
                        </div>
                    </div>
                `;
                
                // Adicionar listener de clique
                subItem.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await this.selectSubTerritory(subTerritory);
                });
                
                subContainer.appendChild(subItem);
            });
            
            parentElement.appendChild(subContainer);

        } catch (error) {
            console.error('❌ Erro ao renderizar sub-territórios na árvore:', error);
        }
    }

    /**
     * Seleciona e exibe uma carteira no mapa
     * @param {Object} subTerritory - Carteira a selecionar
     */
    async selectSubTerritory(subTerritory) {
        try {
            console.log('📍 Selecionando carteira:', subTerritory.carteira_id);
            
            // BLOQUEAR chamadas a loadTerritoryOnMap durante carregamento de carteira
            this._loadingSubTerritory = true;
            
            // LIMPAR CONTEXTO DO TERRITÓRIO ANTERIOR
            console.log('🧹 Limpando contexto de território anterior...');
            this.currentTerritory = null;
            this.currentPolygon = null;
            this.currentParentTerritory = null;
            
            // Limpar apenas camadas de desenho e CAR, MANTER polígonos de fundo
            this.map.clearLayer('drawings');
            this.map.clearLayer('car');
            
            // Recarregar polígonos de fundo para contexto
            console.log('🔄 Recarregando contexto de fundo...');
            await this.map.loadBackgroundTerritories();
            
            // Carregar áreas por CONSULTOR (modo carteira)
            if (this.currentCenterKey) {
                console.log('👤 Carregando áreas por CONSULTOR (modo carteira)...');
                await this.setViewMode('consultor', this.currentCenterKey);
            }
            
            // Preparar geometria da carteira
            const geometry = typeof subTerritory.geometry === 'string' 
                ? JSON.parse(subTerritory.geometry) 
                : subTerritory.geometry;
            
            // Criar layer do GeoJSON
            const geoJsonLayer = L.geoJSON(geometry, {
                style: {
                    color: this.map.territoryColors.subTerritory, // OURO para carteira
                    fillColor: this.map.territoryColors.subTerritoryFill,
                    weight: 3,
                    fillOpacity: 0.5  // Mais visível que o fundo
                }
            });
            
            // Extrair o polígono do layer GeoJSON
            const polygon = geoJsonLayer.getLayers()[0];
            
            if (!polygon) {
                console.error('❌ Erro: polígono não encontrado no layer');
                return;
            }
            
            // VALIDAR GEOMETRIA antes de habilitar edição
            const latlngs = polygon.getLatLngs();
            console.log('🔍 Validando geometria da carteira...');
            console.log('   • Estrutura latlngs:', latlngs);
            console.log('   • Tipo:', Array.isArray(latlngs) ? 'Array' : typeof latlngs);
            console.log('   • Length:', latlngs.length);
            
            // Verificar se há coordenadas válidas
            let hasValidCoords = true;
            let firstRing = Array.isArray(latlngs[0]) ? latlngs[0] : latlngs;
            
            console.log('   • Primeiro anel (nível 1):', firstRing);
            console.log('   • Length nível 1:', firstRing.length);
            
            // DESANINHAR: Se firstRing[0] é um array, ir mais fundo
            if (firstRing.length === 1 && Array.isArray(firstRing[0])) {
                console.log('   ⚠️ Estrutura aninhada demais, desaninhando...');
                firstRing = firstRing[0];
                console.log('   • Primeiro anel (nível 2):', firstRing);
            }
            
            console.log('   • Vértices no primeiro anel:', firstRing.length);
            
            // Verificar cada vértice
            for (let i = 0; i < firstRing.length; i++) {
                const vertex = firstRing[i];
                if (!vertex || vertex.lat === null || vertex.lat === undefined || 
                    vertex.lng === null || vertex.lng === undefined ||
                    isNaN(vertex.lat) || isNaN(vertex.lng)) {
                    console.error(`❌ Vértice ${i} inválido:`, vertex);
                    hasValidCoords = false;
                }
            }
            
            if (!hasValidCoords) {
                console.error('❌ Geometria possui coordenadas inválidas (null/undefined/NaN)');
                this.showNotification('❌ Erro: Geometria da carteira está corrompida', 'error');
                return;
            }
            
            if (firstRing.length < 3) {
                console.error('❌ Geometria possui menos de 3 vértices:', firstRing.length);
                this.showNotification('❌ Erro: Geometria da carteira inválida (menos de 3 vértices)', 'error');
                return;
            }
            
            console.log('✅ Geometria validada:', firstRing.length, 'vértices válidos');
            
            // Debug: Verificar tipo dos vértices
            console.log('🔍 Tipo do primeiro vértice:', firstRing[0]);
            console.log('🔍 É LatLng?', firstRing[0] instanceof L.LatLng);
            console.log('🔍 Tem lat/lng?', firstRing[0] && firstRing[0].lat !== undefined);
            
            // CRÍTICO: Garantir que vértices são objetos LatLng do Leaflet
            const validLatLngs = firstRing.map(v => {
                if (v instanceof L.LatLng) return v;
                if (v && v.lat !== undefined && v.lng !== undefined) {
                    return L.latLng(v.lat, v.lng);
                }
                console.error('❌ Vértice inválido encontrado:', v);
                return null;
            }).filter(v => v !== null);
            
            console.log('✅', validLatLngs.length, 'vértices LatLng criados');
            
            // CRÍTICO: RECONSTRUIR polígono com estrutura correta
            console.log('🔧 Reconstruindo polígono com estrutura correta...');
            polygon.setLatLngs([validLatLngs]);
            console.log('✅ Estrutura do polígono corrigida');
            const newStructure = polygon.getLatLngs();
            console.log('🔍 Nova estrutura tem', newStructure.length, 'anéis');
            console.log('🔍 Primeiro anel tem', newStructure[0] ? newStructure[0].length : 0, 'vértices');
            console.log('🔍 Primeiro vértice do primeiro anel:', newStructure[0] ? newStructure[0][0] : 'N/A');
            
            // NÃO habilitar edição automaticamente - apenas ao clicar em "Editar" ou "Apagar Vértices"
            console.log('ℹ️ Polígono carregado SEM modo de edição (aguardando ação do usuário)');
            
            // Adicionar dados da carteira ao polígono
            polygon.subTerritoryData = subTerritory;
            polygon.carteira_id = subTerritory.carteira_id;
            
            // CRÍTICO: Definir pane para primeiro plano
            polygon.options.pane = 'drawingsPane';
            
            // Adicionar à camada de desenhos (editável) - aparecerá no PRIMEIRO PLANO
            this.map.layers.drawings.addLayer(polygon);
            
            console.log('✅ Carteira adicionada à camada de desenhos (PRIMEIRO PLANO)');
            
            // Centralizar mapa no polígono
            this.map.map.fitBounds(polygon.getBounds(), { 
                padding: [50, 50],
                maxZoom: 16
            });
            
            // Armazenar referência do polígono atual
            this.currentSubTerritory = subTerritory;
            this.currentPolygon = polygon;
            
            console.log('✅ Carteira carregada:', subTerritory.carteira_id);
            this.showNotification(`📍 Carteira ${subTerritory.carteira_id} selecionada`, 'success');
            
            // Expandir região e destacar centro na árvore
            // AGORA É SEGURO porque expandActiveContext() não dispara mais eventos de clique
            this.expandActiveContext();
            
            // DESBLOQUEAR chamadas a loadTerritoryOnMap
            this._loadingSubTerritory = false;

        } catch (error) {
            console.error('❌ Erro ao selecionar carteira:', error);
            this.showNotification('Erro ao selecionar carteira', 'error');
            this._loadingSubTerritory = false; // Desbloquear mesmo em caso de erro
        }
    }

    /**
     * Atualiza rodapé da carteira para mostrar ferramentas de edição
     * @param {String} subTerritoryId - ID da carteira
     * @param {Boolean} isEditing - Se está em modo de edição
     */
    updateSubTerritoryFooter(subTerritoryId, isEditing = false) {
        const item = document.querySelector(`.sub-territory-item[data-sub-territory-id="${subTerritoryId}"]`);
        if (!item) return;

        const footer = item.querySelector('.sub-territory-item-footer');
        if (!footer) return;

        if (isEditing) {
            // Mostrar botões de ferramentas de edição
            footer.innerHTML = `
                <button class="btn-footer-action btn-lasso" 
                        onclick="window.app.uiController.handleLassoDelete()"
                        title="Deletar Pontos em Massa (Laço)">
                    <i class="bi bi-lasso"></i>
                    <span>Deletar Pontos</span>
                </button>
                <button class="btn-footer-action btn-save-edit" 
                        onclick="window.app.uiController.handleSaveSubTerritoryEdit()"
                        title="Salvar Alterações">
                    <i class="bi bi-check-circle"></i>
                    <span>Salvar</span>
                </button>
                <button class="btn-footer-action btn-cancel-edit" 
                        onclick="window.app.uiController.handleCancelSubTerritoryEdit()"
                        title="Cancelar Edição">
                    <i class="bi bi-x-circle"></i>
                    <span>Cancelar</span>
                </button>
            `;
        } else {
            // Mostrar botões padrão (editar/excluir)
            const subT = this.currentSubTerritory;
            if (!subT) return;

            footer.innerHTML = `
                <button class="btn-footer-action btn-edit" 
                        data-sub-territory-id="${subT.id}"
                        data-territory-id="${subT.territory_id}"
                        data-carteira-id="${subT.carteira_id}"
                        title="Editar Carteira">
                    <i class="bi bi-pencil"></i>
                    <span>Editar</span>
                </button>
                <button class="btn-footer-action btn-delete" 
                        data-sub-territory-id="${subT.id}"
                        data-territory-id="${subT.territory_id}"
                        data-carteira-id="${subT.carteira_id}"
                        title="Excluir Carteira">
                    <i class="bi bi-trash"></i>
                    <span>Excluir</span>
                </button>
            `;
        }
    }

    /**
     * Atualiza/recarrega um território com seus sub-territórios
     * @param {String} territoryId - ID do território
     */
    async refreshTerritory(territoryId) {
        try {
            console.log('🔄 Atualizando território:', territoryId);
            
            const territory = await this.dataManager.getTerritoryWithSubTerritories(territoryId);
            
            if (!territory) {
                console.warn('⚠️ Território não encontrado');
                return;
            }

            // Limpar TODAS as camadas (polígonos, desenhos, CAR, etc.)
            console.log('🧹 Limpando todas as camadas do mapa...');
            this.map.clearLayer('polygons');
            this.map.clearLayer('drawings');
            this.map.clearLayer('car');
            
            // Aguardar um momento para garantir limpeza
            await new Promise(resolve => setTimeout(resolve, 100));
            
            // Adicionar apenas o território pai no mapa (sem modo de edição)
            const parentLayer = L.geoJSON(territory.geometry, {
                style: {
                    color: this.map.territoryColors.territory,
                    fillColor: this.map.territoryColors.territoryFill,
                    weight: 3,
                    fillOpacity: 0.25
                }
            }).addTo(this.map.layers.polygons);
            
            console.log('✅ Território pai renderizado');
            
            // Se houver sub-territórios, renderizar todos
            if (territory.subTerritories && territory.subTerritories.length > 0) {
                console.log(`🟠 Renderizando ${territory.subTerritories.length} sub-territórios...`);
                
                territory.subTerritories.forEach(subT => {
                    const subGeometry = typeof subT.geometry === 'string' 
                        ? JSON.parse(subT.geometry) 
                        : subT.geometry;
                    
                    const colors = this.map.territoryColors;
                    L.geoJSON(subGeometry, {
                        style: {
                            color: colors.subTerritory,
                            fillColor: colors.subTerritoryFill,
                            weight: 2,
                            fillOpacity: 0.25
                        }
                    }).addTo(this.map.layers.polygons);
                });
                
                console.log('✅ Sub-territórios renderizados');
            }
            
            // Centralizar mapa no território pai
            this.map.map.fitBounds(parentLayer.getBounds(), { 
                padding: [50, 50],
                maxZoom: 15
            });
            
            // Atualizar árvore
            await this.loadRegionsTree();
            
            this.showNotification('Território atualizado com sucesso', 'success');

        } catch (error) {
            console.error('❌ Erro ao atualizar território:', error);
            this.showNotification('Erro ao atualizar território', 'error');
        }
    }

    /**
     * Mostra notificação
     */
    showNotification(message, type = 'info') {
        // Criar elemento de notificação
        const notification = document.createElement('div');
        notification.className = `alert alert-${this.getBootstrapAlertClass(type)} notification`;
        notification.innerHTML = message;
        notification.style.cssText = `
            position: fixed;
            top: 70px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideIn 0.3s ease-out;
        `;

        document.body.appendChild(notification);

        // Remover após 3 segundos
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => notification.remove(), 300);
        }, CONFIG.ui.notifications.duration);
    }

    /**
     * Converte tipo para classe Bootstrap
     */
    getBootstrapAlertClass(type) {
        const map = {
            'info': 'info',
            'success': 'success',
            'warning': 'warning',
            'error': 'danger'
        };
        return map[type] || 'info';
    }

    /**
     * Define o modo de visualização (interno)
     * @param {string} mode - 'consultor' ou 'unidade'
     * @param {string} centerKey - Chave do centro (opcional, usa this.currentCenterKey se não fornecido)
     */
    async setViewMode(mode, centerKey = null) {
        try {
            const key = centerKey || this.currentCenterKey;
            
            if (!key) {
                console.warn('⚠️ setViewMode: Nenhum centro selecionado');
                return;
            }

            this.viewMode = mode;

            const btnToggleViewMode = document.getElementById('btnToggleViewMode');
            const legendTitle = document.getElementById('legendTitle');

            if (mode === 'unidade') {
                // Modo Unidade
                console.log('🏢 Ativando modo Unidade');
                
                if (btnToggleViewMode) {
                    btnToggleViewMode.innerHTML = '<i class="bi bi-person"></i> Consultor';
                    btnToggleViewMode.title = 'Alternar para visualização por Consultor';
                }
                
                if (legendTitle) {
                    legendTitle.textContent = 'Unidades (Centros)';
                }

                // Carregar áreas por unidade
                await this.map.loadAreasByUnidade(key);
                
            } else {
                // Modo Consultor
                console.log('👤 Ativando modo Consultor');
                
                if (btnToggleViewMode) {
                    btnToggleViewMode.innerHTML = '<i class="bi bi-building"></i> Unidade';
                    btnToggleViewMode.title = 'Alternar para visualização por Unidade';
                }
                
                if (legendTitle) {
                    legendTitle.textContent = 'Consultores';
                }

                // Carregar áreas por consultor
                await this.map.loadAreasByConsultor(key);
            }

        } catch (error) {
            console.error('❌ Erro ao definir modo de visualização:', error);
        }
    }

    /**
     * Alterna entre modo de visualização por Consultor e por Unidade
     */
    async toggleViewMode() {
        try {
            // Verificar se há um centro selecionado
            if (!this.currentCenterKey) {
                this.showNotification('Selecione um centro primeiro', 'warning');
                return;
            }

            // Alternar estado
            const newMode = this.viewMode === 'consultor' ? 'unidade' : 'consultor';
            
            await this.setViewMode(newMode);

            // Notificar usuário
            if (newMode === 'unidade') {
                this.showNotification('Visualização por Unidade ativada', 'success');
            } else {
                this.showNotification('Visualização por Consultor ativada', 'success');
            }

        } catch (error) {
            console.error('❌ Erro ao alternar modo de visualização:', error);
            this.showNotification('Erro ao alternar modo de visualização', 'error');
        }
    }

    /**
     * Toggle de Áreas por Unidade via checkbox do header
     * @param {boolean} enabled - Se deve mostrar ou ocultar as áreas
     */
    async toggleAreasUnidade(enabled) {
        try {
            if (!this.map) {
                console.warn('⚠️ Mapa não inicializado');
                return;
            }

            if (enabled) {
                // Verificar se há um centro selecionado
                if (!this.currentCenterKey) {
                    this.showNotification('Selecione um centro primeiro para visualizar áreas', 'info');
                    // Desmarcar checkbox
                    const chk = document.getElementById('chkAreasUnidade');
                    if (chk) chk.checked = false;
                    return;
                }

                // Carregar áreas por unidade
                console.log(`🏢 Ativando áreas por unidade para: ${this.currentCenterKey}`);
                await this.map.loadAreasByUnidade(this.currentCenterKey);

                // Mostrar legenda
                const legend = document.getElementById('consultorLegend');
                if (legend) legend.style.display = 'block';

                this.showNotification('Áreas por Unidade ativadas', 'success');
            } else {
                // Limpar camada de áreas
                console.log('🏢 Desativando áreas por unidade');
                if (this.map.layers && this.map.layers.consultores) {
                    this.map.layers.consultores.clearLayers();
                }

                // Ocultar legenda
                const legend = document.getElementById('consultorLegend');
                if (legend) legend.style.display = 'none';

                this.showNotification('Áreas por Unidade desativadas', 'info');
            }
        } catch (error) {
            console.error('❌ Erro ao alternar áreas por unidade:', error);
            this.showNotification('Erro ao carregar áreas', 'error');
        }
    }
}

// Export
window.UIController = UIController;

// Adicionar animações CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(400px); opacity: 0; }
    }
`;
document.head.appendChild(style);
