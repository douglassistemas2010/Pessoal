/**
 * Territory Wizard Controller
 * MapCarteiras v2.0
 * 
 * Controla o fluxo do assistente de ajuste de território em 4 etapas:
 * STEP 0: Ajuste Manual (opcional, edição de vértices)
 * STEP 1: Ajuste ao CAR (Expansão para território / Interseção para sub-território)
 * STEP 2: Simplificação de Polígono
 * STEP 3: Recorte de Sobreposição
 * STEP 4: Confirmação Final
 * 
 * CONTEXTOS SUPORTADOS:
 * - 'territory': Ajuste com UNIÃO (expande para cobrir CARs)
 * - 'sub-territory': Ajuste com INTERSEÇÃO (segue contornos do CAR)
 */

class TerritoryWizard {
    constructor(context = 'territory', parentTerritory = null) {
        console.log('🔧 DEBUG - Construtor TerritoryWizard chamado');
        console.log('🔧 DEBUG - Parâmetro context recebido:', context);
        console.log('🔧 DEBUG - Parâmetro parentTerritory recebido:', parentTerritory);
        
        this.currentStep = 0;  // COMEÇA NO STEP 0
        this.totalSteps = 5;   // AGORA SÃO 5 STEPS (0, 1, 2, 3, 4)
        
        // CONTEXTO: 'territory' ou 'sub-territory'
        this.context = context;
        this.parentTerritory = parentTerritory; // Para sub-territórios
        
        console.log('🔧 DEBUG - this.context definido como:', this.context);
        console.log('🔧 DEBUG - this.parentTerritory definido como:', this.parentTerritory);
        
        // Dados do wizard
        this.data = {
            originalLayer: null,
            originalGeoJSON: null,
            manuallyAdjustedGeoJSON: null,  // NOVO: Geometria após ajuste manual (STEP 0)
            carAdjustedGeoJSON: null,
            trimmedGeoJSON: null,
            finalGeoJSON: null,
            
            carFeatures: [],
            overlapTerritories: [],
            
            skipCAR: false,
            skipTrim: false,
            isEditingManually: false  // NOVO: Flag para modo de edição
        };
        
        // Preview layers no mapa
        this.previewLayers = {
            original: null,
            adjusted: null,
            markers: []
        };
        
        console.log(`✅ Territory Wizard inicializado - Contexto: ${this.context}`);
    }

    /**
     * Abre o wizard com o polígono desenhado
     */
    async open(layer, overlapResult) {
        try {
            console.log(`🧙 Abrindo Territory Wizard - Contexto: ${this.context}...`);
            
            // Resetar wizard
            this.reset();
            
            // Salvar dados iniciais
            this.data.originalLayer = layer;
            this.data.originalGeoJSON = layer.toGeoJSON();
            this.data.overlapTerritories = overlapResult?.overlappedTerritories || [];
            
            // Centralizar mapa no polígono
            this.centerMapOnPolygon(layer);
            
            // SEMPRE USAR O MESMO MODAL (modalTerritoryWizard)
            // Alterar título e comportamento baseado no contexto
            const modalId = 'modalTerritoryWizard';
            const modalTitleElement = document.getElementById('modalTerritoryWizardTitle');
            
            if (this.context === 'sub-territory') {
                console.log('🎯 Configurando modal para SUB-TERRITÓRIO');
                if (modalTitleElement) {
                    modalTitleElement.innerHTML = '<i class="bi bi-diagram-3 me-2"></i>Assistente de Sub-Território (Carteira)';
                }
            } else {
                console.log('🎯 Configurando modal para TERRITÓRIO');
                if (modalTitleElement) {
                    modalTitleElement.innerHTML = '<i class="bi bi-geo-alt me-2"></i>Assistente de Território';
                }
            }
            
            const modal = new bootstrap.Modal(document.getElementById(modalId));
            modal.show();
            
            // Ir para Step 0 (Ajuste Manual) - NOVO FLUXO
            this.goToStep(0);
            this.loadManualAdjustStep();
            
        } catch (error) {
            console.error('❌ Erro ao abrir wizard:', error);
        }
    }

    /**
     * STEP 0: Ajuste Manual
     */
    loadManualAdjustStep() {
        console.log('📝 Carregando ajuste manual...');
        
        // Calcular área e vértices
        const area = window.app.map.calculateArea(this.data.originalLayer);
        const vertices = this.data.originalLayer.getLatLngs()[0].length;
        
        // Atualizar UI
        document.getElementById('step0Area').textContent = `${area.toFixed(2)} ha`;
        document.getElementById('step0Vertices').textContent = vertices;
        
        // Configurar botões de edição
        this.setupManualEditButtons();
        
        console.log('✅ STEP 0 carregado');
    }

    /**
     * Configurar botões de edição manual
     */
    setupManualEditButtons() {
        const btnEditVertices = document.getElementById('btnEditPolygonVertices');
        const btnRedraw = document.getElementById('btnRedrawPolygon');
        
        if (btnEditVertices) {
            btnEditVertices.onclick = () => {
                console.log('✏️ Iniciando edição de vértices...');
                this.enableVertexEditing();
            };
        }
        
        if (btnRedraw) {
            btnRedraw.onclick = () => {
                console.log('🔄 Redesenhando polígono...');
                this.redrawPolygon();
            };
        }
    }

    /**
     * Habilitar edição de vértices
     */
    enableVertexEditing() {
        if (!this.data.originalLayer || !this.data.originalLayer.editing) {
            console.error('❌ Layer não tem editing habilitado');
            return;
        }
        
        // Habilitar edição
        this.data.originalLayer.editing.enable();
        this.data.isEditingManually = true;
        
        // Mudar botão
        const btn = document.getElementById('btnEditPolygonVertices');
        btn.innerHTML = '<i class="bi bi-check2 me-2"></i><span>Finalizar Edição</span>';
        btn.classList.remove('btn-outline-primary');
        btn.classList.add('btn-success');
        
        btn.onclick = () => {
            this.finishVertexEditing();
        };
        
        console.log('✅ Edição de vértices habilitada');
    }

    /**
     * Finalizar edição de vértices
     */
    finishVertexEditing() {
        if (!this.data.originalLayer) return;
        
        // Desabilitar edição
        this.data.originalLayer.editing.disable();
        this.data.isEditingManually = false;
        
        // Atualizar informações
        const area = window.app.map.calculateArea(this.data.originalLayer);
        const vertices = this.data.originalLayer.getLatLngs()[0].length;
        
        document.getElementById('step0Area').textContent = `${area.toFixed(2)} ha`;
        document.getElementById('step0Vertices').textContent = vertices;
        
        // Restaurar botão
        const btn = document.getElementById('btnEditPolygonVertices');
        btn.innerHTML = '<i class="bi bi-node-plus me-2"></i><span>Editar Vértices</span>';
        btn.classList.remove('btn-success');
        btn.classList.add('btn-outline-primary');
        
        btn.onclick = () => {
            this.enableVertexEditing();
        };
        
        console.log('✅ Edição de vértices finalizada');
    }

    /**
     * Redesenhar polígono do zero
     */
    redrawPolygon() {
        // Confirmar ação
        if (!confirm('⚠️ Tem certeza que deseja apagar e redesenhar? Isso não pode ser desfeito.')) {
            return;
        }
        
        // Fechar wizard
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalTerritoryWizard'));
        if (modal) {
            modal.hide();
        }
        
        // Remover layer atual
        if (this.data.originalLayer) {
            window.app.map.layers.editableLayers.removeLayer(this.data.originalLayer);
        }
        
        // Iniciar novo desenho
        const drawControl = window.app.map.drawControl;
        if (drawControl && drawControl._toolbars && drawControl._toolbars.draw) {
            const polygonDrawer = drawControl._toolbars.draw._modes.polygon;
            if (polygonDrawer && polygonDrawer.handler) {
                polygonDrawer.handler.enable();
                console.log('✅ Modo de desenho ativado');
            }
        }
    }

    /**
     * Centraliza o mapa no polígono
     */
    centerMapOnPolygon(layer) {
        try {
            const bounds = layer.getBounds();
            window.app.map.map.fitBounds(bounds, {
                padding: [100, 100],
                maxZoom: 15,
                animate: true,
                duration: 0.5
            });
            console.log('📍 Mapa centralizado no polígono');
        } catch (error) {
            console.warn('⚠️ Erro ao centralizar mapa:', error);
        }
    }

    /**
     * Reseta o wizard
     */
    reset() {
        this.currentStep = 0;  // Resetar para STEP 0
        this.data = {
            originalLayer: null,
            originalGeoJSON: null,
            manuallyAdjustedGeoJSON: null,  // Novo campo
            carAdjustedGeoJSON: null,
            trimmedGeoJSON: null,
            finalGeoJSON: null,
            carFeatures: [],
            overlapTerritories: [],
            skipCAR: false,
            skipTrim: false,
            isEditingManually: false  // Novo campo
        };
        this.clearPreviews();
    }

    /**
     * Navega para uma etapa específica
     */
    goToStep(step) {
        console.log(`📍 Navegando para Step ${step} (Contexto: ${this.context})`);
        
        this.currentStep = step;
        
        // SEMPRE USAR IDs DO MODAL DE TERRITÓRIO (modal único)
        // Ocultar todos os steps
        document.querySelectorAll('.wizard-step').forEach(el => el.style.display = 'none');
        
        // Mostrar step atual
        const stepId = `wizardStep${step}`;
        const stepElement = document.getElementById(stepId);
        
        if (stepElement) {
            stepElement.style.display = 'block';
        } else {
            console.error(`❌ Elemento ${stepId} não encontrado!`);
        }
        
        // Atualizar indicadores
        this.updateStepIndicators();
        
        // Atualizar botões
        this.updateButtons();
    }

    /**
     * Helper para pegar elemento correto baseado no contexto
     * Território usa IDs como: carLoadingState, stepIndicator1, wizardStep1
     * Sub-território usa IDs como: subStep1Status, subStepIndicator1, subStep1
     */
    getContextElement(baseId) {
        // Se for sub-território e o ID não começar com 'sub', tentar variações
        if (this.context === 'sub-territory') {
            // Tentar primeiro com prefixo sub
            let element = document.getElementById(`sub${baseId.charAt(0).toUpperCase() + baseId.slice(1)}`);
            if (element) return element;
            
            // Tentar com o ID direto (pode já ter o prefixo)
            element = document.getElementById(baseId);
            if (element) return element;
        }
        
        // Território ou fallback
        return document.getElementById(baseId);
    }

    /**
     * Atualiza os indicadores visuais do stepper
     */
    updateStepIndicators() {
        // Atualizar indicadores de STEP 0 a STEP 3
        const indicatorPrefix = 'stepIndicator';
        
        for (let i = 0; i <= 3; i++) {  // Mudado para começar em 0
            const indicator = document.getElementById(`${indicatorPrefix}${i}`);
            
            if (!indicator) {
                console.warn(`⚠️ Indicador ${indicatorPrefix}${i} não encontrado`);
                continue;
            }
            
            const circle = indicator.querySelector('.step-circle');
            
            if (i < this.currentStep) {
                // Step completado
                indicator.classList.remove('active');
                circle.classList.remove('active');
                circle.classList.add('completed');
                circle.textContent = '';
            } else if (i === this.currentStep) {
                // Step atual
                indicator.classList.add('active');
                circle.classList.add('active');
                circle.classList.remove('completed');
                circle.textContent = i;
            } else {
                // Step futuro
                indicator.classList.remove('active');
                circle.classList.remove('active', 'completed');
                circle.textContent = i;
            }
        }
    }

    /**
     * Atualiza a visibilidade dos botões conforme o step
     */
    updateButtons() {
        const btnPrev = document.getElementById('btnWizardPrev');
        const btnNext = document.getElementById('btnWizardNext');
        const btnSkip = document.getElementById('btnWizardSkip');
        const btnSave = document.getElementById('btnWizardSave');
        
        // Botão Voltar (apenas se não for STEP 0)
        btnPrev.style.display = this.currentStep > 0 ? 'inline-block' : 'none';
        
        // STEP 0: Botão "Buscar CARs"
        if (this.currentStep === 0) {
            btnNext.textContent = '🔍 Buscar CARs';
            btnNext.innerHTML = '<i class="bi bi-search me-2"></i>Buscar CARs e Continuar';
            btnSkip.style.display = 'inline-block';  // Permitir pular CAR
            btnSkip.textContent = 'Pular CAR';
            btnSkip.innerHTML = '<i class="bi bi-skip-forward me-1"></i>Pular CAR';
            btnNext.style.display = 'inline-block';
            btnSave.style.display = 'none';
        }
        // Botões no último step
        else if (this.currentStep === 4) {  // Step 4 agora é o último (Confirmação Final)
            btnNext.style.display = 'none';
            btnSkip.style.display = 'none';
            btnSave.style.display = 'inline-block';
        } else {
            // Steps intermediários (1, 2, 3)
            btnNext.innerHTML = 'Próximo <i class="bi bi-arrow-right ms-1"></i>';
            btnNext.style.display = 'inline-block';
            btnSave.style.display = 'none';
            
            // Botão Skip apenas no Step 1 (CAR)
            btnSkip.style.display = this.currentStep === 1 ? 'inline-block' : 'none';
            if (this.currentStep === 1) {
                btnSkip.innerHTML = '<i class="bi bi-skip-forward me-1"></i>Pular';
            }
        }
    }

    /**
     * STEP 1: Carregar e ajustar ao CAR
     */
    async loadCARStep() {
        try {
            console.log('🗺️ Carregando CAR...');
            console.log('🔍 DEBUG - Contexto atual:', this.context);
            console.log('🔍 DEBUG - Território pai:', this.parentTerritory);
            
            // Verificar se servidor CAR está disponível
            const carServerDown = window.app.carIntegration.wfsAvailable === false;
            if (carServerDown) {
                console.warn('⚠️ Servidor CAR indisponível - pulando etapa CAR');
            }
            
            // Mostrar loading
            document.getElementById('carLoadingState').style.display = 'block';
            document.getElementById('carContentState').style.display = 'none';
            document.getElementById('carNoDataState').style.display = 'none';
            
            // Atualizar mensagem de loading baseado no status do servidor
            if (carServerDown) {
                document.getElementById('carLoadingMessage').innerHTML = `
                    <i class="bi bi-exclamation-triangle-fill text-warning me-2"></i>
                    Servidor CAR Indisponível
                `;
                document.getElementById('carLoadingDetails').textContent = 'Verificando disponibilidade do servidor CAR...';
            }
            
            // Preencher área original
            const originalArea = window.app.polygonTools.calculateArea(this.data.originalLayer);
            const originalVertices = this.data.originalGeoJSON.geometry.coordinates[0].length - 1;
            
            document.getElementById('carOriginalArea').textContent = `${originalArea.toFixed(2)} ha`;
            document.getElementById('carOriginalVertices').textContent = originalVertices;
            
            // Detectar estado
            const state = window.app.carIntegration.detectStateFromPolygon(this.data.originalLayer);
            
            // Callback para atualizar progresso na interface
            const progressCallback = (message) => {
                document.getElementById('carLoadingDetails').textContent = message;
            };
            
            // Carregar CAR features
            console.log('⏳ Aguardando carregamento de CAR features...');
            const features = await window.app.carIntegration.loadCARForPolygon(
                this.data.originalLayer, 
                state,
                progressCallback
            );
            
            console.log(`📦 CAR features carregadas: ${features ? features.length : 0}`);
            
            if (!features || features.length === 0) {
                // Verificar se é por servidor indisponível ou área sem CAR
                const carServerDown = window.app.carIntegration.wfsAvailable === false;
                
                if (carServerDown) {
                    console.error('❌ Servidor CAR está indisponível');
                    document.getElementById('carLoadingState').style.display = 'none';
                    document.getElementById('carNoDataState').style.display = 'block';
                    
                    // Atualizar mensagem para indicar que servidor está DOWN
                    const noDataText = document.querySelector('#carNoDataState p');
                    if (noDataText) {
                        noDataText.innerHTML = `
                            <i class="bi bi-exclamation-triangle-fill text-warning me-2"></i>
                            <strong>Servidor CAR Indisponível</strong><br>
                            <small class="text-muted">
                                O servidor do CAR (geoserver.car.gov.br) não está respondendo no momento.<br>
                                Você pode continuar sem o ajuste automático ao CAR.
                            </small>
                        `;
                    }
                } else {
                    console.warn('⚠️ Nenhum CAR encontrado para este polígono');
                    document.getElementById('carLoadingState').style.display = 'none';
                    document.getElementById('carNoDataState').style.display = 'block';
                    
                    // Mensagem padrão - área sem CARs
                    const noDataText = document.querySelector('#carNoDataState p');
                    if (noDataText) {
                        noDataText.innerHTML = `
                            <i class="bi bi-info-circle-fill text-info me-2"></i>
                            Nenhum imóvel CAR encontrado nesta área.<br>
                            <small class="text-muted">Continue para o próximo passo.</small>
                        `;
                    }
                }
                return;
            }
            
            this.data.carFeatures = features;
            document.getElementById('carCount').textContent = features.length;
            
            // Atualizar mensagem de loading
            document.getElementById('carLoadingMessage').textContent = 'Processando ajuste ao CAR...';
            document.getElementById('carLoadingDetails').textContent = `Unindo território com ${features.length} imóveis CAR...`;
            
            // APLICAR AJUSTE BASEADO NO CONTEXTO
            let adjusted;
            
            console.log('🎯 DEBUG - Verificando contexto para escolher método CAR...');
            console.log('🎯 DEBUG - this.context ===', this.context);
            console.log('🎯 DEBUG - this.context === "sub-territory"?', this.context === 'sub-territory');
            
            if (this.context === 'sub-territory') {
                // SUB-TERRITÓRIO: Usar UNIÃO para expandir seguindo CARs externos
                // NOTA: Corte dentro do território pai acontece no STEP 2
                console.log('✅ Contexto: SUB-TERRITÓRIO - Aplicando UNIÃO com CARs externos...');
                
                adjusted = await window.app.carIntegration.adjustSubTerritoryToCAR(
                    this.data.originalLayer,
                    features
                );
            } else {
                // TERRITÓRIO: Usar UNIÃO para expandir e cobrir CARs
                console.log('✅ Contexto: TERRITÓRIO - Aplicando UNIÃO com CAR...');
                adjusted = await window.app.carIntegration.adjustPolygonToCAR(
                    this.data.originalLayer,
                    features
                );
            }
            
            if (!adjusted) {
                console.warn('⚠️ Falha ao ajustar ao CAR');
                document.getElementById('carLoadingState').style.display = 'none';
                document.getElementById('carNoDataState').style.display = 'block';
                return;
            }
            
            // REMOVER BURACOS DO POLÍGONO - Garantir polígono válido
            console.log('🕳️ Verificando e removendo buracos do polígono...');
            const holesBefore = window.app.polygonTools.countHoles(adjusted);
            
            if (holesBefore > 0) {
                console.log(`⚠️ Encontrados ${holesBefore} buraco(s) no polígono. Removendo...`);
                adjusted = window.app.polygonTools.removeHoles(adjusted);
                console.log('✅ Buracos removidos com sucesso');
            } else {
                console.log('✅ Polígono sem buracos');
            }
            
            // SIMPLIFICAR POLÍGONO - Reduzir vértices desnecessários
            console.log('✂️ Simplificando polígono com turf.simplify...');
            const verticesBefore = adjusted.geometry.coordinates[0].length - 1;
            console.log(`   📊 Vértices antes: ${verticesBefore}`);
            
            try {
                adjusted = turf.simplify(adjusted, {
                    tolerance: 0.00005,    // ~5 metros de tolerância
                    highQuality: true,      // Usa algoritmo Ramer-Douglas-Peucker
                    mutate: false
                });
                
                const verticesAfter = adjusted.geometry.coordinates[0].length - 1;
                const reduction = ((verticesBefore - verticesAfter) / verticesBefore * 100).toFixed(1);
                console.log(`   📊 Vértices depois: ${verticesAfter} (redução de ${reduction}%)`);
                console.log('   ✅ Simplificação concluída');
            } catch (error) {
                console.warn('⚠️ Erro ao simplificar polígono:', error);
                console.warn('   Continuando com polígono original...');
            }
            
            // Salvar resultado (adjusted já é um GeoJSON Feature)
            this.data.carAdjustedGeoJSON = adjusted;
            
            // VALIDAÇÃO CRÍTICA: Verificar se foi salvo
            console.log('🔍 DEBUG PÓS-CAR-AJUSTE - adjusted:', adjusted);
            console.log('🔍 DEBUG PÓS-CAR-AJUSTE - adjusted.type:', adjusted?.type);
            console.log('🔍 DEBUG PÓS-CAR-AJUSTE - adjusted.geometry?.type:', adjusted?.geometry?.type);
            console.log('🔍 DEBUG PÓS-CAR-AJUSTE - this.data.carAdjustedGeoJSON:', this.data.carAdjustedGeoJSON);
            console.log('🔍 DEBUG PÓS-CAR-AJUSTE - this.data.carAdjustedGeoJSON === adjusted?', this.data.carAdjustedGeoJSON === adjusted);
            
            // Preencher área ajustada
            const adjustedArea = window.app.polygonTools.calculateArea(adjusted);
            const adjustedVertices = this.data.carAdjustedGeoJSON.geometry.coordinates[0].length - 1;
            
            document.getElementById('carAdjustedArea').textContent = `${adjustedArea.toFixed(2)} ha`;
            document.getElementById('carAdjustedVertices').textContent = adjustedVertices;
            
            // Mostrar preview no mapa
            this.showCARPreview(adjusted);
            
            // Centralizar mapa no polígono ajustado
            const tempLayer = L.geoJSON(adjusted);
            this.centerMapOnPolygon(tempLayer);
            
            // Ocultar loading, mostrar conteúdo
            document.getElementById('carLoadingState').style.display = 'none';
            document.getElementById('carContentState').style.display = 'block';

            console.log('✅ CAR carregado e ajustado');
            
        } catch (error) {
            console.error('❌ Erro no carregamento do CAR:', error);
            document.getElementById('carLoadingState').style.display = 'none';
            document.getElementById('carNoDataState').style.display = 'block';
        }
    }

    /**
     * STEP 2: Carregar simplificação de polígono
     */
    async loadSimplifyStep() {
        console.log('📐 Carregando STEP 2: Simplificação...');
        
        try {
            // Usar polígono na seguinte ordem de prioridade:
            // 1. CAR ajustado (se foi feito)
            // 2. Manualmente ajustado no STEP 0
            // 3. Original
            let polygonToSimplify = this.data.finalGeoJSON ||
                                    this.data.carAdjustedGeoJSON || 
                                    this.data.manuallyAdjustedGeoJSON || 
                                    this.data.originalGeoJSON;
            
            console.log('🔍 Polígono para simplificar:', polygonToSimplify);
            
            // Atualizar informações do card
            if (polygonToSimplify) {
                const tempLayer = L.geoJSON(polygonToSimplify);
                const area = window.app.polygonTools.calculateArea(tempLayer.getLayers()[0]);
                
                const geometry = polygonToSimplify.geometry || polygonToSimplify;
                let vertices = 0;
                
                if (geometry.type === 'Polygon') {
                    vertices = geometry.coordinates[0].length - 1;
                } else if (geometry.type === 'MultiPolygon') {
                    vertices = geometry.coordinates.reduce((sum, polygon) => 
                        sum + (polygon[0].length - 1), 0);
                }
                
                const areaElement = document.getElementById('simplifyArea');
                const verticesElement = document.getElementById('simplifyVertices');
                
                if (areaElement) areaElement.textContent = `${area.toFixed(2)} ha`;
                if (verticesElement) verticesElement.textContent = vertices.toLocaleString('pt-BR');
                
                console.log(`✅ Info atualizada - Área: ${area.toFixed(2)} ha, Vértices: ${vertices}`);
            }
            
            // Configurar botão de fechamento morfológico
            setTimeout(() => {
                this.setupClosingButton();
            }, 150);
            
        } catch (error) {
            console.error('❌ Erro ao carregar STEP 2:', error);
        }
    }

    /**
     * STEP 3: Verificar e aplicar recorte de sobreposição
     */
    async loadOverlapStep() {
        try {
            console.log('✂️ Verificando sobreposição...');
            
            // Usar polígono na seguinte ordem de prioridade:
            // 1. Simplificado no STEP 2 (finalGeoJSON)
            // 2. CAR ajustado (se foi feito)
            // 3. Manualmente ajustado no STEP 0
            // 4. Original
            let polygonToCheck = this.data.finalGeoJSON ||
                                 this.data.carAdjustedGeoJSON || 
                                 this.data.manuallyAdjustedGeoJSON || 
                                 this.data.originalGeoJSON;
            
            console.log('🔍 DEBUG INICIAL - polygonToCheck:', polygonToCheck);
            console.log('🔍 DEBUG INICIAL - Fonte:', 
                this.data.finalGeoJSON ? 'Simplificado (STEP 2)' :
                this.data.carAdjustedGeoJSON ? 'CAR' : 
                this.data.manuallyAdjustedGeoJSON ? 'Manual (STEP 0)' : 'Original');
            
            // ⭐ ATUALIZAR CARD IMEDIATAMENTE com os dados do polígono inicial
            console.log('📊 Atualizando card do STEP 3 com polígono simplificado...');
            setTimeout(() => {
                this.updateFinalPolygonInfo(polygonToCheck);
            }, 500); // Delay maior para garantir renderização do modal
            console.log('🔍 DEBUG INICIAL - polygonToCheck TYPE:', typeof polygonToCheck);
            console.log('🔍 DEBUG INICIAL - polygonToCheck.type:', polygonToCheck?.type);
            console.log('🔍 DEBUG INICIAL - polygonToCheck.geometry?.type:', polygonToCheck?.geometry?.type);
            
            // ================================================================
            // SUB-TERRITÓRIO: CORTAR dentro do território pai PRIMEIRO
            // ================================================================
            if (this.context === 'sub-territory' && this.parentTerritory) {
                console.log('✂️ SUB-TERRITÓRIO: Cortando dentro do território pai...');
                console.log('🔍 DEBUG - parentTerritory TYPE:', typeof this.parentTerritory);
                console.log('🔍 DEBUG - parentTerritory KEYS:', Object.keys(this.parentTerritory));
                console.log('🔍 DEBUG - parentTerritory.geometry:', this.parentTerritory.geometry);
                console.log('🔍 DEBUG - polygonToCheck TYPE:', typeof polygonToCheck);
                console.log('🔍 DEBUG - polygonToCheck.type:', polygonToCheck.type);
                console.log('🔍 DEBUG - polygonToCheck.geometry:', polygonToCheck.geometry);
                
                // CORREÇÃO CRÍTICA: Se for MultiPolygon, UNIR fragmentos antes do intersect
                if (polygonToCheck && polygonToCheck.geometry && polygonToCheck.geometry.type === 'MultiPolygon') {
                    console.warn('⚠️ MultiPolygon detectado - UNINDO fragmentos antes do corte...');
                    
                    try {
                        // Usar turf.union() para unir todos os fragmentos em um único Polygon
                        let unified = polygonToCheck;
                        
                        // Iterar sobre cada fragmento e fazer união progressiva
                        const fragments = polygonToCheck.geometry.coordinates;
                        console.log(`   📦 Unindo ${fragments.length} fragmentos...`);
                        
                        for (let i = 1; i < fragments.length; i++) {
                            try {
                                const fragment = turf.polygon(fragments[i]);
                                unified = turf.union(unified, fragment);
                            } catch (err) {
                                console.warn(`   ⚠️ Erro ao unir fragmento ${i + 1}:`, err.message);
                            }
                        }
                        
                        // Substituir polygonToCheck pelo resultado unificado
                        polygonToCheck = unified;
                        console.log(`   ✅ MultiPolygon unificado: ${fragments.length} → ${polygonToCheck.geometry.type}`);
                        
                    } catch (err) {
                        console.error('❌ Erro ao unir fragmentos MultiPolygon:', err);
                        alert('❌ Erro ao processar geometria MultiPolygon!\n\nTente novamente com polígono mais simples.');
                        this.cancel();
                        return;
                    }
                }
                
                try {
                    const parentGeo = typeof this.parentTerritory === 'string'
                        ? JSON.parse(this.parentTerritory)
                        : (this.parentTerritory.geometry || this.parentTerritory);
                    
                    console.log('🔍 DEBUG - parentGeo extraído TYPE:', parentGeo.type);
                    console.log('🔍 DEBUG - parentGeo tem coordinates?', !!parentGeo.coordinates);
                    
                    const polygonFeature = polygonToCheck.type === 'Feature'
                        ? polygonToCheck
                        : turf.feature(polygonToCheck.geometry || polygonToCheck);
                    
                    // Extrair geometry pura do parent (pode ser Feature)
                    const parentGeometry = parentGeo.type === 'Feature' ? parentGeo.geometry : parentGeo;
                    const parentFeature = turf.feature(parentGeometry);
                    
                    console.log('🔍 DEBUG - polygonFeature.geometry.type:', polygonFeature.geometry.type);
                    console.log('🔍 DEBUG - parentFeature.geometry.type:', parentFeature.geometry.type);
                    
                    // Calcular área ANTES do corte
                    const areaBefore = turf.area(polygonFeature) / 10000; // hectares
                    const areaParent = turf.area(parentFeature) / 10000; // hectares
                    
                    console.log(`🔍 DEBUG - Área sub-território (expandido): ${areaBefore.toFixed(2)} ha`);
                    console.log(`🔍 DEBUG - Área território pai: ${areaParent.toFixed(2)} ha`);
                    console.log(`🔍 DEBUG - Sub > Pai? ${areaBefore > areaParent ? 'SIM ⚠️' : 'NÃO'}`);
                    console.log('🔍 Aplicando INTERSECT com território pai (obrigatório)...');
                    
                    // SEMPRE fazer INTERSEÇÃO com território pai (garante que está dentro)
                    const clipped = turf.intersect(polygonFeature, parentFeature);
                    
                    console.log('🔍 DEBUG - Resultado turf.intersect() TYPE:', typeof clipped);
                    console.log('🔍 DEBUG - Resultado turf.intersect() IS NULL?', clipped === null);
                    console.log('🔍 DEBUG - Resultado completo:', clipped);
                    
                    if (clipped && clipped.geometry) {
                        const areaAfter = turf.area(clipped) / 10000; // hectares
                        const diff = areaBefore - areaAfter;
                        
                        polygonToCheck = clipped;
                        console.log(`✅ Sub-território cortado dentro do território pai:`);
                        console.log(`   • Antes: ${areaBefore.toFixed(2)} ha`);
                        console.log(`   • Depois: ${areaAfter.toFixed(2)} ha`);
                        console.log(`   • Removido: ${diff.toFixed(2)} ha (${(diff / areaBefore * 100).toFixed(1)}%)`);
                    } else {
                        console.error('❌ ⚠️ INTERSEÇÃO RETORNOU NULL - Sub-território NÃO intersecta com território pai!');
                        console.error('   • CAUSA PROVÁVEL: Sub-território expandiu DEMAIS e saiu completamente fora do pai');
                        console.error(`   • Sub-território expandido: ${areaBefore.toFixed(2)} ha`);
                        console.error(`   • Território pai: ${areaParent.toFixed(2)} ha`);
                        console.error('   • Sub > Pai em área? SIM - pode ter expandido para fora');
                        console.error('   • turf.intersect() retornou:', clipped);
                        
                        // FALLBACK: Usar polígono ORIGINAL (não expandido) para corte
                        console.warn('🔄 FALLBACK: Tentando cortar polígono ORIGINAL (antes da expansão CAR)...');
                        const originalFeature = this.data.originalGeoJSON.type === 'Feature'
                            ? this.data.originalGeoJSON
                            : turf.feature(this.data.originalGeoJSON);
                        
                        const clippedOriginal = turf.intersect(originalFeature, parentFeature);
                        
                        if (clippedOriginal && clippedOriginal.geometry) {
                            console.log('✅ FALLBACK funcionou - usando polígono original cortado dentro do pai');
                            polygonToCheck = clippedOriginal;
                        } else {
                            console.error('❌ FALLBACK também falhou - polígono original também não intersecta com pai');
                            console.error('⚠️ PROBLEMA GRAVE: Usuário desenhou sub-território COMPLETAMENTE FORA do território pai!');
                            // polygonToCheck permanece com valor expandido (será detectado como inválido)
                        }
                    }
                } catch (e) {
                    console.error('❌ EXCEÇÃO ao cortar com território pai:', e.message);
                    console.error('   Stack:', e.stack);
                }
            }
            
            console.log('🔍 DEBUG - polygonToCheck FINAL após corte pai:', polygonToCheck);
            console.log('🔍 DEBUG - polygonToCheck.geometry existe?', !!(polygonToCheck && polygonToCheck.geometry));
            
            // ================================================================
            // VALIDAR polygonToCheck antes de continuar
            // ================================================================
            if (!polygonToCheck || !polygonToCheck.geometry) {
                console.error('❌ ❌ ❌ GEOMETRIA INVÁLIDA APÓS TODOS OS PROCESSAMENTOS');
                console.error('   • polygonToCheck:', polygonToCheck);
                console.error('   • Isso indica que:');
                console.error('     1. turf.intersect() retornou null (sub-território fora do pai)');
                console.error('     2. Fallback com polígono original também falhou');
                console.error('     3. Usuário desenhou sub-território completamente FORA do território pai');
                
                console.warn('⚠️ ÚLTIMO FALLBACK: Usando geometria expandida (sem corte) - mas vai falhar na verificação de sobreposição');
                polygonToCheck = this.data.carAdjustedGeoJSON || this.data.originalGeoJSON;
                
                // Se ainda for null, exibir erro e abortar
                if (!polygonToCheck || !polygonToCheck.geometry) {
                    alert('❌ ERRO CRÍTICO\n\nNão foi possível processar o polígono.\n\nO sub-território desenhado pode estar completamente fora do território pai.\n\nPor favor, redesenhe o sub-território DENTRO do território pai.');
                    this.cancel(); // CORRIGIDO: era this.close()
                    return;
                }
            }
            
            // ================================================================
            // Verificar sobreposição com outros territórios/sub-territórios
            // ================================================================
            
            // Buscar territórios existentes
            let existingGeometries = window.app.map.getExistingTerritoriesGeometries();
            
            // 🔧 CORREÇÃO CRÍTICA: Excluir território pai da verificação de sobreposição
            if (this.context === 'sub-territory' && this.parentTerritory) {
                const parentId = this.parentTerritory.id;
                const beforeCount = existingGeometries.length;
                
                console.log(`🔧 FILTRO ATIVADO - Excluindo território pai...`);
                console.log(`   • Parent ID: ${parentId}`);
                console.log(`   • Geometrias ANTES do filtro: ${beforeCount}`);
                existingGeometries.forEach(geo => {
                    console.log(`      - ${geo.properties.territory_id} (ID: ${geo.properties.id}, Tipo: ${geo.properties.type || 'N/A'})`);
                });
                
                existingGeometries = existingGeometries.filter(geo => {
                    const match = geo.properties.id === parentId;
                    if (match) {
                        console.log(`      ✂️ REMOVENDO: ${geo.properties.territory_id} (ID: ${geo.properties.id})`);
                    }
                    return !match; // Inverter lógica: retornar true para MANTER
                });
                
                console.log(`🔧 Sub-território: Território pai (${this.parentTerritory.territory_id}) EXCLUÍDO`);
                console.log(`   • Geometrias DEPOIS do filtro: ${existingGeometries.length}`);
                existingGeometries.forEach(geo => {
                    console.log(`      - ${geo.properties.territory_id} (ID: ${geo.properties.id})`);
                });
            }
            
            if (existingGeometries.length === 0) {
                // Sem territórios existentes para verificar sobreposição
                console.log('✅ Nenhum território existente para verificar sobreposição');
                
                // MAS para sub-território, já foi cortado dentro do pai acima
                // Então precisamos salvar esse corte E MOSTRAR PREVIEW!
                if (this.context === 'sub-territory' && this.parentTerritory) {
                    console.log('✅ Sub-território cortado dentro do território pai - mostrando preview');
                    
                    this.data.trimmedGeoJSON = polygonToCheck; // Salvar versão cortada
                    this.data.finalGeoJSON = polygonToCheck;
                    
                    // Mostrar preview do corte com território pai
                    const originalPolygon = this.data.carAdjustedGeoJSON || this.data.originalGeoJSON;
                    this.showTrimPreview(originalPolygon, polygonToCheck);
                    
                    // Atualizar informações do polígono final (com delay)
                    setTimeout(() => {
                        this.updateFinalPolygonInfo(polygonToCheck);
                    }, 300);
                    
                    // Mostrar "Nenhuma sobreposição" mas o preview estará visível
                    document.getElementById('overlapDetectedState').style.display = 'none';
                    document.getElementById('noOverlapState').style.display = 'block';
                } else {
                    // Território normal sem sobreposição
                    this.data.skipTrim = true;
                    this.data.finalGeoJSON = polygonToCheck;
                    
                    // Atualizar informações do polígono final (com delay)
                    setTimeout(() => {
                        this.updateFinalPolygonInfo(polygonToCheck);
                    }, 300);
                    
                    document.getElementById('overlapDetectedState').style.display = 'none';
                    document.getElementById('noOverlapState').style.display = 'block';
                }
                
                return;
            }
            
            // ================================================================
            // VALIDAÇÃO CRÍTICA: polygonToCheck deve ser válido ANTES de checkOverlap
            // ================================================================
            console.log('🔍 Validando polygonToCheck antes de checkOverlap...');
            console.log('   • polygonToCheck:', polygonToCheck);
            console.log('   • Tipo:', polygonToCheck ? polygonToCheck.type : 'undefined');
            console.log('   • Geometry:', polygonToCheck ? polygonToCheck.geometry : 'undefined');
            
            if (!polygonToCheck || !polygonToCheck.geometry) {
                console.error('❌ ERRO: polygonToCheck inválido antes de checkOverlap');
                console.error('   • Não é possível verificar sobreposição com geometria null');
                console.error('   • Abortando Step 2...');
                
                alert('❌ ERRO\n\nNão foi possível processar o polígono para verificação de sobreposição.\n\nO polígono pode estar completamente fora do território pai.\n\nPor favor, redesenhe o sub-território DENTRO do território pai.');
                this.cancel(); // CORRIGIDO: era this.close()
                return;
            }
            
            // Converter para Layer do Leaflet para checkOverlap
            console.log('🔍 Convertendo polygonToCheck para Leaflet Layer...');
            let layerToCheck;
            try {
                layerToCheck = L.geoJSON(polygonToCheck).getLayers()[0];
                console.log('✅ Layer criado com sucesso');
            } catch (e) {
                console.error('❌ Erro ao converter para Layer:', e.message);
                alert('❌ ERRO\n\nErro ao processar geometria para verificação de sobreposição.\n\nPor favor, redesenhe o polígono.');
                this.cancel(); // CORRIGIDO: era this.close()
                return;
            }
            
            // Verificar sobreposição
            console.log('🔍 Verificando sobreposição com outros territórios...');
            console.log(`   • Territórios a verificar: ${existingGeometries.length}`);
            if (this.context === 'sub-territory') {
                console.log('   • Contexto: SUB-TERRITÓRIO (território pai foi EXCLUÍDO)');
            }
            const overlapResult = window.app.map.checkOverlap(layerToCheck, existingGeometries);
            
            if (!overlapResult.hasOverlap) {
                // Sem sobreposição com outros territórios
                console.log('✅ Nenhuma sobreposição com outros territórios detectada');
                
                // MAS para sub-território, já foi cortado dentro do pai acima
                // Então precisamos salvar esse corte E MOSTRAR PREVIEW!
                if (this.context === 'sub-territory' && this.parentTerritory) {
                    console.log('✅ Sub-território cortado dentro do território pai - mostrando preview');
                    
                    this.data.trimmedGeoJSON = polygonToCheck; // Salvar versão cortada
                    this.data.finalGeoJSON = polygonToCheck;
                    
                    // Mostrar preview do corte com território pai
                    const originalPolygon = this.data.carAdjustedGeoJSON || this.data.originalGeoJSON;
                    this.showTrimPreview(originalPolygon, polygonToCheck);
                    
                    // Atualizar informações do polígono final (com delay)
                    setTimeout(() => {
                        this.updateFinalPolygonInfo(polygonToCheck);
                    }, 300);
                    
                    // Mostrar "Nenhuma sobreposição" mas o preview estará visível
                    document.getElementById('overlapDetectedState').style.display = 'none';
                    document.getElementById('noOverlapState').style.display = 'block';
                } else {
                    // Território normal sem sobreposição
                    this.data.skipTrim = true;
                    this.data.finalGeoJSON = polygonToCheck;
                    
                    // Atualizar informações do polígono final (com delay)
                    setTimeout(() => {
                        this.updateFinalPolygonInfo(polygonToCheck);
                    }, 300);
                    
                    document.getElementById('overlapDetectedState').style.display = 'none';
                    document.getElementById('noOverlapState').style.display = 'block';
                }
                
                return;
            }
            
            console.log(`⚠️ Sobreposição detectada com ${overlapResult.count} território(s)`);
            
            // Aplicar trim
            const trimmed = window.app.polygonTools.quickTrim(
                L.geoJSON(polygonToCheck).getLayers()[0],
                overlapResult.overlappedTerritories
            );
            
            if (!trimmed) {
                console.error('❌ Falha ao aplicar trim');
                return;
            }
            
            this.data.trimmedGeoJSON = trimmed;
            this.data.finalGeoJSON = trimmed;
            
            // Preencher dados do modal
            document.getElementById('overlapCount').textContent = overlapResult.count;
            
            const beforeArea = window.app.polygonTools.calculateArea(L.geoJSON(polygonToCheck).getLayers()[0]);
            const afterArea = window.app.polygonTools.calculateArea(L.geoJSON(trimmed).getLayers()[0]);
            
            // Calcular vértices (suporta Polygon e MultiPolygon)
            const beforeVertices = this._countVertices(polygonToCheck.geometry);
            const afterVertices = this._countVertices(trimmed.geometry);
            
            document.getElementById('trimBeforeArea').textContent = `${beforeArea.toFixed(2)} ha`;
            document.getElementById('trimBeforeVertices').textContent = beforeVertices;
            document.getElementById('trimAfterArea').textContent = `${afterArea.toFixed(2)} ha`;
            document.getElementById('trimAfterVertices').textContent = afterVertices;
            
            // Lista de territórios sobrepostos
            const listContainer = document.getElementById('overlapList');
            listContainer.innerHTML = '';
            overlapResult.overlappedTerritories.forEach(territory => {
                const item = document.createElement('div');
                item.className = 'list-group-item';
                item.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${territory.properties.territory_id || 'N/A'}</strong>
                            <br>
                            <small class="text-muted">${territory.properties.name || 'Sem nome'}</small>
                        </div>
                        <i class="bi bi-exclamation-triangle text-warning"></i>
                    </div>
                `;
                listContainer.appendChild(item);
            });
            
            // Mostrar preview
            this.showTrimPreview(polygonToCheck, trimmed);
            
            // Atualizar informações do polígono final no card do topo (com delay para garantir renderização do modal)
            console.log('🔄 Chamando updateFinalPolygonInfo com trimmed:', trimmed);
            setTimeout(() => {
                this.updateFinalPolygonInfo(trimmed);
            }, 300);
            
            // Mostrar estado de sobreposição
            document.getElementById('overlapDetectedState').style.display = 'block';
            document.getElementById('noOverlapState').style.display = 'none';
            
            console.log('✅ Trim aplicado');
            
        } catch (error) {
            console.error('❌ Erro no STEP 3:', error);
        }
        
        // Configurar botões de edição de vértices no STEP 3
        this.setupStep2EditButtons();
    }

    /**
     * Atualiza informações do polígono no card do STEP 2 (Simplificação)
     */
    updateSimplifyStepInfo(geojson) {
        try {
            if (!geojson) {
                console.warn('⚠️ GeoJSON não fornecido para updateSimplifyStepInfo');
                return;
            }

            const areaElement = document.getElementById('simplifyArea');
            const verticesElement = document.getElementById('simplifyVertices');
            
            if (!areaElement || !verticesElement) {
                console.warn('⚠️ Elementos do STEP 2 não encontrados');
                return;
            }

            // Calcular área
            const tempLayer = L.geoJSON(geojson);
            const area = window.app.polygonTools.calculateArea(tempLayer.getLayers()[0]);
            
            // Calcular vértices
            let vertices = 0;
            const geometry = geojson.geometry || geojson;
            
            if (geometry.type === 'Polygon') {
                vertices = geometry.coordinates[0].length - 1;
            } else if (geometry.type === 'MultiPolygon') {
                geometry.coordinates.forEach(polygon => {
                    vertices += polygon[0].length - 1;
                });
            }
            
            // Atualizar UI
            areaElement.textContent = `${area.toFixed(2)} ha`;
            verticesElement.textContent = vertices.toLocaleString('pt-BR');
            
            console.log(`✅ STEP 2 atualizado - Área: ${area.toFixed(2)} ha, Vértices: ${vertices}`);
            
        } catch (error) {
            console.error('❌ Erro ao atualizar STEP 2:', error);
        }
    }

    /**
     * Atualiza informações do polígono final no card do STEP 3 (Sobreposição)
     */
    updateFinalPolygonInfo(geojson, retryCount = 0) {
        try {
            console.log(`🔍 INÍCIO updateFinalPolygonInfo (tentativa ${retryCount + 1})`);
            
            if (!geojson) {
                console.warn('⚠️ GeoJSON não fornecido para updateFinalPolygonInfo');
                return;
            }

            // Verificar se elementos existem
            const areaElement = document.getElementById('step2FinalArea');
            const verticesElement = document.getElementById('step2FinalVertices');
            
            // Se elementos não existem e ainda temos tentativas, aguardar e tentar novamente
            if ((!areaElement || !verticesElement) && retryCount < 5) {
                console.log(`⏳ Elementos não encontrados. Tentando novamente em 200ms... (tentativa ${retryCount + 1}/5)`);
                setTimeout(() => {
                    this.updateFinalPolygonInfo(geojson, retryCount + 1);
                }, 200);
                return;
            }
            
            if (!areaElement || !verticesElement) {
                console.error('❌ Elementos não encontrados após 5 tentativas!');
                console.log('🔍 Modal STEP 2 visível?', document.getElementById('wizardStep2Modal')?.style.display);
                console.log('🔍 Modal STEP 2 classes:', document.getElementById('wizardStep2Modal')?.className);
                console.log('🔍 Todos os IDs no DOM:', Array.from(document.querySelectorAll('[id]')).map(el => el.id).join(', '));
                return;
            }

            console.log('✅ Elementos encontrados! Atualizando valores...');
            console.log('🔍 DEBUG - geojson.type:', geojson.type);
            console.log('🔍 DEBUG - geojson.geometry:', geojson.geometry);
            
            // Calcular área
            const tempLayer = L.geoJSON(geojson);
            const area = window.app.polygonTools.calculateArea(tempLayer.getLayers()[0]);
            
            // Calcular vértices baseado no tipo de geometria
            let vertices = 0;
            const geometry = geojson.geometry || geojson;
            
            if (geometry.type === 'Polygon') {
                vertices = geometry.coordinates[0].length - 1;
            } else if (geometry.type === 'MultiPolygon') {
                // Somar vértices de todos os polígonos
                geometry.coordinates.forEach(polygon => {
                    vertices += polygon[0].length - 1;
                });
            } else {
                console.warn('⚠️ Tipo de geometria não suportado:', geometry.type);
                vertices = 0;
            }
            
            console.log(`📊 Calculado - Área: ${area.toFixed(2)} ha, Vértices: ${vertices}`);
            
            // Atualizar card
            areaElement.textContent = `${area.toFixed(2)} ha`;
            verticesElement.textContent = vertices;
            
            console.log('✅ Card atualizado com sucesso!');
            console.log(`   📍 Área: ${areaElement.textContent}`);
            console.log(`   📍 Vértices: ${verticesElement.textContent}`);
            
        } catch (error) {
            console.error('❌ Erro ao atualizar informações do polígono:', error);
            console.error('   Stack:', error.stack);
        }
    }

    /**
     * Configura os botões de edição de vértices no STEP 2
     */
    setupStep2EditButtons() {
        const btnEdit = document.getElementById('btnEditVerticesStep2');
        const btnFinish = document.getElementById('btnFinishEditStep2');
        const alert = document.getElementById('editModeAlertStep2');
        
        if (!btnEdit || !btnFinish) {
            console.warn('⚠️ Botões de edição do STEP 2 não encontrados');
            return;
        }
        
        // Remover listeners anteriores
        const newBtnEdit = btnEdit.cloneNode(true);
        const newBtnFinish = btnFinish.cloneNode(true);
        btnEdit.parentNode.replaceChild(newBtnEdit, btnEdit);
        btnFinish.parentNode.replaceChild(newBtnFinish, btnFinish);
        
        // Listener de "Editar Vértices"
        newBtnEdit.addEventListener('click', () => {
            this.enableStep2VertexEditing();
            newBtnEdit.style.display = 'none';
            newBtnFinish.style.display = 'block';
            alert.style.display = 'block';
        });
        
        // Listener de "Finalizar Edição"
        newBtnFinish.addEventListener('click', () => {
            this.finishStep2VertexEditing();
            newBtnEdit.style.display = 'block';
            newBtnFinish.style.display = 'none';
            alert.style.display = 'none';
        });
    }

    /**
     * Habilita edição de vértices no STEP 2
     */
    enableStep2VertexEditing() {
        try {
            // Obter polígono final atual
            const currentGeoJSON = this.data.finalGeoJSON || 
                                   this.data.carAdjustedGeoJSON || 
                                   this.data.manuallyAdjustedGeoJSON || 
                                   this.data.originalGeoJSON;
            
            // Limpar preview atual
            if (this.previewLayers) {
                if (this.previewLayers.before) this.previewLayers.before.clearLayers();
                if (this.previewLayers.after) this.previewLayers.after.clearLayers();
            }
            
            // Criar layer editável
            if (this.editableLayer) {
                window.app.mapManager.map.removeLayer(this.editableLayer);
            }
            
            this.editableLayer = L.geoJSON(currentGeoJSON, {
                style: {
                    color: '#0d6efd',
                    fillColor: '#0d6efd',
                    fillOpacity: 0.3,
                    weight: 3
                }
            }).addTo(window.app.mapManager.map);
            
            // Habilitar edição
            this.editableLayer.eachLayer(layer => {
                if (layer.editing) {
                    layer.editing.enable();
                }
            });
            
            console.log('✏️ Modo de edição de vértices ativado no STEP 2');
            
        } catch (error) {
            console.error('❌ Erro ao habilitar edição:', error);
        }
    }

    /**
     * Finaliza edição de vértices no STEP 2 e atualiza dados
     */
    finishStep2VertexEditing() {
        try {
            if (!this.editableLayer) {
                console.warn('⚠️ Nenhuma camada editável encontrada');
                return;
            }
            
            // Desabilitar edição
            this.editableLayer.eachLayer(layer => {
                if (layer.editing) {
                    layer.editing.disable();
                }
            });
            
            // Obter GeoJSON atualizado
            const updatedGeoJSON = this.editableLayer.toGeoJSON();
            const feature = updatedGeoJSON.features[0];
            
            // Atualizar polígono final
            this.data.finalGeoJSON = feature;
            
            // Atualizar informações no card
            this.updateFinalPolygonInfo(feature);
            
            // Remover layer editável
            window.app.mapManager.map.removeLayer(this.editableLayer);
            this.editableLayer = null;
            
            // Recriar preview com polígono atualizado
            this.showTrimPreview(null, feature);
            
            console.log('✅ Edição de vértices finalizada e polígono atualizado');
            
            // Notificar usuário
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    'Polígono atualizado com sucesso!',
                    'success'
                );
            }
            
        } catch (error) {
            console.error('❌ Erro ao finalizar edição:', error);
        }
    }

    /**
     * Configura o botão de fechamento morfológico no STEP 2
     */
    setupClosingButton() {
        const btnClosing = document.getElementById('btnApplyClosing');

        if (!btnClosing) {
            console.warn('⚠️ Botão de fechamento morfológico não encontrado');
            return;
        }

        console.log('🔧 Configurando botão de fechamento morfológico...');

        // Remover listeners anteriores
        const newBtn = btnClosing.cloneNode(true);
        btnClosing.parentNode.replaceChild(newBtn, btnClosing);

        // Adicionar novo listener
        newBtn.addEventListener('click', () => {
            console.log('🖱️ Botão Aplicar Fechamento clicado!');
            this.applyMorphologicalClosing();
        });

        console.log('✅ Botão de fechamento morfológico configurado');
    }

    /**
     * Aplica fechamento morfológico ao polígono (buffer positivo -> buffer negativo)
     * Preenche reentrâncias e remove buracos
     */
    async applyMorphologicalClosing() {
        const btnClosing = document.getElementById('btnApplyClosing');
        const distanceInput = document.getElementById('closingDistance');
        const statsDiv = document.getElementById('simplifyStats');

        try {
            // Obter distância em metros
            const meters = parseInt(distanceInput.value) || 50;

            // Validar range
            if (meters < 10 || meters > 200) {
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification(
                        'Distância deve estar entre 10 e 200 metros!',
                        'warning'
                    );
                }
                return;
            }

            // Desabilitar botão
            btnClosing.disabled = true;
            distanceInput.disabled = true;
            btnClosing.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Processando...`;

            // Obter polígono atual
            let currentGeoJSON = this.data.finalGeoJSON ||
                                 this.data.carAdjustedGeoJSON ||
                                 this.data.manuallyAdjustedGeoJSON ||
                                 this.data.originalGeoJSON;

            if (!currentGeoJSON) {
                console.error('❌ Nenhum polígono disponível');
                if (window.app && window.app.uiController) {
                    window.app.uiController.showNotification(
                        'Nenhum polígono disponível!',
                        'error'
                    );
                }
                return;
            }

            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            console.log(`🔲 Aplicando FECHAMENTO MORFOLÓGICO:`);
            console.log(`   📏 Distância do buffer: ${meters}m`);

            // Contar vértices antes
            let verticesBefore = 0;
            if (currentGeoJSON.geometry.type === 'Polygon') {
                verticesBefore = currentGeoJSON.geometry.coordinates[0].length - 1;
            } else if (currentGeoJSON.geometry.type === 'MultiPolygon') {
                verticesBefore = currentGeoJSON.geometry.coordinates.reduce((sum, poly) => sum + poly[0].length - 1, 0);
            }
            console.log(`   📍 Vértices antes: ${verticesBefore}`);

            // Converter metros para km
            const distanceKm = meters / 1000;

            // Marcar tempo de execução
            const startTime = performance.now();

            // Passo 1: Buffer positivo (dilatação)
            console.log('   ➕ Aplicando buffer positivo...');
            const dilated = turf.buffer(currentGeoJSON, distanceKm, { units: 'kilometers' });

            if (!dilated) {
                throw new Error('Buffer positivo resultou em geometria nula');
            }

            // Passo 2: Buffer negativo (erosão)
            console.log('   ➖ Aplicando buffer negativo...');
            const closed = turf.buffer(dilated, -distanceKm, { units: 'kilometers' });

            if (!closed) {
                throw new Error('Buffer negativo resultou em geometria nula');
            }

            // Se for MultiPolygon, pegar o maior
            let result = closed;
            if (closed.geometry.type === 'MultiPolygon') {
                console.log('   🔄 MultiPolygon detectado, selecionando maior polígono...');
                const polygons = closed.geometry.coordinates.map(coords => turf.polygon(coords));
                result = polygons.reduce((max, p) => turf.area(p) > turf.area(max) ? p : max);
            }

            // Passo 3: Remover buracos
            console.log('   🕳️ Removendo buracos...');
            result = window.app.polygonTools.removeHoles(result);

            // Passo 4: Simplificar para reduzir vértices criados pelo buffer
            console.log('   ✂️ Simplificando polígono...');
            const tolerance = 0.0003; // Tolerância em graus (~30m)
            result = turf.simplify(result, { tolerance: tolerance, highQuality: true });

            const duration = performance.now() - startTime;

            // Contar vértices depois
            let verticesAfter = 0;
            if (result.geometry.type === 'Polygon') {
                verticesAfter = result.geometry.coordinates[0].length - 1;
            } else if (result.geometry.type === 'MultiPolygon') {
                verticesAfter = result.geometry.coordinates.reduce((sum, poly) => sum + poly[0].length - 1, 0);
            }

            const reduction = verticesBefore > 0
                ? ((verticesBefore - verticesAfter) / verticesBefore * 100).toFixed(1)
                : '0';

            console.log(`   📍 Vértices depois: ${verticesAfter}`);
            console.log(`   📉 Redução: ${reduction}%`);
            console.log(`   ⏱️  Tempo: ${duration.toFixed(2)}ms`);
            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

            // Atualizar polígono final
            this.data.finalGeoJSON = result;
            console.log('✅ finalGeoJSON atualizado');

            // Atualizar estatísticas na UI
            document.getElementById('verticesBefore').textContent = verticesBefore;
            document.getElementById('verticesAfter').textContent = verticesAfter;
            document.getElementById('reductionPercent').textContent = `${reduction}%`;
            statsDiv.style.display = 'block';

            // Atualizar card do STEP 2
            this.updateSimplifyStepInfo(result);

            // Atualizar preview no mapa
            this.showFinalPolygonPreview(result);

            // Mostrar notificação
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    `✅ Fechamento morfológico aplicado! ${verticesBefore} → ${verticesAfter} vértices`,
                    'success'
                );
            }

        } catch (error) {
            console.error('❌ Erro no fechamento morfológico:', error);
            if (window.app && window.app.uiController) {
                window.app.uiController.showNotification(
                    'Erro ao aplicar fechamento morfológico: ' + error.message,
                    'error'
                );
            }
        } finally {
            // Reabilitar botão
            btnClosing.disabled = false;
            distanceInput.disabled = false;
            btnClosing.innerHTML = `<i class="bi bi-bounding-box me-2"></i>Aplicar`;
        }
    }

    /**
     * STEP 4: Montar confirmação final
     */
    loadConfirmationStep() {
        try {
            console.log('✅ Montando confirmação...');
            
            const originalArea = window.app.polygonTools.calculateArea(this.data.originalLayer);
            const carArea = this.data.carAdjustedGeoJSON 
                ? window.app.polygonTools.calculateArea(L.geoJSON(this.data.carAdjustedGeoJSON).getLayers()[0])
                : originalArea;
            const finalArea = this.data.finalGeoJSON
                ? window.app.polygonTools.calculateArea(L.geoJSON(this.data.finalGeoJSON).getLayers()[0])
                : originalArea;
            
            // Se for sub-território, mostrar campos de nome e descrição
            if (this.context === 'sub-territory') {
                this._showSubTerritoryFields();
            } else {
                this._hideSubTerritoryFields();
            }
            
            // Preencher áreas
            document.getElementById('finalOriginalArea').textContent = `${originalArea.toFixed(2)} ha`;
            document.getElementById('finalCarArea').textContent = `${carArea.toFixed(2)} ha`;
            document.getElementById('finalTotalArea').textContent = `${finalArea.toFixed(2)} ha`;
            
            // Diferenças
            const carDiff = carArea - originalArea;
            document.getElementById('finalCarDiff').textContent = 
                `${carDiff >= 0 ? '+' : ''}${carDiff.toFixed(2)} ha`;
            
            // Resumo
            const summaryList = document.getElementById('finalSummaryList');
            summaryList.innerHTML = '';
            
            if (!this.data.skipCAR && this.data.carAdjustedGeoJSON) {
                const li = document.createElement('li');
                li.innerHTML = `<i class="bi bi-check-circle text-success me-2"></i>
                    <strong>Ajuste ao CAR:</strong> ${this.data.carFeatures.length} imóveis processados 
                    (${carDiff >= 0 ? '+' : ''}${carDiff.toFixed(2)} ha)`;
                summaryList.appendChild(li);
            }
            
            if (!this.data.skipTrim && this.data.trimmedGeoJSON) {
                const trimDiff = finalArea - carArea;
                const li = document.createElement('li');
                li.innerHTML = `<i class="bi bi-check-circle text-success me-2"></i>
                    <strong>Recorte de sobreposição:</strong> Margem de 2cm aplicada 
                    (${trimDiff.toFixed(2)} ha)`;
                summaryList.appendChild(li);
            }
            
            if (this.data.skipCAR && this.data.skipTrim) {
                const li = document.createElement('li');
                li.innerHTML = `<i class="bi bi-info-circle text-info me-2"></i>
                    <strong>Sem ajustes:</strong> Território salvo como desenhado`;
                summaryList.appendChild(li);
            }
            
            console.log('✅ Confirmação montada');
            
        } catch (error) {
            console.error('❌ Erro no STEP 4:', error);
        }
    }

    /**
     * Mostra preview do ajuste CAR no mapa
     */
    showCARPreview(adjustedGeoJSON) {
        this.clearPreviews();

        // Reduzir opacidade do layer "Áreas por unidade" para não confundir
        this._reduceConsultoresOpacity();

        // Preview verde (ajustado) - adjustedGeoJSON já é um GeoJSON Feature
        this.previewLayers.adjusted = L.geoJSON(adjustedGeoJSON, {
            style: {
                color: '#10b981',
                fillColor: '#10b981',
                fillOpacity: 0.3,
                weight: 3
            }
        }).addTo(window.app.map.map);

        console.log('🗺️ Preview atualizado no mapa');
    }

    /**
     * Reduz opacidade do layer "Áreas por unidade" durante preview CAR
     */
    _reduceConsultoresOpacity() {
        if (window.app?.map?.layers?.consultores) {
            window.app.map.layers.consultores.eachLayer(layer => {
                if (layer.setStyle) {
                    layer.setStyle({ fillOpacity: 0.05, opacity: 0.3 });
                }
            });
        }
    }

    /**
     * Restaura opacidade do layer "Áreas por unidade"
     * Valores originais: fillOpacity: 0.45, opacity: 0.75, weight: 2
     */
    _restoreConsultoresOpacity() {
        if (window.app?.map?.layers?.consultores) {
            window.app.map.layers.consultores.eachLayer(layer => {
                if (layer.setStyle) {
                    layer.setStyle({ fillOpacity: 0.45, opacity: 0.75, weight: 2 });
                }
            });
        }
    }

    /**
     * Mostra apenas o polígono final no mapa (modo edição disponível)
     */
    showFinalPolygonPreview(geoJSON) {
        this.clearPreviews();

        // IMPORTANTE: Ocultar o polígono original desenhado para não sobrepor o preview final
        this._hideOriginalDrawingLayer();

        // Criar layer editável com o polígono final
        this.previewLayers.final = L.geoJSON(geoJSON, {
            style: {
                color: '#10b981',
                fillColor: '#10b981',
                fillOpacity: 0.2,
                weight: 3,
                dashArray: null
            }
        }).addTo(window.app.map.map);
        
        // Centralizar mapa no polígono
        this.centerMapOnPolygon(this.previewLayers.final);
        
        console.log('🗺️ Polígono final exibido no mapa');
    }


    /**
     * Habilita edição de vértices no STEP 2
     */
    enableVertexEditingStep2() {
        if (!this.previewLayers.final) {
            console.warn('⚠️ Nenhum polígono final para editar');
            return;
        }
        
        // Obter layer do polígono
        const layers = this.previewLayers.final.getLayers();
        if (layers.length === 0) return;
        
        const polygonLayer = layers[0];
        
        // Habilitar edição
        if (polygonLayer.editing) {
            polygonLayer.editing.enable();
            this.isEditingStep2 = true;
            
            // Atualizar UI
            document.getElementById('btnEditVerticesStep2').classList.add('d-none');
            document.getElementById('btnFinishEditingStep2').classList.remove('d-none');
            document.getElementById('editingModeAlert').style.display = 'block';
            
            // Listener para atualizar contador de vértices em tempo real
            polygonLayer.on('edit', () => {
                const updatedGeoJSON = polygonLayer.toGeoJSON();
                this.data.finalGeoJSON = updatedGeoJSON;
                this.updateFinalPolygonInfo(updatedGeoJSON);
            });
            
            console.log('✏️ Modo de edição de vértices ativado no STEP 2');
        }
    }

    /**
     * Desabilita edição de vértices no STEP 2
     */
    finishVertexEditingStep2() {
        if (!this.previewLayers.final) return;
        
        const layers = this.previewLayers.final.getLayers();
        if (layers.length === 0) return;
        
        const polygonLayer = layers[0];
        
        if (polygonLayer.editing) {
            polygonLayer.editing.disable();
            this.isEditingStep2 = false;
            
            // Salvar versão final editada
            this.data.finalGeoJSON = polygonLayer.toGeoJSON();
            
            // Atualizar UI
            document.getElementById('btnEditVerticesStep2').classList.remove('d-none');
            document.getElementById('btnFinishEditingStep2').classList.add('d-none');
            document.getElementById('editingModeAlert').style.display = 'none';
            
            // Atualizar informações
            this.updateFinalPolygonInfo(this.data.finalGeoJSON);
            
            console.log('✅ Edição de vértices finalizada no STEP 2');
        }
    }

    /**
     * Mostra preview do trim no mapa
     * VERDE = Parte INTERNA (fica dentro do território pai)
     * VERMELHO = Parte EXTERNA (fica fora do território pai)
     */
    showTrimPreview(beforeGeoJSON, afterGeoJSON) {
        this.clearPreviews();

        // IMPORTANTE: Ocultar o polígono original desenhado para não sobrepor os previews
        this._hideOriginalDrawingLayer();

        // Preview VERMELHO tracejado (EXTERNO - parte original que inclui área fora)
        this.previewLayers.original = L.geoJSON(beforeGeoJSON, {
            style: {
                color: '#ef4444',
                fillColor: '#ef4444',
                fillOpacity: 0.15,
                weight: 2,
                dashArray: '8, 4'
            }
        }).addTo(window.app.map.map);
        
        // Preview VERDE sólido (INTERNO - parte que fica dentro do território)
        this.previewLayers.adjusted = L.geoJSON(afterGeoJSON, {
            style: {
                color: '#10b981',
                fillColor: '#10b981',
                fillOpacity: 0.35,
                weight: 3
            }
        }).addTo(window.app.map.map);
        
        // Zoom para área do preview
        try {
            const bounds = this.previewLayers.original.getBounds();
            window.app.map.map.fitBounds(bounds, { padding: [50, 50] });
        } catch (e) {
            console.warn('⚠️ Não foi possível ajustar zoom:', e.message);
        }
    }

    /**
     * Limpa previews do mapa
     */
    clearPreviews() {
        if (this.previewLayers.original) {
            window.app.map.map.removeLayer(this.previewLayers.original);
            this.previewLayers.original = null;
        }
        if (this.previewLayers.adjusted) {
            window.app.map.map.removeLayer(this.previewLayers.adjusted);
            this.previewLayers.adjusted = null;
        }
        this.previewLayers.markers.forEach(marker => {
            window.app.map.map.removeLayer(marker);
        });
        this.previewLayers.markers = [];

        // Restaurar opacidade do layer "Áreas por unidade"
        this._restoreConsultoresOpacity();
    }

    /**
     * Oculta o polígono original desenhado para não sobrepor os previews
     * O polígono é mantido em memória para ser restaurado depois se necessário
     */
    _hideOriginalDrawingLayer() {
        // Ocultar originalLayer se existir
        if (this.data.originalLayer) {
            // Verificar em qual layer group está
            if (window.app.map.layers.drawings && window.app.map.layers.drawings.hasLayer(this.data.originalLayer)) {
                window.app.map.layers.drawings.removeLayer(this.data.originalLayer);
                this._originalLayerHidden = true;
                console.log('🙈 Polígono original ocultado (estava em drawings)');
            } else if (window.app.map.layers.editableLayers && window.app.map.layers.editableLayers.hasLayer(this.data.originalLayer)) {
                window.app.map.layers.editableLayers.removeLayer(this.data.originalLayer);
                this._originalLayerHidden = true;
                console.log('🙈 Polígono original ocultado (estava em editableLayers)');
            } else if (window.app.map.map.hasLayer(this.data.originalLayer)) {
                window.app.map.map.removeLayer(this.data.originalLayer);
                this._originalLayerHidden = true;
                console.log('🙈 Polígono original ocultado (estava no mapa)');
            }
        }

        // Também ocultar currentPolygon do uiController se for diferente do originalLayer
        if (window.app.uiController && window.app.uiController.currentPolygon) {
            const currentPoly = window.app.uiController.currentPolygon;
            if (currentPoly !== this.data.originalLayer) {
                if (window.app.map.layers.drawings && window.app.map.layers.drawings.hasLayer(currentPoly)) {
                    window.app.map.layers.drawings.removeLayer(currentPoly);
                    this._currentPolygonHidden = true;
                    console.log('🙈 currentPolygon do uiController ocultado');
                } else if (window.app.map.map.hasLayer(currentPoly)) {
                    window.app.map.map.removeLayer(currentPoly);
                    this._currentPolygonHidden = true;
                    console.log('🙈 currentPolygon ocultado do mapa');
                }
            }
        }
    }

    /**
     * Restaura o polígono original desenhado (se foi ocultado)
     */
    _restoreOriginalDrawingLayer() {
        if (this._originalLayerHidden && this.data.originalLayer) {
            window.app.map.layers.drawings.addLayer(this.data.originalLayer);
            this._originalLayerHidden = false;
            console.log('👁️ Polígono original restaurado');
        }
        if (this._currentPolygonHidden && window.app.uiController && window.app.uiController.currentPolygon) {
            window.app.map.layers.drawings.addLayer(window.app.uiController.currentPolygon);
            this._currentPolygonHidden = false;
            console.log('👁️ currentPolygon restaurado');
        }
    }

    /**
     * Remove permanentemente o polígono original desenhado (após salvar)
     * Diferente de _hideOriginalDrawingLayer que apenas oculta temporariamente
     */
    _removeOriginalDrawingLayer() {
        // Remover originalLayer de todos os possíveis layer groups
        if (this.data.originalLayer) {
            if (window.app.map.layers.drawings && window.app.map.layers.drawings.hasLayer(this.data.originalLayer)) {
                window.app.map.layers.drawings.removeLayer(this.data.originalLayer);
                console.log('🗑️ Polígono original removido de drawings');
            }
            if (window.app.map.layers.editableLayers && window.app.map.layers.editableLayers.hasLayer(this.data.originalLayer)) {
                window.app.map.layers.editableLayers.removeLayer(this.data.originalLayer);
                console.log('🗑️ Polígono original removido de editableLayers');
            }
            if (window.app.map.map && window.app.map.map.hasLayer(this.data.originalLayer)) {
                window.app.map.map.removeLayer(this.data.originalLayer);
                console.log('🗑️ Polígono original removido do mapa');
            }
            this.data.originalLayer = null;
        }

        // Remover currentPolygon do uiController
        if (window.app.uiController && window.app.uiController.currentPolygon) {
            const currentPoly = window.app.uiController.currentPolygon;
            if (window.app.map.layers.drawings && window.app.map.layers.drawings.hasLayer(currentPoly)) {
                window.app.map.layers.drawings.removeLayer(currentPoly);
                console.log('🗑️ currentPolygon removido de drawings');
            }
            if (window.app.map.map && window.app.map.map.hasLayer(currentPoly)) {
                window.app.map.map.removeLayer(currentPoly);
                console.log('🗑️ currentPolygon removido do mapa');
            }
            window.app.uiController.currentPolygon = null;
        }

        // Limpar também o previewLayers.final se existir
        if (this.previewLayers.final) {
            window.app.map.map.removeLayer(this.previewLayers.final);
            this.previewLayers.final = null;
            console.log('🗑️ Preview final removido');
        }

        // Resetar flags
        this._originalLayerHidden = false;
        this._currentPolygonHidden = false;
    }

    /**
     * Avançar para próximo step
     */
    async next() {
        console.log(`⏭️ NEXT() chamado - currentStep: ${this.currentStep} / ${this.totalSteps}`);
        
        if (this.currentStep >= this.totalSteps) return;
        
        // STEP 0 -> STEP 1: Salvar ajustes manuais e carregar CAR
        if (this.currentStep === 0) {
            console.log('📝 Finalizando ajustes manuais e carregando CAR...');
            
            // Salvar a geometria atual (pode ter sido editada)
            if (this.data.originalLayer) {
                this.data.manuallyAdjustedGeoJSON = this.data.originalLayer.toGeoJSON();
                console.log('✅ Geometria manualmente ajustada salva');
            }
            
            // Ir para STEP 1 e carregar CAR em background
            this.goToStep(1);
            await this.loadCARStep();
            return;
        }
        
        // STEP 1 -> STEP 2: Carregar simplificação
        if (this.currentStep === 1) {
            console.log('� Indo para STEP 2 - Simplificação');
            await this.loadSimplifyStep();
            this.goToStep(2);
            return;
        }
        
        // STEP 2 -> STEP 3: Carregar verificação de sobreposição
        if (this.currentStep === 2) {
            console.log('✂️ Indo para STEP 3 - Sobreposição');
            await this.loadOverlapStep();
            this.goToStep(3);
            return;
        }
        
        // STEP 3 -> STEP 4: Carregar confirmação final
        if (this.currentStep === 3) {
            console.log('✅ Indo para STEP 4 - Confirmação Final');
            this.loadConfirmationStep();
            this.goToStep(4);
            return;
        }
        
        this.goToStep(this.currentStep + 1);
    }

    /**
     * Voltar para step anterior
     */
    previous() {
        if (this.currentStep <= 0) return;  // Não pode voltar do STEP 0
        this.goToStep(this.currentStep - 1);
    }

    /**
     * Pular step atual
     */
    skip() {
        // STEP 0: Pular CAR (ir direto para STEP 2 - Simplificação)
        if (this.currentStep === 0) {
            this.data.skipCAR = true;
            this.data.manuallyAdjustedGeoJSON = this.data.originalLayer.toGeoJSON();
            console.log('⏭️ CAR pulado no STEP 0 - Indo para STEP 2');
            this.goToStep(2);  // Pular STEP 1 (CAR) e ir direto para STEP 2 (Simplificação)
            this.loadSimplifyStep();
            return;
        }
        
        // STEP 1: Pular CAR (ir para STEP 2 - Simplificação)
        if (this.currentStep === 1) {
            this.data.skipCAR = true;
            this.data.carAdjustedGeoJSON = null;
            console.log('⏭️ CAR pulado no STEP 1 - Indo para STEP 2');
            this.goToStep(2);
            this.loadSimplifyStep();
            return;
        }
        
        this.next();
    }

    /**
     * Salvar território final
     */
    async save() {
        // PROTEÇÃO CONTRA MÚLTIPLOS CLIQUES
        if (this._saving) {
            console.log('⚠️ Salvamento já em andamento, ignorando...');
            return;
        }
        
        this._saving = true;
        
        try {
            console.log('💾 Salvando território...');
            console.log('🔍 Contexto:', this.context);
            console.log('🔍 Território pai:', this.parentTerritory);
            
            // Remover polígono original
            if (window.app.map.layers.drawings.hasLayer(this.data.originalLayer)) {
                window.app.map.layers.drawings.removeLayer(this.data.originalLayer);
            }
            
            // Criar layer final
            const finalLayer = L.geoJSON(this.data.finalGeoJSON).getLayers()[0];
            
            // Transferir dados
            if (this.data.originalLayer.territoryData) {
                finalLayer.territoryData = this.data.originalLayer.territoryData;
                finalLayer.centerKey = this.data.originalLayer.centerKey;
            }
            
            finalLayer._skipOverlapValidation = true;
            
            // Adicionar ao mapa
            window.app.map.layers.drawings.addLayer(finalLayer);
            window.app.map.currentPolygon = finalLayer;
            
            // Calcular área
            const area = window.app.polygonTools.calculateArea(finalLayer);
            
            // VERIFICAR CONTEXTO: SUB-TERRITÓRIO ou TERRITÓRIO
            if (this.context === 'sub-territory' && this.parentTerritory) {
                console.log('🎯 Salvando SUB-TERRITÓRIO (Carteira)...');
                
                // Obter nome do campo do Step 3
                const nameInput = document.getElementById('subTerritoryName');
                const name = nameInput ? nameInput.value.trim() : '';
                
                if (!name) {
                    window.app.uiController.showNotification('❌ Nome da carteira é obrigatório', 'error');
                    return;
                }
                
                // Criar sub-território
                const geojson = finalLayer.toGeoJSON();
                
                // Gerar carteira_id baseado no territory_id do pai + sufixo
                const carteiraId = await this._generateCarteiraId(this.parentTerritory.id);
                
                const subTerritoryData = {
                    areaKey: 1, // Área padrão
                    subAreaKey: 1, // Sub-área padrão
                    carteiraId: carteiraId,
                    name: name,
                    geometry: geojson.geometry,
                    area_hectares: area
                };
                
                console.log('📦 Dados do sub-território:', {
                    parent: this.parentTerritory.id,
                    property: this.parentTerritory.property_id,
                    data: subTerritoryData
                });
                
                try {
                    const savedSubTerritory = await window.app.dataManager.createSubTerritory(
                        this.parentTerritory.id,
                        this.parentTerritory.property_id,
                        subTerritoryData
                    );
                    console.log('✅ Sub-território salvo no banco:', savedSubTerritory);
                    
                    window.app.uiController.showNotification(
                        `✅ Carteira "${name}" criada com sucesso! (${area.toFixed(2)} ha)`, 
                        'success'
                    );
                    
                    // 🔄 ATUALIZAR VISUALIZAÇÃO NO MAPA
                    console.log('🔄 Atualizando visualização no mapa...');
                    
                    // 1. Remover layer temporário de desenho
                    if (window.app.map.layers.drawings.hasLayer(finalLayer)) {
                        window.app.map.layers.drawings.removeLayer(finalLayer);
                    }
                    
                    // 2. Recarregar TODOS os territórios e sub-territórios de fundo
                    console.log('📥 Recarregando territórios e sub-territórios...');
                    await window.app.map.loadBackgroundTerritories();
                    
                    // 3. Recarregar árvore lateral
                    console.log('🌲 Recarregando árvore de regiões...');
                    await window.app.uiController.loadRegionsTree();
                    
                    // 4. Centralizar no sub-território recém-criado
                    if (savedSubTerritory && savedSubTerritory.geometry) {
                        console.log('📍 Centralizando no sub-território criado...');
                        const bounds = L.geoJSON(savedSubTerritory.geometry).getBounds();
                        window.app.map.getMap().fitBounds(bounds, { padding: [50, 50] });
                    }
                    
                    console.log('✅ Visualização atualizada com sucesso!');
                    
                } catch (error) {
                    console.error('❌ Erro ao salvar sub-território:', error);
                    window.app.uiController.showNotification(
                        '❌ Erro ao salvar carteira: ' + error.message, 
                        'error'
                    );
                    return;
                }
                
            } else {
                console.log('🗺️ Salvando TERRITÓRIO...');
                
                // Salvar território (fluxo original)
                await window.app.map.savePendingTerritory(finalLayer, area);
            }
            
            // Fechar modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('modalTerritoryWizard'));
            modal.hide();

            // Limpar previews E remover polígono original desenhado
            this.clearPreviews();
            this._removeOriginalDrawingLayer();

            console.log('✅ Território salvo com sucesso!');
            
        } catch (error) {
            console.error('❌ Erro ao salvar território:', error);
            window.app.uiController.showNotification(
                '❌ Erro ao salvar: ' + error.message, 
                'error'
            );
        } finally {
            // Liberar flag de salvamento
            this._saving = false;
        }
    }

    /**
     * Cancelar wizard
     */
    cancel() {
        // Remover polígono original
        if (this.data.originalLayer && window.app.map.layers.drawings.hasLayer(this.data.originalLayer)) {
            window.app.map.layers.drawings.removeLayer(this.data.originalLayer);
        }
        
        // Limpar previews
        this.clearPreviews();
        
        // Fechar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalTerritoryWizard'));
        modal.hide();
        
        console.log('❌ Wizard cancelado');
    }

    /**
     * Mostra campos específicos de sub-território no Step 3
     */
    _showSubTerritoryFields() {
        // Criar campos se não existirem
        let fieldsContainer = document.getElementById('subTerritoryFieldsContainer');
        
        if (!fieldsContainer) {
            // Criar container
            fieldsContainer = document.createElement('div');
            fieldsContainer.id = 'subTerritoryFieldsContainer';
            fieldsContainer.className = 'card mb-4 border-primary';
            fieldsContainer.style.display = 'block'; // Garantir visibilidade
            fieldsContainer.innerHTML = `
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-pencil-square me-2"></i>
                    <strong>Informações da Carteira</strong>
                </div>
                <div class="card-body">
                    <div class="mb-0">
                        <label for="subTerritoryName" class="form-label">
                            <i class="bi bi-tag me-1"></i>
                            Nome da Carteira <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control form-control-lg" id="subTerritoryName" 
                               placeholder="Ex: Norte, Sul, Área 01..." required autofocus>
                        <small class="form-text text-muted">Nome para identificar esta carteira</small>
                    </div>
                </div>
            `;
            
            // Inserir LOGO APÓS o alert de sucesso no STEP 4 (Confirmação Final)
            const alertSuccess = document.querySelector('#wizardStep4 .alert-success');
            if (alertSuccess) {
                alertSuccess.parentNode.insertBefore(fieldsContainer, alertSuccess.nextSibling);
                console.log('✅ Container de campos criado e inserido após alert');
            } else {
                console.error('❌ Alert de sucesso não encontrado para inserir campos');
            }
        } else {
            // Se já existe, apenas mostrar
            fieldsContainer.style.display = 'block';
        }
        
        console.log('📝 Campo de nome da carteira exibido');
        
        // Focar no input de nome após um pequeno delay
        setTimeout(() => {
            const nameInput = document.getElementById('subTerritoryName');
            if (nameInput) {
                nameInput.focus();
            }
        }, 300);
    }

    /**
     * Esconde campos específicos de sub-território
     */
    _hideSubTerritoryFields() {
        const fieldsContainer = document.getElementById('subTerritoryFieldsContainer');
        if (fieldsContainer) {
            fieldsContainer.style.display = 'none';
        }
    }

    /**
     * Gera ID único para carteira baseado no território pai
     */
    async _generateCarteiraId(parentTerritoryId) {
        try {
            // CORREÇÃO: Usar território pai já carregado em this.parentTerritory
            const territory = this.parentTerritory;
            
            if (!territory) {
                throw new Error('Território pai não encontrado');
            }
            
            // Buscar sub-territórios existentes do território pai
            let subTerritories = [];
            try {
                subTerritories = await window.app.dataManager.listSubTerritories(parentTerritoryId);
            } catch (err) {
                console.warn('⚠️ Erro ao buscar sub-territórios, assumindo nenhum existente:', err);
                subTerritories = [];
            }
            
            // Extrair números dos IDs existentes (ex: C011.01 -> 1)
            const existingNumbers = subTerritories
                .map(st => {
                    const match = st.carteira_id?.match(/\.(\d+)$/);
                    return match ? parseInt(match[1], 10) : 0;
                })
                .filter(n => !isNaN(n));
            
            // Próximo número disponível
            const nextNumber = existingNumbers.length > 0 
                ? Math.max(...existingNumbers) + 1 
                : 1;
            
            // Formato: territorio_id + . + número (ex: C011.01)
            const carteiraId = `${territory.territory_id}.${String(nextNumber).padStart(2, '0')}`;
            
            console.log(`🏷️ Carteira ID gerado: ${carteiraId}`);
            return carteiraId;
            
        } catch (error) {
            console.error('❌ Erro ao gerar carteira ID:', error);
            // Fallback: usar timestamp
            return `CART_${Date.now()}`;
        }
    }

    /**
     * Conta total de vértices em uma geometria (suporta Polygon e MultiPolygon)
     */
    _countVertices(geometry) {
        if (!geometry || !geometry.coordinates) return 0;
        
        if (geometry.type === 'Polygon') {
            // Polygon: coordinates[0] é o anel externo
            return geometry.coordinates[0].length - 1; // -1 porque primeiro e último são iguais
        } else if (geometry.type === 'MultiPolygon') {
            // MultiPolygon: somar vértices de todos os polígonos
            let total = 0;
            geometry.coordinates.forEach(polygon => {
                total += polygon[0].length - 1; // polygon[0] é o anel externo
            });
            return total;
        }
        
        return 0;
    }
}

// Exportar globalmente
if (typeof window !== 'undefined') {
    window.TerritoryWizard = TerritoryWizard;
}
