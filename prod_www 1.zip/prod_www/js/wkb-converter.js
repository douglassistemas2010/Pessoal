/**
 * Converte WKB hexadecimal para GeoJSON
 * @param {string} wkbHex - String hexadecimal do WKB
 * @returns {object} Objeto GeoJSON
 */
function wkbHexToGeoJSON(wkbHex) {
    // Converter hex string para array de bytes
    const bytes = [];
    for (let i = 0; i < wkbHex.length; i += 2) {
        bytes.push(parseInt(wkbHex.substr(i, 2), 16));
    }
    
    // Ler byte order (0 = Big Endian, 1 = Little Endian)
    const littleEndian = bytes[0] === 1;
    let offset = 1;
    
    // Ler tipo de geometria
    const wkbType = readUInt32(bytes, offset, littleEndian);
    offset += 4;
    
    // SRID (se presente - tipo & 0x20000000)
    if (wkbType & 0x20000000) {
        offset += 4; // Pular SRID
    }
    
    const geometryType = wkbType & 0xFF;
    
    // Polygon = 3
    if (geometryType === 3) {
        return parsePolygon(bytes, offset, littleEndian);
    }
    // MultiPolygon = 6
    else if (geometryType === 6) {
        return parseMultiPolygon(bytes, offset, littleEndian);
    }
    // Point = 1
    else if (geometryType === 1) {
        return parsePoint(bytes, offset, littleEndian);
    }
    
    throw new Error(`Tipo de geometria não suportado: ${geometryType}`);
}

function readUInt32(bytes, offset, littleEndian) {
    if (littleEndian) {
        return bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24);
    } else {
        return (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];
    }
}

function readDouble(bytes, offset, littleEndian) {
    const buffer = new ArrayBuffer(8);
    const view = new DataView(buffer);
    for (let i = 0; i < 8; i++) {
        view.setUint8(i, bytes[offset + i]);
    }
    return view.getFloat64(0, littleEndian);
}

function parsePoint(bytes, offset, littleEndian) {
    const x = readDouble(bytes, offset, littleEndian);
    const y = readDouble(bytes, offset + 8, littleEndian);
    return {
        type: 'Point',
        coordinates: [x, y]
    };
}

function parsePolygon(bytes, offset, littleEndian) {
    // Ler número de rings
    const numRings = readUInt32(bytes, offset, littleEndian);
    offset += 4;
    
    const rings = [];
    for (let i = 0; i < numRings; i++) {
        const numPoints = readUInt32(bytes, offset, littleEndian);
        offset += 4;
        
        const ring = [];
        for (let j = 0; j < numPoints; j++) {
            const x = readDouble(bytes, offset, littleEndian);
            const y = readDouble(bytes, offset + 8, littleEndian);
            ring.push([x, y]);
            offset += 16;
        }
        rings.push(ring);
    }
    
    return {
        type: 'Polygon',
        coordinates: rings
    };
}

function parseMultiPolygon(bytes, offset, littleEndian) {
    const numPolygons = readUInt32(bytes, offset, littleEndian);
    offset += 4;
    
    const polygons = [];
    for (let i = 0; i < numPolygons; i++) {
        // Pular byte order e tipo para cada polígono
        offset += 5;
        const polygon = parsePolygon(bytes, offset, littleEndian);
        polygons.push(polygon.coordinates);
        // Atualizar offset baseado no número de rings e pontos
        // (isso é simplificado - uma implementação completa precisaria calcular corretamente)
    }
    
    return {
        type: 'MultiPolygon',
        coordinates: polygons
    };
}

// Exportar
window.WKBConverter = {
    wkbHexToGeoJSON
};

console.log('✅ WKB Converter carregado');
