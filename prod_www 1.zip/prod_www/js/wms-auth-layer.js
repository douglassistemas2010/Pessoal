/**
 * WMS Layer com Autenticação HTTP Basic
 * Extensão do L.TileLayer.WMS para suportar autenticação
 */

L.TileLayer.WMSAuth = L.TileLayer.WMS.extend({
    initialize: function(url, options) {
        L.TileLayer.WMS.prototype.initialize.call(this, url, options);
        this.username = options.username;
        this.password = options.password;
    },

    createTile: function(coords, done) {
        const tile = document.createElement('img');
        
        L.DomEvent.on(tile, 'load', L.Util.bind(this._tileOnLoad, this, done, tile));
        L.DomEvent.on(tile, 'error', L.Util.bind(this._tileOnError, this, done, tile));

        if (this.options.crossOrigin || this.options.crossOrigin === '') {
            tile.crossOrigin = this.options.crossOrigin === true ? '' : this.options.crossOrigin;
        }

        tile.alt = '';
        tile.setAttribute('role', 'presentation');

        // Criar URL do tile
        const url = this.getTileUrl(coords);

        // Usar fetch com autenticação
        const authString = btoa(`${this.username}:${this.password}`);
        
        fetch(url, {
            headers: {
                'Authorization': `Basic ${authString}`
            },
            mode: 'cors',
            credentials: 'include'
        })
        .then(response => response.blob())
        .then(blob => {
            const objectURL = URL.createObjectURL(blob);
            tile.src = objectURL;
        })
        .catch(error => {
            console.error('Erro ao carregar tile WMS:', error);
            this._tileOnError(done, tile, error);
        });

        return tile;
    }
});

L.tileLayer.wmsAuth = function(url, options) {
    return new L.TileLayer.WMSAuth(url, options);
};
